#!/usr/bin/env python3
"""Independent offline physical and rank-RSS audit of the fixed 30e2941 pair."""
import ast
import collections
import csv
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

WORK=Path(__file__).resolve().parent
BASE=WORK.parent
SOURCE='30e29411431d4f721f1a9aa4b9b55fc685f70e7b'
LIMIT=2e-9
helper_files={
    BASE/'audit-physical-116836b.py':{'need','digest','records','history','difference','load_piece','volume'},
    BASE/'native-only-n8-116836b/audit.py':{'audit_run','compare_runs'},
}
for path,names in helper_files.items():
    tree=ast.parse(path.read_text())
    selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in names]
    assert {node.name for node in selected}==names
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),globals())

result=dict(status='running',build_source=SOURCE,runs=[],errors=[],
    audit_sha256=digest(__file__),
    parser_sources=[dict(path=str(path),sha256=digest(path)) for path in helper_files],
    scope='Two single observations, fixed source and input, no timing conclusion')


def check_stamp(entry):
    path=Path(entry['path'])
    need(path.stat().st_size==entry['bytes'] and digest(path)==entry['sha256'],('Artifact changed',str(path)))


def printed_close(actual,text):
    # The old root summary uses ostream precision inherited from other output.
    # Rank rows are printed with %.17g. Check aggregate agreement within the
    # precision actually present in the root summary, not an enlarged RSS gate.
    value=Decimal(text)
    half_unit=Decimal(5).scaleb(value.as_tuple().exponent-1)
    return abs(Decimal(actual)-value)<=half_unit


def exact_rank_audit(log,summary):
    groups=[]
    for line in log.splitlines():
        if line.startswith('solver_report '):
            groups.append(dict(report=records(line,'solver_report')[0],ranks=[]))
        elif line.startswith('solver_rank_report '):
            need(groups,'Rank memory before solver report')
            groups[-1]['ranks'].append(records(line,'solver_rank_report')[0])
    need(len(groups)==3,'Missing rank memory steps')
    rank_samples={0:[],1:[]}
    exact_steps=[]
    for step,group in enumerate(groups,1):
        need(collections.Counter(int(row['rank']) for row in group['ranks'])=={0:1,1:1},
             'Missing or duplicated per-rank memory record')
        typed=[]
        for raw in group['ranks']:
            row=dict(step=step,rank=int(raw['rank']),host=raw['host'],owned=int(raw['owned']),ghosts=int(raw['ghosts']))
            for name in ('rss_bytes','peak_rss_bytes','system_peak_rss_bytes'):
                value=float(raw[name])
                need(math.isfinite(value) and value>=0 and value.is_integer(),'Invalid rank RSS')
                row[name]=int(value)
            need(row['peak_rss_bytes']==max(row['rss_bytes'],row['system_peak_rss_bytes']),
                 ('Normalized/raw RSS invariant',row))
            typed.append(row);rank_samples[row['rank']].append(row)
        need(sum(row['owned'] for row in typed)==summary['dofs'],'Rank owned rows differ from actual DoFs')
        entry=dict(step=step,ranks=typed,
            rss_max_bytes=max(row['rss_bytes'] for row in typed),rss_sum_bytes=sum(row['rss_bytes'] for row in typed),
            peak_rss_max_bytes=max(row['peak_rss_bytes'] for row in typed),peak_rss_sum_bytes=sum(row['peak_rss_bytes'] for row in typed),
            system_peak_rss_max_bytes=max(row['system_peak_rss_bytes'] for row in typed),
            system_peak_rss_sum_bytes=sum(row['system_peak_rss_bytes'] for row in typed))
        for name in ('rss_max_bytes','rss_sum_bytes','peak_rss_max_bytes','peak_rss_sum_bytes'):
            need(printed_close(entry[name],group['report'][name]),('Global/rank RSS disagrees',step,name))
        exact_steps.append(entry)
    for name in ('rss_max_bytes','rss_sum_bytes','peak_rss_max_bytes','peak_rss_sum_bytes',
                 'system_peak_rss_max_bytes','system_peak_rss_sum_bytes'):
        summary[name]=max(row[name] for row in exact_steps)
    summary.update(rank_id_rss_available=True,raw_system_peak_rss_available=True,
        rank_rss_steps=exact_steps,rss_steps=exact_steps,
        rank_memory=[dict(rank=rank,host=samples[-1]['host'],
            final_rss_bytes=samples[-1]['rss_bytes'],max_observed_rss_bytes=max(row['rss_bytes'] for row in samples),
            max_normalized_peak_rss_bytes=max(row['peak_rss_bytes'] for row in samples),
            max_raw_system_peak_rss_bytes=max(row['system_peak_rss_bytes'] for row in samples),samples=samples)
            for rank,samples in rank_samples.items()],
        nodes=len({row['host'] for group in exact_steps for row in group['ranks']}))


def storage_audit(summary):
    first,last={},{}
    for row in summary['smoother_records']:
        key=int(row['rank']),int(row['level'])
        first.setdefault(key,row);last[key]=row
    for when,rows in (('first',first),('last',last)):
        total=summary[when+'_reported_storage_total']
        for field in ('factor_bytes','native_sparse_patches','native_dense_patches','native_index_bytes'):
            need(all(field in row for row in rows.values()),('Missing new storage counter',field))
            total[field]=sum(int(row[field]) for row in rows.values())
        total['reported_coefficients_lu_patch_indices_bytes']=(total['retained_coefficient_bytes']+
            total['factor_bytes']+total['native_index_bytes'])
        if summary['mode']=='mono_native_fp32':
            need(total['native_sparse_patches']>0 and
                 total['native_sparse_patches']+total['native_dense_patches']==total['patches'],
                 'Native compact patch representation was not executed')
        else:need(total['native_sparse_patches']==total['native_dense_patches']==total['native_index_bytes']==0,
                  'FP64 reference unexpectedly stored native patch coefficients')


def all_vtu_audit():
    directories=[WORK/'mono',WORK/'mono_native_fp32']
    modes=['mono','mono_native_fp32']
    pieces=[{p.name[len(mode):]:p for p in directory.glob(mode+'*.vtu')}
            for directory,mode in zip(directories,modes)]
    need(pieces[0].keys()==pieces[1].keys(),'Volume/boundary VTU file sets differ')
    maximum=0.;arrays_checked=0;files=[]
    for suffix in sorted(pieces[0]):
        roots=[ET.parse(pieces[i][suffix]).getroot().find('.//Piece') for i in (0,1)]
        need(roots[0].attrib==roots[1].attrib,('VTU piece dimensions differ',suffix))
        file_error=0.
        for group in ('Points','PointData','Cells','CellData'):
            arrays=[]
            for root in roots:
                arrays.append({node.attrib.get('Name','coordinates'):node
                               for node in root.findall('./'+group+'/DataArray')})
            need(arrays[0].keys()==arrays[1].keys(),('VTU array set differs',suffix,group))
            for name in arrays[0]:
                first,second=arrays[0][name],arrays[1][name]
                need(first.attrib==second.attrib and first.attrib['format']=='ascii',
                     ('VTU array metadata differs',suffix,group,name))
                if 'Float' in first.attrib['type']:
                    a=tuple(map(float,(first.text or '').split()));b=tuple(map(float,(second.text or '').split()))
                    need(len(a)==len(b) and all(map(math.isfinite,a+b)),('VTU values invalid',suffix,name))
                    error=max((abs(x-y) for x,y in zip(a,b)),default=0.)
                    need(error<=LIMIT,('VTU physical gate failed',suffix,group,name,error))
                    file_error=max(file_error,error)
                else:
                    a=tuple(map(int,(first.text or '').split()));b=tuple(map(int,(second.text or '').split()))
                    need(a==b,('VTU discrete identities/topology differ',suffix,group,name))
                arrays_checked+=1
        maximum=max(maximum,file_error)
        files.append(dict(suffix=suffix,max_difference=file_error,
                          reference=str(pieces[0][suffix]),candidate=str(pieces[1][suffix])))
    return dict(files_per_run=len(files),total_files_read=2*len(files),arrays_compared=arrays_checked,
                boundary_files_per_run=sum('_boundary' in name for name in pieces[0]),
                max_difference=maximum,files=files)


try:
    plan=json.loads((WORK/'invocation.json').read_text())
    need(plan['status']=='passed' and plan['build_source']==SOURCE and len(plan['runs'])==2,'Pair incomplete')
    result['invocation_sha256']=digest(WORK/'invocation.json')
    for item in [plan['binary'],plan['source_argv_receipt'],plan['script'],*plan['input_hashes']]:check_stamp(item)
    result['binary_sha256']=plan['binary']['sha256']
    original=plan['source_argv']
    old_case=Path(original[original.index('-case')+1])
    cfg=json.loads(old_case.read_text())
    runs=[]
    hashes=0;verified_paths=set()
    for run in plan['runs']:
        need(run['status']=='passed' and run['exit_code']==0,'Solver failed')
        for item in [run['case'],*run['mesh_inputs'],*run['artifacts']]:
            check_stamp(item);hashes+=1;verified_paths.add(item['path'])
        actual=list(run['command'][2:]);expected=list(original)
        expected[expected.index(str(old_case))]=run['case']['path']
        expected[3]=plan['binary']['path']
        expected+=['-solver_rank_report']
        if run['mode']=='mono_native_fp32':expected+=['-monolithic_mg_native_fp32','true']
        need(actual==expected,'Pair argv contains an unplanned option change')
        candidate_cfg=json.loads(Path(run['case']['path']).read_text())
        candidate_cfg['output']=cfg['output']
        need(candidate_cfg==cfg,'Physics/time/solver input changed')
        directory=Path(run['log']).parent
        parsed=audit_run(directory,run['mode'],cfg)
        exact_rank_audit(Path(run['log']).read_text(),parsed[3])
        storage_audit(parsed[3]);runs.append(parsed)
    result['artifacts_verified']=hashes
    result['distinct_run_artifacts_verified']=len(verified_paths)
    fp64,native=runs
    result['native_vs_fp64']=compare_runs(fp64,native)
    result['all_volume_and_boundary_vtu']=all_vtu_audit()
    old_receipt=json.loads(Path(plan['source_argv_receipt']['path']).read_text())
    direct_record=next(row for case in old_receipt['cases'] if case['name']=='scaling-n8-r2'
                       for row in case['runs'] if row['mode']=='direct')
    for item in direct_record['artifacts']:check_stamp(item)
    result['reference_direct_artifacts_verified']=len(direct_record['artifacts'])
    direct_history=history(old_case.parent/'direct.csv')
    direct=(direct_history,[volume(old_case.parent/f'direct_step{int(row["step"])}',2) for row in direct_history],
            volume(old_case.parent/'direct',2))
    result['native_vs_existing_direct']=compare_runs(direct,native)
    result['fp64_vs_existing_direct']=compare_runs(direct,fp64)
    a,b=fp64[3],native[3]
    result['comparison']=dict(iteration_change=b['outer_iterations']-a['outer_iterations'],
        first_coefficient_ratio=b['first_reported_storage_total']['retained_coefficient_bytes']/a['first_reported_storage_total']['retained_coefficient_bytes'],
        first_coefficient_lu_patch_index_ratio=b['first_reported_storage_total']['reported_coefficients_lu_patch_indices_bytes']/a['first_reported_storage_total']['reported_coefficients_lu_patch_indices_bytes'],
        peak_rss_max_ratio=b['peak_rss_max_bytes']/a['peak_rss_max_bytes'],
        peak_rss_sum_ratio=b['peak_rss_sum_bytes']/a['peak_rss_sum_bytes'],
        raw_system_peak_max_ratio=b['system_peak_rss_max_bytes']/a['system_peak_rss_max_bytes'],
        raw_system_peak_sum_ratio=b['system_peak_rss_sum_bytes']/a['system_peak_rss_sum_bytes'])
    result['status']='passed'
    result['limitations']=[
        'One FP64 and one native observation on the same fixed binary/input; no timing or general RSS scaling claim.',
        'Per-step rank RSS is exact to printed %.17g precision; normalized and raw OS peaks are retained separately.',
        'Summed per-rank peak samples are not a simultaneous allocator-wide peak measurement.',
        'Reported coefficient/LU/patch-index totals exclude other indices, PETSc vectors, communication buffers, outer P and allocator/runtime storage.',
        'FP64 emitted one initial hierarchy/storage report; native emitted reports for successive rebuilt generations.',
        'Residual norms are verified against saved original-operator diagnostics, not reconstructed from VTU.'
    ]
except BaseException as error:
    result['status']='failed';result['errors'].append(str(error))
finally:
    (WORK/'independent-audit.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in
        ('runs','native_vs_fp64','native_vs_existing_direct','fp64_vs_existing_direct','all_volume_and_boundary_vtu')},indent=2))
    for run in result['runs']:
        print(json.dumps({k:run.get(k) for k in ('mode','dofs','accepted_steps','corrections','outer_iterations',
            'max_true_residual_ratio','true_residual_checks','true_residual_rejections','rank_memory',
            'first_reported_storage_total','last_reported_storage_total')},indent=2))
    for name in ('native_vs_fp64','native_vs_existing_direct','fp64_vs_existing_direct'):
        if name in result:print(name,{k:v for k,v in result[name].items() if k.endswith('_max_difference')})
sys.exit(0 if result['status']=='passed' else 1)
