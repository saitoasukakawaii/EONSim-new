00000000000047c0 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)>:
    47c0:	55                   	push   %rbp
    47c1:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
    47c5:	48 89 e5             	mov    %rsp,%rbp
    47c8:	41 57                	push   %r15
    47ca:	41 56                	push   %r14
    47cc:	41 55                	push   %r13
    47ce:	41 54                	push   %r12
    47d0:	53                   	push   %rbx
    47d1:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
    47d5:	48 81 ec c0 0a 00 00 	sub    $0xac0,%rsp
    47dc:	48 83 f8 03          	cmp    $0x3,%rax
    47e0:	0f 87 00 00 00 00    	ja     47e6 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x26>
    47e6:	31 c0                	xor    %eax,%eax
    47e8:	49 89 fa             	mov    %rdi,%r10
    47eb:	49 89 c8             	mov    %rcx,%r8
    47ee:	b9 6c 00 00 00       	mov    $0x6c,%ecx
    47f3:	48 8d bc 24 60 07 00 	lea    0x760(%rsp),%rdi
    47fa:	00 
    47fb:	48 89 d3             	mov    %rdx,%rbx
    47fe:	45 31 c9             	xor    %r9d,%r9d
    4801:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    4804:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
    480b:	00 
    480c:	b9 30 00 00 00       	mov    $0x30,%ecx
    4811:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    4814:	48 8d 84 24 60 07 00 	lea    0x760(%rsp),%rax
    481b:	00 
    481c:	48 8d 8c 24 60 04 00 	lea    0x460(%rsp),%rcx
    4823:	00 
    4824:	48 89 f7             	mov    %rsi,%rdi
    4827:	4b 8b 14 ca          	mov    (%r10,%r9,8),%rdx
    482b:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    4830:	f2 0f 10 0a          	movsd  (%rdx),%xmm1
    4834:	f2 0f 11 40 20       	movsd  %xmm0,0x20(%rax)
    4839:	f2 0f 10 42 18       	movsd  0x18(%rdx),%xmm0
    483e:	f2 0f 11 08          	movsd  %xmm1,(%rax)
    4842:	f2 0f 10 4a 10       	movsd  0x10(%rdx),%xmm1
    4847:	f2 0f 11 40 60       	movsd  %xmm0,0x60(%rax)
    484c:	f2 0f 10 42 28       	movsd  0x28(%rdx),%xmm0
    4851:	f2 0f 11 48 40       	movsd  %xmm1,0x40(%rax)
    4856:	f2 0f 10 4a 20       	movsd  0x20(%rdx),%xmm1
    485b:	f2 0f 11 80 a0 00 00 	movsd  %xmm0,0xa0(%rax)
    4862:	00 
    4863:	f2 0f 10 42 38       	movsd  0x38(%rdx),%xmm0
    4868:	f2 0f 11 88 80 00 00 	movsd  %xmm1,0x80(%rax)
    486f:	00 
    4870:	f2 0f 10 4a 30       	movsd  0x30(%rdx),%xmm1
    4875:	f2 0f 11 80 e0 00 00 	movsd  %xmm0,0xe0(%rax)
    487c:	00 
    487d:	f2 0f 10 42 48       	movsd  0x48(%rdx),%xmm0
    4882:	f2 0f 11 88 c0 00 00 	movsd  %xmm1,0xc0(%rax)
    4889:	00 
    488a:	f2 0f 10 4a 40       	movsd  0x40(%rdx),%xmm1
    488f:	f2 0f 11 80 20 01 00 	movsd  %xmm0,0x120(%rax)
    4896:	00 
    4897:	f2 0f 10 42 58       	movsd  0x58(%rdx),%xmm0
    489c:	f2 0f 11 88 00 01 00 	movsd  %xmm1,0x100(%rax)
    48a3:	00 
    48a4:	f2 0f 10 4a 50       	movsd  0x50(%rdx),%xmm1
    48a9:	f2 0f 11 80 60 01 00 	movsd  %xmm0,0x160(%rax)
    48b0:	00 
    48b1:	f2 0f 10 42 68       	movsd  0x68(%rdx),%xmm0
    48b6:	f2 0f 11 88 40 01 00 	movsd  %xmm1,0x140(%rax)
    48bd:	00 
    48be:	f2 0f 10 4a 60       	movsd  0x60(%rdx),%xmm1
    48c3:	f2 0f 11 80 a0 01 00 	movsd  %xmm0,0x1a0(%rax)
    48ca:	00 
    48cb:	f2 0f 10 42 78       	movsd  0x78(%rdx),%xmm0
    48d0:	f2 0f 11 88 80 01 00 	movsd  %xmm1,0x180(%rax)
    48d7:	00 
    48d8:	f2 0f 10 4a 70       	movsd  0x70(%rdx),%xmm1
    48dd:	f2 0f 11 88 c0 01 00 	movsd  %xmm1,0x1c0(%rax)
    48e4:	00 
    48e5:	f2 0f 11 80 e0 01 00 	movsd  %xmm0,0x1e0(%rax)
    48ec:	00 
    48ed:	f2 0f 10 82 88 00 00 	movsd  0x88(%rdx),%xmm0
    48f4:	00 
    48f5:	f2 0f 10 8a 80 00 00 	movsd  0x80(%rdx),%xmm1
    48fc:	00 
    48fd:	f2 0f 11 80 20 02 00 	movsd  %xmm0,0x220(%rax)
    4904:	00 
    4905:	f2 0f 10 82 98 00 00 	movsd  0x98(%rdx),%xmm0
    490c:	00 
    490d:	f2 0f 11 88 00 02 00 	movsd  %xmm1,0x200(%rax)
    4914:	00 
    4915:	f2 0f 10 8a 90 00 00 	movsd  0x90(%rdx),%xmm1
    491c:	00 
    491d:	f2 0f 11 80 60 02 00 	movsd  %xmm0,0x260(%rax)
    4924:	00 
    4925:	f2 0f 10 82 a8 00 00 	movsd  0xa8(%rdx),%xmm0
    492c:	00 
    492d:	f2 0f 11 88 40 02 00 	movsd  %xmm1,0x240(%rax)
    4934:	00 
    4935:	f2 0f 10 8a a0 00 00 	movsd  0xa0(%rdx),%xmm1
    493c:	00 
    493d:	f2 0f 11 80 a0 02 00 	movsd  %xmm0,0x2a0(%rax)
    4944:	00 
    4945:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
    494c:	00 
    494d:	f2 0f 11 88 80 02 00 	movsd  %xmm1,0x280(%rax)
    4954:	00 
    4955:	f2 0f 10 8a b0 00 00 	movsd  0xb0(%rdx),%xmm1
    495c:	00 
    495d:	f2 0f 11 80 e0 02 00 	movsd  %xmm0,0x2e0(%rax)
    4964:	00 
    4965:	f2 0f 10 82 c8 00 00 	movsd  0xc8(%rdx),%xmm0
    496c:	00 
    496d:	f2 0f 11 88 c0 02 00 	movsd  %xmm1,0x2c0(%rax)
    4974:	00 
    4975:	f2 0f 10 8a c0 00 00 	movsd  0xc0(%rdx),%xmm1
    497c:	00 
    497d:	f2 0f 11 80 20 03 00 	movsd  %xmm0,0x320(%rax)
    4984:	00 
    4985:	f2 0f 10 82 d0 00 00 	movsd  0xd0(%rdx),%xmm0
    498c:	00 
    498d:	f2 0f 11 88 00 03 00 	movsd  %xmm1,0x300(%rax)
    4994:	00 
    4995:	f2 0f 11 80 40 03 00 	movsd  %xmm0,0x340(%rax)
    499c:	00 
    499d:	4d 39 c1             	cmp    %r8,%r9
    49a0:	0f 82 9b 00 00 00    	jb     4a41 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x281>
    49a6:	49 83 c1 01          	add    $0x1,%r9
    49aa:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    49b1:	48 c7 41 20 00 00 00 	movq   $0x0,0x20(%rcx)
    49b8:	00 
    49b9:	48 c7 41 40 00 00 00 	movq   $0x0,0x40(%rcx)
    49c0:	00 
    49c1:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    49c8:	00 
    49c9:	48 c7 81 80 00 00 00 	movq   $0x0,0x80(%rcx)
    49d0:	00 00 00 00 
    49d4:	48 c7 81 a0 00 00 00 	movq   $0x0,0xa0(%rcx)
    49db:	00 00 00 00 
    49df:	48 c7 81 c0 00 00 00 	movq   $0x0,0xc0(%rcx)
    49e6:	00 00 00 00 
    49ea:	48 c7 81 e0 00 00 00 	movq   $0x0,0xe0(%rcx)
    49f1:	00 00 00 00 
    49f5:	48 c7 81 00 01 00 00 	movq   $0x0,0x100(%rcx)
    49fc:	00 00 00 00 
    4a00:	48 c7 81 20 01 00 00 	movq   $0x0,0x120(%rcx)
    4a07:	00 00 00 00 
    4a0b:	48 c7 81 40 01 00 00 	movq   $0x0,0x140(%rcx)
    4a12:	00 00 00 00 
    4a16:	48 c7 81 60 01 00 00 	movq   $0x0,0x160(%rcx)
    4a1d:	00 00 00 00 
    4a21:	4d 39 c1             	cmp    %r8,%r9
    4a24:	0f 83 c9 00 00 00    	jae    4af3 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x333>
    4a2a:	48 83 c0 08          	add    $0x8,%rax
    4a2e:	48 83 c1 08          	add    $0x8,%rcx
    4a32:	48 83 c7 60          	add    $0x60,%rdi
    4a36:	41 b9 02 00 00 00    	mov    $0x2,%r9d
    4a3c:	e9 e6 fd ff ff       	jmp    4827 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x67>
    4a41:	f2 0f 10 07          	movsd  (%rdi),%xmm0
    4a45:	49 83 c1 01          	add    $0x1,%r9
    4a49:	f2 0f 11 01          	movsd  %xmm0,(%rcx)
    4a4d:	f2 0f 10 47 08       	movsd  0x8(%rdi),%xmm0
    4a52:	f2 0f 11 41 20       	movsd  %xmm0,0x20(%rcx)
    4a57:	f2 0f 10 47 10       	movsd  0x10(%rdi),%xmm0
    4a5c:	f2 0f 11 41 40       	movsd  %xmm0,0x40(%rcx)
    4a61:	f2 0f 10 47 18       	movsd  0x18(%rdi),%xmm0
    4a66:	f2 0f 11 41 60       	movsd  %xmm0,0x60(%rcx)
    4a6b:	f2 0f 10 47 20       	movsd  0x20(%rdi),%xmm0
    4a70:	f2 0f 11 81 80 00 00 	movsd  %xmm0,0x80(%rcx)
    4a77:	00 
    4a78:	f2 0f 10 47 28       	movsd  0x28(%rdi),%xmm0
    4a7d:	f2 0f 11 81 a0 00 00 	movsd  %xmm0,0xa0(%rcx)
    4a84:	00 
    4a85:	f2 0f 10 47 30       	movsd  0x30(%rdi),%xmm0
    4a8a:	f2 0f 11 81 c0 00 00 	movsd  %xmm0,0xc0(%rcx)
    4a91:	00 
    4a92:	f2 0f 10 47 38       	movsd  0x38(%rdi),%xmm0
    4a97:	f2 0f 11 81 e0 00 00 	movsd  %xmm0,0xe0(%rcx)
    4a9e:	00 
    4a9f:	f2 0f 10 47 40       	movsd  0x40(%rdi),%xmm0
    4aa4:	f2 0f 11 81 00 01 00 	movsd  %xmm0,0x100(%rcx)
    4aab:	00 
    4aac:	f2 0f 10 47 48       	movsd  0x48(%rdi),%xmm0
    4ab1:	f2 0f 11 81 20 01 00 	movsd  %xmm0,0x120(%rcx)
    4ab8:	00 
    4ab9:	f2 0f 10 47 50       	movsd  0x50(%rdi),%xmm0
    4abe:	f2 0f 11 81 40 01 00 	movsd  %xmm0,0x140(%rcx)
    4ac5:	00 
    4ac6:	f2 0f 10 47 58       	movsd  0x58(%rdi),%xmm0
    4acb:	f2 0f 11 81 60 01 00 	movsd  %xmm0,0x160(%rcx)
    4ad2:	00 
    4ad3:	4d 39 c1             	cmp    %r8,%r9
    4ad6:	73 11                	jae    4ae9 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x329>
    4ad8:	48 83 c0 08          	add    $0x8,%rax
    4adc:	48 83 c1 08          	add    $0x8,%rcx
    4ae0:	48 83 c7 60          	add    $0x60,%rdi
    4ae4:	e9 3e fd ff ff       	jmp    4827 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x67>
    4ae9:	49 83 f8 04          	cmp    $0x4,%r8
    4aed:	0f 84 a3 0f 00 00    	je     5a96 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x12d6>
    4af3:	4b 8d 14 40          	lea    (%r8,%r8,2),%rdx
    4af7:	4e 8d 0c c5 00 00 00 	lea    0x0(,%r8,8),%r9
    4afe:	00 
    4aff:	4c 89 c7             	mov    %r8,%rdi
    4b02:	48 c1 e2 05          	shl    $0x5,%rdx
    4b06:	4a 8d 84 0c 60 07 00 	lea    0x760(%rsp,%r9,1),%rax
    4b0d:	00 
    4b0e:	4a 8d 8c 0c 60 04 00 	lea    0x460(%rsp,%r9,1),%rcx
    4b15:	00 
    4b16:	48 01 d6             	add    %rdx,%rsi
    4b19:	49 8b 12             	mov    (%r10),%rdx
    4b1c:	f2 0f 10 82 b8 00 00 	movsd  0xb8(%rdx),%xmm0
    4b23:	00 
    4b24:	f2 0f 10 7a 08       	movsd  0x8(%rdx),%xmm7
    4b29:	f2 0f 10 72 18       	movsd  0x18(%rdx),%xmm6
    4b2e:	4c 8b 5a 20          	mov    0x20(%rdx),%r11
    4b32:	66 49 0f 7e ff       	movq   %xmm7,%r15
    4b37:	f2 0f 10 3a          	movsd  (%rdx),%xmm7
    4b3b:	4c 8b 52 38          	mov    0x38(%rdx),%r10
    4b3f:	f2 0f 11 84 24 d0 00 	movsd  %xmm0,0xd0(%rsp)
    4b46:	00 00 
    4b48:	f2 0f 10 82 b0 00 00 	movsd  0xb0(%rdx),%xmm0
    4b4f:	00 
    4b50:	f2 44 0f 10 7a 30    	movsd  0x30(%rdx),%xmm15
    4b56:	f2 0f 11 b4 24 b0 00 	movsd  %xmm6,0xb0(%rsp)
    4b5d:	00 00 
    4b5f:	f2 0f 11 bc 24 90 00 	movsd  %xmm7,0x90(%rsp)
    4b66:	00 00 
    4b68:	f2 0f 10 72 28       	movsd  0x28(%rdx),%xmm6
    4b6d:	f2 0f 10 7a 10       	movsd  0x10(%rdx),%xmm7
    4b72:	66 49 0f 7e c6       	movq   %xmm0,%r14
    4b77:	f2 0f 10 82 c8 00 00 	movsd  0xc8(%rdx),%xmm0
    4b7e:	00 
    4b7f:	f2 44 0f 10 72 48    	movsd  0x48(%rdx),%xmm14
    4b85:	f2 0f 11 bc 24 c0 00 	movsd  %xmm7,0xc0(%rsp)
    4b8c:	00 00 
    4b8e:	f2 44 0f 10 6a 40    	movsd  0x40(%rdx),%xmm13
    4b94:	f2 44 0f 10 62 58    	movsd  0x58(%rdx),%xmm12
    4b9a:	66 49 0f 7e c4       	movq   %xmm0,%r12
    4b9f:	f2 0f 10 82 c0 00 00 	movsd  0xc0(%rdx),%xmm0
    4ba6:	00 
    4ba7:	f2 0f 11 b4 24 a0 00 	movsd  %xmm6,0xa0(%rsp)
    4bae:	00 00 
    4bb0:	f2 44 0f 10 5a 50    	movsd  0x50(%rdx),%xmm11
    4bb6:	f2 44 0f 10 52 68    	movsd  0x68(%rdx),%xmm10
    4bbc:	f2 44 0f 10 4a 60    	movsd  0x60(%rdx),%xmm9
    4bc2:	f2 44 0f 10 42 78    	movsd  0x78(%rdx),%xmm8
    4bc8:	f2 0f 10 7a 70       	movsd  0x70(%rdx),%xmm7
    4bcd:	66 49 0f 7e c5       	movq   %xmm0,%r13
    4bd2:	f2 0f 10 b2 88 00 00 	movsd  0x88(%rdx),%xmm6
    4bd9:	00 
    4bda:	f2 0f 10 aa 80 00 00 	movsd  0x80(%rdx),%xmm5
    4be1:	00 
    4be2:	f2 0f 10 a2 98 00 00 	movsd  0x98(%rdx),%xmm4
    4be9:	00 
    4bea:	f2 0f 10 9a 90 00 00 	movsd  0x90(%rdx),%xmm3
    4bf1:	00 
    4bf2:	f2 0f 10 92 a8 00 00 	movsd  0xa8(%rdx),%xmm2
    4bf9:	00 
    4bfa:	f2 0f 10 8a a0 00 00 	movsd  0xa0(%rdx),%xmm1
    4c01:	00 
    4c02:	48 8b 92 d0 00 00 00 	mov    0xd0(%rdx),%rdx
    4c09:	f2 0f 10 84 24 90 00 	movsd  0x90(%rsp),%xmm0
    4c10:	00 00 
    4c12:	4c 89 78 20          	mov    %r15,0x20(%rax)
    4c16:	4c 89 98 80 00 00 00 	mov    %r11,0x80(%rax)
    4c1d:	f2 0f 11 00          	movsd  %xmm0,(%rax)
    4c21:	f2 0f 10 84 24 c0 00 	movsd  0xc0(%rsp),%xmm0
    4c28:	00 00 
    4c2a:	4c 89 90 e0 00 00 00 	mov    %r10,0xe0(%rax)
    4c31:	f2 0f 11 40 40       	movsd  %xmm0,0x40(%rax)
    4c36:	f2 0f 10 84 24 b0 00 	movsd  0xb0(%rsp),%xmm0
    4c3d:	00 00 
    4c3f:	4c 89 b0 c0 02 00 00 	mov    %r14,0x2c0(%rax)
    4c46:	f2 0f 11 40 60       	movsd  %xmm0,0x60(%rax)
    4c4b:	f2 0f 10 84 24 a0 00 	movsd  0xa0(%rsp),%xmm0
    4c52:	00 00 
    4c54:	4c 89 a8 00 03 00 00 	mov    %r13,0x300(%rax)
    4c5b:	f2 0f 11 80 a0 00 00 	movsd  %xmm0,0xa0(%rax)
    4c62:	00 
    4c63:	f2 0f 10 84 24 d0 00 	movsd  0xd0(%rsp),%xmm0
    4c6a:	00 00 
    4c6c:	4c 89 a0 20 03 00 00 	mov    %r12,0x320(%rax)
    4c73:	48 89 90 40 03 00 00 	mov    %rdx,0x340(%rax)
    4c7a:	f2 44 0f 11 b8 c0 00 	movsd  %xmm15,0xc0(%rax)
    4c81:	00 00 
    4c83:	f2 44 0f 11 a8 00 01 	movsd  %xmm13,0x100(%rax)
    4c8a:	00 00 
    4c8c:	f2 44 0f 11 b0 20 01 	movsd  %xmm14,0x120(%rax)
    4c93:	00 00 
    4c95:	f2 44 0f 11 98 40 01 	movsd  %xmm11,0x140(%rax)
    4c9c:	00 00 
    4c9e:	f2 44 0f 11 a0 60 01 	movsd  %xmm12,0x160(%rax)
    4ca5:	00 00 
    4ca7:	f2 44 0f 11 88 80 01 	movsd  %xmm9,0x180(%rax)
    4cae:	00 00 
    4cb0:	f2 44 0f 11 90 a0 01 	movsd  %xmm10,0x1a0(%rax)
    4cb7:	00 00 
    4cb9:	f2 0f 11 b8 c0 01 00 	movsd  %xmm7,0x1c0(%rax)
    4cc0:	00 
    4cc1:	f2 44 0f 11 80 e0 01 	movsd  %xmm8,0x1e0(%rax)
    4cc8:	00 00 
    4cca:	f2 0f 11 a8 00 02 00 	movsd  %xmm5,0x200(%rax)
    4cd1:	00 
    4cd2:	f2 0f 11 b0 20 02 00 	movsd  %xmm6,0x220(%rax)
    4cd9:	00 
    4cda:	f2 0f 11 98 40 02 00 	movsd  %xmm3,0x240(%rax)
    4ce1:	00 
    4ce2:	f2 0f 11 a0 60 02 00 	movsd  %xmm4,0x260(%rax)
    4ce9:	00 
    4cea:	f2 0f 11 88 80 02 00 	movsd  %xmm1,0x280(%rax)
    4cf1:	00 
    4cf2:	f2 0f 11 90 a0 02 00 	movsd  %xmm2,0x2a0(%rax)
    4cf9:	00 
    4cfa:	f2 0f 11 80 e0 02 00 	movsd  %xmm0,0x2e0(%rax)
    4d01:	00 
    4d02:	4c 39 c7             	cmp    %r8,%rdi
    4d05:	0f 82 1d 0b 00 00    	jb     5828 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1068>
    4d0b:	48 83 c7 01          	add    $0x1,%rdi
    4d0f:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    4d16:	48 c7 41 20 00 00 00 	movq   $0x0,0x20(%rcx)
    4d1d:	00 
    4d1e:	48 c7 41 40 00 00 00 	movq   $0x0,0x40(%rcx)
    4d25:	00 
    4d26:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    4d2d:	00 
    4d2e:	48 c7 81 80 00 00 00 	movq   $0x0,0x80(%rcx)
    4d35:	00 00 00 00 
    4d39:	48 c7 81 a0 00 00 00 	movq   $0x0,0xa0(%rcx)
    4d40:	00 00 00 00 
    4d44:	48 c7 81 c0 00 00 00 	movq   $0x0,0xc0(%rcx)
    4d4b:	00 00 00 00 
    4d4f:	48 c7 81 e0 00 00 00 	movq   $0x0,0xe0(%rcx)
    4d56:	00 00 00 00 
    4d5a:	48 c7 81 00 01 00 00 	movq   $0x0,0x100(%rcx)
    4d61:	00 00 00 00 
    4d65:	48 c7 81 20 01 00 00 	movq   $0x0,0x120(%rcx)
    4d6c:	00 00 00 00 
    4d70:	48 c7 81 40 01 00 00 	movq   $0x0,0x140(%rcx)
    4d77:	00 00 00 00 
    4d7b:	48 c7 81 60 01 00 00 	movq   $0x0,0x160(%rcx)
    4d82:	00 00 00 00 
    4d86:	48 83 ff 04          	cmp    $0x4,%rdi
    4d8a:	0f 85 34 0b 00 00    	jne    58c4 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1104>
    4d90:	4c 8d ac 24 00 01 00 	lea    0x100(%rsp),%r13
    4d97:	00 
    4d98:	31 c0                	xor    %eax,%eax
    4d9a:	66 0f ef ff          	pxor   %xmm7,%xmm7
    4d9e:	b9 24 00 00 00       	mov    $0x24,%ecx
    4da3:	4c 89 ef             	mov    %r13,%rdi
    4da6:	0f 29 7c 24 30       	movaps %xmm7,0x30(%rsp)
    4dab:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    4db2:	00 
    4db3:	66 44 0f 28 b4 24 40 	movapd 0x940(%rsp),%xmm14
    4dba:	09 00 00 
    4dbd:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    4dc0:	b9 24 00 00 00       	mov    $0x24,%ecx
    4dc5:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
    4dcc:	00 
    4dcd:	66 44 0f 28 ac 24 50 	movapd 0x950(%rsp),%xmm13
    4dd4:	09 00 00 
    4dd7:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    4dda:	b9 24 00 00 00       	mov    $0x24,%ecx
    4ddf:	48 89 f7             	mov    %rsi,%rdi
    4de2:	4c 8d 94 24 e0 05 00 	lea    0x5e0(%rsp),%r10
    4de9:	00 
    4dea:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    4ded:	0f 29 bc 24 90 00 00 	movaps %xmm7,0x90(%rsp)
    4df4:	00 
    4df5:	48 8d 8c 24 60 07 00 	lea    0x760(%rsp),%rcx
    4dfc:	00 
    4dfd:	48 8d 84 24 60 04 00 	lea    0x460(%rsp),%rax
    4e04:	00 
    4e05:	0f 29 bc 24 d0 00 00 	movaps %xmm7,0xd0(%rsp)
    4e0c:	00 
    4e0d:	66 44 0f 28 c7       	movapd %xmm7,%xmm8
    4e12:	66 44 0f 28 cf       	movapd %xmm7,%xmm9
    4e17:	66 44 0f 28 d7       	movapd %xmm7,%xmm10
    4e1c:	0f 29 7c 24 40       	movaps %xmm7,0x40(%rsp)
    4e21:	66 44 0f 28 df       	movapd %xmm7,%xmm11
    4e26:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
    4e2b:	0f 29 bc 24 a0 00 00 	movaps %xmm7,0xa0(%rsp)
    4e32:	00 
    4e33:	0f 29 bc 24 b0 00 00 	movaps %xmm7,0xb0(%rsp)
    4e3a:	00 
    4e3b:	0f 29 bc 24 c0 00 00 	movaps %xmm7,0xc0(%rsp)
    4e42:	00 
    4e43:	0f 29 7c 24 50       	movaps %xmm7,0x50(%rsp)
    4e48:	0f 29 7c 24 60       	movaps %xmm7,0x60(%rsp)
    4e4d:	0f 29 7c 24 70       	movaps %xmm7,0x70(%rsp)
    4e52:	0f 29 bc 24 80 00 00 	movaps %xmm7,0x80(%rsp)
    4e59:	00 
    4e5a:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    4e5f:	0f 29 7c 24 20       	movaps %xmm7,0x20(%rsp)
    4e64:	66 0f 28 28          	movapd (%rax),%xmm5
    4e68:	66 0f 28 59 20       	movapd 0x20(%rcx),%xmm3
    4e6d:	48 83 c0 60          	add    $0x60,%rax
    4e71:	48 83 c1 60          	add    $0x60,%rcx
    4e75:	66 0f 28 60 b0       	movapd -0x50(%rax),%xmm4
    4e7a:	66 0f 28 51 d0       	movapd -0x30(%rcx),%xmm2
    4e7f:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
    4e84:	66 0f 28 49 e0       	movapd -0x20(%rcx),%xmm1
    4e89:	66 0f 28 39          	movapd (%rcx),%xmm7
    4e8d:	66 44 0f 28 fb       	movapd %xmm3,%xmm15
    4e92:	66 41 0f 59 e5       	mulpd  %xmm13,%xmm4
    4e97:	66 0f 28 c5          	movapd %xmm5,%xmm0
    4e9b:	66 0f 28 f5          	movapd %xmm5,%xmm6
    4e9f:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
    4ea3:	66 0f 59 f1          	mulpd  %xmm1,%xmm6
    4ea7:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
    4eab:	66 44 0f 58 e0       	addpd  %xmm0,%xmm12
    4eb0:	66 0f 28 c4          	movapd %xmm4,%xmm0
    4eb4:	66 0f 59 c2          	mulpd  %xmm2,%xmm0
    4eb8:	66 44 0f 58 d6       	addpd  %xmm6,%xmm10
    4ebd:	66 0f 28 f4          	movapd %xmm4,%xmm6
    4ec1:	66 44 0f 58 c5       	addpd  %xmm5,%xmm8
    4ec6:	66 0f 28 68 c0       	movapd -0x40(%rax),%xmm5
    4ecb:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
    4ed0:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
    4ed5:	66 0f 28 41 f0       	movapd -0x10(%rcx),%xmm0
    4eda:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
    4ede:	66 44 0f 59 fd       	mulpd  %xmm5,%xmm15
    4ee3:	66 44 0f 58 7c 24 10 	addpd  0x10(%rsp),%xmm15
    4eea:	66 44 0f 58 ce       	addpd  %xmm6,%xmm9
    4eef:	66 0f 28 71 10       	movapd 0x10(%rcx),%xmm6
    4ef4:	44 0f 29 7c 24 10    	movaps %xmm15,0x10(%rsp)
    4efa:	66 44 0f 28 fa       	movapd %xmm2,%xmm15
    4eff:	66 0f 59 e6          	mulpd  %xmm6,%xmm4
    4f03:	66 0f 58 64 24 20    	addpd  0x20(%rsp),%xmm4
    4f09:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
    4f0e:	66 0f 28 60 d0       	movapd -0x30(%rax),%xmm4
    4f13:	66 41 0f 59 e5       	mulpd  %xmm13,%xmm4
    4f18:	66 44 0f 59 fc       	mulpd  %xmm4,%xmm15
    4f1d:	66 44 0f 58 bc 24 80 	addpd  0x80(%rsp),%xmm15
    4f24:	00 00 00 
    4f27:	44 0f 29 bc 24 80 00 	movaps %xmm15,0x80(%rsp)
    4f2e:	00 00 
    4f30:	66 44 0f 28 f9       	movapd %xmm1,%xmm15
    4f35:	66 44 0f 59 fd       	mulpd  %xmm5,%xmm15
    4f3a:	66 44 0f 58 7c 24 70 	addpd  0x70(%rsp),%xmm15
    4f41:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
    4f45:	66 0f 58 6c 24 50    	addpd  0x50(%rsp),%xmm5
    4f4b:	44 0f 29 7c 24 70    	movaps %xmm15,0x70(%rsp)
    4f51:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
    4f56:	66 44 0f 59 fc       	mulpd  %xmm4,%xmm15
    4f5b:	0f 29 6c 24 50       	movaps %xmm5,0x50(%rsp)
    4f60:	66 0f 28 68 e0       	movapd -0x20(%rax),%xmm5
    4f65:	66 0f 59 e6          	mulpd  %xmm6,%xmm4
    4f69:	66 44 0f 58 7c 24 60 	addpd  0x60(%rsp),%xmm15
    4f70:	66 0f 58 64 24 40    	addpd  0x40(%rsp),%xmm4
    4f76:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
    4f7b:	44 0f 29 7c 24 60    	movaps %xmm15,0x60(%rsp)
    4f81:	0f 29 64 24 40       	movaps %xmm4,0x40(%rsp)
    4f86:	66 0f 28 60 f0       	movapd -0x10(%rax),%xmm4
    4f8b:	66 41 0f 59 e5       	mulpd  %xmm13,%xmm4
    4f90:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
    4f94:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
    4f98:	66 0f 58 5c 24 30    	addpd  0x30(%rsp),%xmm3
    4f9e:	66 0f 58 8c 24 b0 00 	addpd  0xb0(%rsp),%xmm1
    4fa5:	00 00 
    4fa7:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
    4fab:	66 0f 59 d4          	mulpd  %xmm4,%xmm2
    4faf:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    4fb4:	66 0f 58 94 24 c0 00 	addpd  0xc0(%rsp),%xmm2
    4fbb:	00 00 
    4fbd:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
    4fc1:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
    4fc8:	00 
    4fc9:	66 0f 59 e6          	mulpd  %xmm6,%xmm4
    4fcd:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
    4fd4:	00 
    4fd5:	66 0f 58 84 24 a0 00 	addpd  0xa0(%rsp),%xmm0
    4fdc:	00 00 
    4fde:	66 0f 58 ac 24 d0 00 	addpd  0xd0(%rsp),%xmm5
    4fe5:	00 00 
    4fe7:	66 0f 58 a4 24 90 00 	addpd  0x90(%rsp),%xmm4
    4fee:	00 00 
    4ff0:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
    4ff7:	00 
    4ff8:	0f 29 ac 24 d0 00 00 	movaps %xmm5,0xd0(%rsp)
    4fff:	00 
    5000:	0f 29 a4 24 90 00 00 	movaps %xmm4,0x90(%rsp)
    5007:	00 
    5008:	49 39 c2             	cmp    %rax,%r10
    500b:	0f 85 53 fe ff ff    	jne    4e64 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x6a4>
    5011:	0f 29 94 24 d0 01 00 	movaps %xmm2,0x1d0(%rsp)
    5018:	00 
    5019:	66 0f 28 74 24 10    	movapd 0x10(%rsp),%xmm6
    501f:	66 0f 28 94 24 d0 00 	movapd 0xd0(%rsp),%xmm2
    5026:	00 00 
    5028:	66 41 0f 28 df       	movapd %xmm15,%xmm3
    502d:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
    5034:	00 
    5035:	66 0f 28 64 24 70    	movapd 0x70(%rsp),%xmm4
    503b:	66 0f 28 84 24 80 09 	movapd 0x980(%rsp),%xmm0
    5042:	00 00 
    5044:	48 8d 84 24 20 02 00 	lea    0x220(%rsp),%rax
    504b:	00 
    504c:	0f 29 94 24 00 02 00 	movaps %xmm2,0x200(%rsp)
    5053:	00 
    5054:	66 44 0f 28 74 24 50 	movapd 0x50(%rsp),%xmm14
    505b:	66 0f 28 94 24 90 09 	movapd 0x990(%rsp),%xmm2
    5062:	00 00 
    5064:	48 8d 8c 24 60 07 00 	lea    0x760(%rsp),%rcx
    506b:	00 
    506c:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    5071:	0f 29 8c 24 e0 01 00 	movaps %xmm1,0x1e0(%rsp)
    5078:	00 
    5079:	66 0f 28 8c 24 90 00 	movapd 0x90(%rsp),%xmm1
    5080:	00 00 
    5082:	66 0f 28 ac 24 80 00 	movapd 0x80(%rsp),%xmm5
    5089:	00 00 
    508b:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
    5090:	66 44 0f 28 6c 24 40 	movapd 0x40(%rsp),%xmm13
    5097:	66 0f 28 7c 24 20    	movapd 0x20(%rsp),%xmm7
    509d:	44 0f 29 bc 24 90 01 	movaps %xmm15,0x190(%rsp)
    50a4:	00 00 
    50a6:	0f 29 8c 24 10 02 00 	movaps %xmm1,0x210(%rsp)
    50ad:	00 
    50ae:	66 0f ef c9          	pxor   %xmm1,%xmm1
    50b2:	66 44 0f 28 7c 24 30 	movapd 0x30(%rsp),%xmm15
    50b9:	0f 29 b4 24 60 01 00 	movaps %xmm6,0x160(%rsp)
    50c0:	00 
    50c1:	0f 29 a4 24 80 01 00 	movaps %xmm4,0x180(%rsp)
    50c8:	00 
    50c9:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    50cd:	44 0f 29 a4 24 00 01 	movaps %xmm12,0x100(%rsp)
    50d4:	00 00 
    50d6:	66 0f 58 d1          	addpd  %xmm1,%xmm2
    50da:	66 0f 28 8c 24 a0 09 	movapd 0x9a0(%rsp),%xmm1
    50e1:	00 00 
    50e3:	44 0f 29 9c 24 10 01 	movaps %xmm11,0x110(%rsp)
    50ea:	00 00 
    50ec:	44 0f 29 94 24 20 01 	movaps %xmm10,0x120(%rsp)
    50f3:	00 00 
    50f5:	66 41 0f 59 ca       	mulpd  %xmm10,%xmm1
    50fa:	0f 29 bc 24 50 01 00 	movaps %xmm7,0x150(%rsp)
    5101:	00 
    5102:	44 0f 29 8c 24 30 01 	movaps %xmm9,0x130(%rsp)
    5109:	00 00 
    510b:	44 0f 29 84 24 40 01 	movaps %xmm8,0x140(%rsp)
    5112:	00 00 
    5114:	0f 29 ac 24 70 01 00 	movaps %xmm5,0x170(%rsp)
    511b:	00 
    511c:	44 0f 29 b4 24 a0 01 	movaps %xmm14,0x1a0(%rsp)
    5123:	00 00 
    5125:	44 0f 29 ac 24 b0 01 	movaps %xmm13,0x1b0(%rsp)
    512c:	00 00 
    512e:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    5132:	66 0f 28 84 24 b0 09 	movapd 0x9b0(%rsp),%xmm0
    5139:	00 00 
    513b:	44 0f 29 bc 24 c0 01 	movaps %xmm15,0x1c0(%rsp)
    5142:	00 00 
    5144:	66 41 0f 59 c1       	mulpd  %xmm9,%xmm0
    5149:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    514d:	66 0f 28 94 24 c0 09 	movapd 0x9c0(%rsp),%xmm2
    5154:	00 00 
    5156:	66 0f 59 bc 24 d0 09 	mulpd  0x9d0(%rsp),%xmm7
    515d:	00 00 
    515f:	66 0f 59 b4 24 e0 09 	mulpd  0x9e0(%rsp),%xmm6
    5166:	00 00 
    5168:	66 41 0f 59 d0       	mulpd  %xmm8,%xmm2
    516d:	66 0f 59 a4 24 00 0a 	mulpd  0xa00(%rsp),%xmm4
    5174:	00 00 
    5176:	66 0f 59 9c 24 10 0a 	mulpd  0xa10(%rsp),%xmm3
    517d:	00 00 
    517f:	66 0f 58 d1          	addpd  %xmm1,%xmm2
    5183:	66 0f 28 cf          	movapd %xmm7,%xmm1
    5187:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    518b:	66 0f 28 c6          	movapd %xmm6,%xmm0
    518f:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    5193:	66 0f 28 94 24 f0 09 	movapd 0x9f0(%rsp),%xmm2
    519a:	00 00 
    519c:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
    51a0:	66 0f 58 d1          	addpd  %xmm1,%xmm2
    51a4:	66 0f 28 cc          	movapd %xmm4,%xmm1
    51a8:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    51ac:	66 0f 28 c3          	movapd %xmm3,%xmm0
    51b0:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    51b4:	66 0f 28 94 24 20 0a 	movapd 0xa20(%rsp),%xmm2
    51bb:	00 00 
    51bd:	66 41 0f 59 d6       	mulpd  %xmm14,%xmm2
    51c2:	66 0f 58 d1          	addpd  %xmm1,%xmm2
    51c6:	66 0f 28 8c 24 30 0a 	movapd 0xa30(%rsp),%xmm1
    51cd:	00 00 
    51cf:	66 41 0f 59 cd       	mulpd  %xmm13,%xmm1
    51d4:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    51d8:	66 0f 28 84 24 40 0a 	movapd 0xa40(%rsp),%xmm0
    51df:	00 00 
    51e1:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
    51e6:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    51ea:	66 0f 28 94 24 c0 00 	movapd 0xc0(%rsp),%xmm2
    51f1:	00 00 
    51f3:	66 0f 59 94 24 50 0a 	mulpd  0xa50(%rsp),%xmm2
    51fa:	00 00 
    51fc:	66 0f 58 d1          	addpd  %xmm1,%xmm2
    5200:	66 0f 28 8c 24 b0 00 	movapd 0xb0(%rsp),%xmm1
    5207:	00 00 
    5209:	66 0f 59 8c 24 60 0a 	mulpd  0xa60(%rsp),%xmm1
    5210:	00 00 
    5212:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    5216:	66 0f 28 84 24 a0 00 	movapd 0xa0(%rsp),%xmm0
    521d:	00 00 
    521f:	66 0f 59 84 24 70 0a 	mulpd  0xa70(%rsp),%xmm0
    5226:	00 00 
    5228:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    522c:	66 0f 28 94 24 d0 00 	movapd 0xd0(%rsp),%xmm2
    5233:	00 00 
    5235:	66 0f 59 94 24 80 0a 	mulpd  0xa80(%rsp),%xmm2
    523c:	00 00 
    523e:	66 0f 58 d1          	addpd  %xmm1,%xmm2
    5242:	66 0f 28 8c 24 90 00 	movapd 0x90(%rsp),%xmm1
    5249:	00 00 
    524b:	66 0f 59 8c 24 90 0a 	mulpd  0xa90(%rsp),%xmm1
    5252:	00 00 
    5254:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    5258:	66 0f 28 a9 40 02 00 	movapd 0x240(%rcx),%xmm5
    525f:	00 
    5260:	48 83 c0 60          	add    $0x60,%rax
    5264:	48 83 c1 60          	add    $0x60,%rcx
    5268:	66 0f 28 b9 c0 01 00 	movapd 0x1c0(%rcx),%xmm7
    526f:	00 
    5270:	66 0f 28 99 f0 01 00 	movapd 0x1f0(%rcx),%xmm3
    5277:	00 
    5278:	66 0f 28 b1 d0 01 00 	movapd 0x1d0(%rcx),%xmm6
    527f:	00 
    5280:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
    5285:	66 0f 28 e7          	movapd %xmm7,%xmm4
    5289:	66 45 0f 59 fa       	mulpd  %xmm10,%xmm15
    528e:	66 44 0f 28 eb       	movapd %xmm3,%xmm13
    5293:	66 0f 28 c6          	movapd %xmm6,%xmm0
    5297:	66 41 0f 59 e4       	mulpd  %xmm12,%xmm4
    529c:	66 0f 58 60 a0       	addpd  -0x60(%rax),%xmm4
    52a1:	66 45 0f 59 e9       	mulpd  %xmm9,%xmm13
    52a6:	66 41 0f 59 c3       	mulpd  %xmm11,%xmm0
    52ab:	66 0f 58 40 b0       	addpd  -0x50(%rax),%xmm0
    52b0:	66 44 0f 58 fc       	addpd  %xmm4,%xmm15
    52b5:	66 0f 28 a1 00 02 00 	movapd 0x200(%rcx),%xmm4
    52bc:	00 
    52bd:	66 44 0f 28 f4       	movapd %xmm4,%xmm14
    52c2:	66 44 0f 58 e8       	addpd  %xmm0,%xmm13
    52c7:	66 0f 28 81 10 02 00 	movapd 0x210(%rcx),%xmm0
    52ce:	00 
    52cf:	66 45 0f 59 f0       	mulpd  %xmm8,%xmm14
    52d4:	66 45 0f 58 f7       	addpd  %xmm15,%xmm14
    52d9:	66 44 0f 28 bc 24 80 	movapd 0x80(%rsp),%xmm15
    52e0:	00 00 00 
    52e3:	66 44 0f 59 fe       	mulpd  %xmm6,%xmm15
    52e8:	44 0f 29 70 a0       	movaps %xmm14,-0x60(%rax)
    52ed:	66 44 0f 28 74 24 20 	movapd 0x20(%rsp),%xmm14
    52f4:	66 44 0f 58 78 d0    	addpd  -0x30(%rax),%xmm15
    52fa:	66 0f 59 b4 24 c0 00 	mulpd  0xc0(%rsp),%xmm6
    5301:	00 00 
    5303:	66 44 0f 59 f0       	mulpd  %xmm0,%xmm14
    5308:	66 0f 58 70 f0       	addpd  -0x10(%rax),%xmm6
    530d:	66 45 0f 58 f5       	addpd  %xmm13,%xmm14
    5312:	66 44 0f 28 6c 24 10 	movapd 0x10(%rsp),%xmm13
    5319:	66 44 0f 59 ef       	mulpd  %xmm7,%xmm13
    531e:	44 0f 29 70 b0       	movaps %xmm14,-0x50(%rax)
    5323:	66 44 0f 28 74 24 70 	movapd 0x70(%rsp),%xmm14
    532a:	66 44 0f 58 68 c0    	addpd  -0x40(%rax),%xmm13
    5330:	66 0f 59 7c 24 30    	mulpd  0x30(%rsp),%xmm7
    5336:	66 44 0f 59 f5       	mulpd  %xmm5,%xmm14
    533b:	66 0f 58 78 e0       	addpd  -0x20(%rax),%xmm7
    5340:	66 0f 59 ac 24 b0 00 	mulpd  0xb0(%rsp),%xmm5
    5347:	00 00 
    5349:	66 45 0f 58 f5       	addpd  %xmm13,%xmm14
    534e:	66 44 0f 28 6c 24 60 	movapd 0x60(%rsp),%xmm13
    5355:	66 0f 58 ef          	addpd  %xmm7,%xmm5
    5359:	66 44 0f 59 eb       	mulpd  %xmm3,%xmm13
    535e:	66 0f 59 9c 24 a0 00 	mulpd  0xa0(%rsp),%xmm3
    5365:	00 00 
    5367:	66 45 0f 58 ef       	addpd  %xmm15,%xmm13
    536c:	66 44 0f 28 7c 24 50 	movapd 0x50(%rsp),%xmm15
    5373:	66 0f 58 de          	addpd  %xmm6,%xmm3
    5377:	66 44 0f 59 fc       	mulpd  %xmm4,%xmm15
    537c:	66 0f 59 a4 24 d0 00 	mulpd  0xd0(%rsp),%xmm4
    5383:	00 00 
    5385:	66 45 0f 58 fe       	addpd  %xmm14,%xmm15
    538a:	66 44 0f 28 74 24 40 	movapd 0x40(%rsp),%xmm14
    5391:	66 0f 58 e5          	addpd  %xmm5,%xmm4
    5395:	66 44 0f 59 f0       	mulpd  %xmm0,%xmm14
    539a:	66 0f 59 84 24 90 00 	mulpd  0x90(%rsp),%xmm0
    53a1:	00 00 
    53a3:	44 0f 29 78 c0       	movaps %xmm15,-0x40(%rax)
    53a8:	0f 29 60 e0          	movaps %xmm4,-0x20(%rax)
    53ac:	66 45 0f 58 f5       	addpd  %xmm13,%xmm14
    53b1:	66 0f 58 c3          	addpd  %xmm3,%xmm0
    53b5:	44 0f 29 70 d0       	movaps %xmm14,-0x30(%rax)
    53ba:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    53be:	48 39 f0             	cmp    %rsi,%rax
    53c1:	0f 85 91 fe ff ff    	jne    5258 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xa98>
    53c7:	66 0f 59 94 24 20 09 	mulpd  0x920(%rsp),%xmm2
    53ce:	00 00 
    53d0:	49 89 de             	mov    %rbx,%r14
    53d3:	45 31 db             	xor    %r11d,%r11d
    53d6:	66 0f 28 b4 24 a0 0a 	movapd 0xaa0(%rsp),%xmm6
    53dd:	00 00 
    53df:	66 0f 59 8c 24 30 09 	mulpd  0x930(%rsp),%xmm1
    53e6:	00 00 
    53e8:	4c 89 cb             	mov    %r9,%rbx
    53eb:	48 89 f2             	mov    %rsi,%rdx
    53ee:	66 0f 28 bc 24 b0 0a 	movapd 0xab0(%rsp),%xmm7
    53f5:	00 00 
    53f7:	0f 29 b4 24 c0 00 00 	movaps %xmm6,0xc0(%rsp)
    53fe:	00 
    53ff:	66 0f ef e4          	pxor   %xmm4,%xmm4
    5403:	66 44 0f 28 a4 24 00 	movapd 0x900(%rsp),%xmm12
    540a:	09 00 00 
    540d:	66 44 0f 28 9c 24 10 	movapd 0x910(%rsp),%xmm11
    5414:	09 00 00 
    5417:	0f 29 bc 24 d0 00 00 	movaps %xmm7,0xd0(%rsp)
    541e:	00 
    541f:	4c 8d 84 24 c0 07 00 	lea    0x7c0(%rsp),%r8
    5426:	00 
    5427:	49 89 f1             	mov    %rsi,%r9
    542a:	4c 8d a4 24 20 02 00 	lea    0x220(%rsp),%r12
    5431:	00 
    5432:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
    5437:	66 44 0f 28 e9       	movapd %xmm1,%xmm13
    543c:	66 45 0f 28 14 24    	movapd (%r12),%xmm10
    5442:	66 45 0f 28 4c 24 10 	movapd 0x10(%r12),%xmm9
    5449:	48 89 d7             	mov    %rdx,%rdi
    544c:	4c 89 e9             	mov    %r13,%rcx
    544f:	66 45 0f 28 44 24 20 	movapd 0x20(%r12),%xmm8
    5456:	66 41 0f 28 7c 24 30 	movapd 0x30(%r12),%xmm7
    545d:	48 8d 84 24 60 07 00 	lea    0x760(%rsp),%rax
    5464:	00 
    5465:	66 41 0f 28 74 24 40 	movapd 0x40(%r12),%xmm6
    546c:	66 41 0f 28 6c 24 50 	movapd 0x50(%r12),%xmm5
    5473:	66 0f 28 80 20 02 00 	movapd 0x220(%rax),%xmm0
    547a:	00 
    547b:	66 0f 28 98 80 02 00 	movapd 0x280(%rax),%xmm3
    5482:	00 
    5483:	48 83 c0 20          	add    $0x20,%rax
    5487:	48 83 c1 20          	add    $0x20,%rcx
    548b:	66 0f 28 88 10 02 00 	movapd 0x210(%rax),%xmm1
    5492:	00 
    5493:	66 0f 28 90 d0 02 00 	movapd 0x2d0(%rax),%xmm2
    549a:	00 
    549b:	48 83 c7 20          	add    $0x20,%rdi
    549f:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
    54a4:	66 44 0f 28 79 e0    	movapd -0x20(%rcx),%xmm15
    54aa:	66 41 0f 59 d8       	mulpd  %xmm8,%xmm3
    54af:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
    54b4:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
    54b8:	66 45 0f 59 fc       	mulpd  %xmm12,%xmm15
    54bd:	66 0f 58 c4          	addpd  %xmm4,%xmm0
    54c1:	66 0f 58 cc          	addpd  %xmm4,%xmm1
    54c5:	66 0f 58 d8          	addpd  %xmm0,%xmm3
    54c9:	66 0f 28 80 70 02 00 	movapd 0x270(%rax),%xmm0
    54d0:	00 
    54d1:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
    54d5:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    54d9:	66 0f 28 49 f0       	movapd -0x10(%rcx),%xmm1
    54de:	66 41 0f 59 cb       	mulpd  %xmm11,%xmm1
    54e3:	66 0f 58 d0          	addpd  %xmm0,%xmm2
    54e7:	66 42 0f 28 84 18 10 	movapd 0x210(%rax,%r11,1),%xmm0
    54ee:	02 00 00 
    54f1:	66 0f 59 94 24 d0 00 	mulpd  0xd0(%rsp),%xmm2
    54f8:	00 00 
    54fa:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
    54ff:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    5503:	66 42 0f 28 8c 18 00 	movapd 0x200(%rax,%r11,1),%xmm1
    550a:	02 00 00 
    550d:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
    5512:	66 0f 5c c2          	subpd  %xmm2,%xmm0
    5516:	0f 29 47 f0          	movaps %xmm0,-0x10(%rdi)
    551a:	66 41 0f 58 cf       	addpd  %xmm15,%xmm1
    551f:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
    5526:	00 
    5527:	66 44 0f 28 b8 c0 02 	movapd 0x2c0(%rax),%xmm15
    552e:	00 00 
    5530:	66 44 0f 59 fe       	mulpd  %xmm6,%xmm15
    5535:	66 44 0f 58 fb       	addpd  %xmm3,%xmm15
    553a:	66 44 0f 59 bc 24 c0 	mulpd  0xc0(%rsp),%xmm15
    5541:	00 00 00 
    5544:	66 41 0f 5c cf       	subpd  %xmm15,%xmm1
    5549:	0f 29 4f e0          	movaps %xmm1,-0x20(%rdi)
    554d:	0f 29 8c 24 e0 00 00 	movaps %xmm1,0xe0(%rsp)
    5554:	00 
    5555:	4c 39 c0             	cmp    %r8,%rax
    5558:	0f 85 15 ff ff ff    	jne    5473 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xcb3>
    555e:	49 83 c3 60          	add    $0x60,%r11
    5562:	49 83 c5 60          	add    $0x60,%r13
    5566:	48 83 c2 60          	add    $0x60,%rdx
    556a:	49 83 c4 60          	add    $0x60,%r12
    556e:	49 81 fb 20 01 00 00 	cmp    $0x120,%r11
    5575:	0f 85 c1 fe ff ff    	jne    543c <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xc7c>
    557b:	66 44 0f 28 b4 24 60 	movapd 0x760(%rsp),%xmm14
    5582:	07 00 00 
    5585:	31 c0                	xor    %eax,%eax
    5587:	4c 89 d7             	mov    %r10,%rdi
    558a:	66 0f 28 8c 24 60 09 	movapd 0x960(%rsp),%xmm1
    5591:	00 00 
    5593:	b9 30 00 00 00       	mov    $0x30,%ecx
    5598:	4c 89 ce             	mov    %r9,%rsi
    559b:	48 8d 94 24 60 07 00 	lea    0x760(%rsp),%rdx
    55a2:	00 
    55a3:	49 89 d9             	mov    %rbx,%r9
    55a6:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
    55ab:	4c 89 f3             	mov    %r14,%rbx
    55ae:	4c 8d 96 20 01 00 00 	lea    0x120(%rsi),%r10
    55b5:	66 44 0f 28 ac 24 70 	movapd 0x770(%rsp),%xmm13
    55bc:	07 00 00 
    55bf:	66 0f 28 94 24 70 09 	movapd 0x970(%rsp),%xmm2
    55c6:	00 00 
    55c8:	f2 44 0f 10 25 00 00 	movsd  0x0(%rip),%xmm12        # 55d1 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xe11>
    55cf:	00 00 
    55d1:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    55d4:	48 8d 84 24 e0 05 00 	lea    0x5e0(%rsp),%rax
    55db:	00 
    55dc:	31 ff                	xor    %edi,%edi
    55de:	66 41 0f 59 d5       	mulpd  %xmm13,%xmm2
    55e3:	49 89 c3             	mov    %rax,%r11
    55e6:	66 0f 28 c1          	movapd %xmm1,%xmm0
    55ea:	66 0f 28 7a 20       	movapd 0x20(%rdx),%xmm7
    55ef:	66 0f 28 72 50       	movapd 0x50(%rdx),%xmm6
    55f4:	66 41 0f 28 ec       	movapd %xmm12,%xmm5
    55f9:	0f 29 bc 24 b0 00 00 	movaps %xmm7,0xb0(%rsp)
    5600:	00 
    5601:	66 0f 28 7a 30       	movapd 0x30(%rdx),%xmm7
    5606:	0f 29 b4 24 80 00 00 	movaps %xmm6,0x80(%rsp)
    560d:	00 
    560e:	66 0f 28 72 70       	movapd 0x70(%rdx),%xmm6
    5613:	0f 29 bc 24 a0 00 00 	movaps %xmm7,0xa0(%rsp)
    561a:	00 
    561b:	66 0f 28 7a 40       	movapd 0x40(%rdx),%xmm7
    5620:	0f 29 b4 24 c0 00 00 	movaps %xmm6,0xc0(%rsp)
    5627:	00 
    5628:	0f 29 bc 24 90 00 00 	movaps %xmm7,0x90(%rsp)
    562f:	00 
    5630:	66 0f 28 7a 60       	movapd 0x60(%rdx),%xmm7
    5635:	0f 29 bc 24 d0 00 00 	movaps %xmm7,0xd0(%rsp)
    563c:	00 
    563d:	85 ff                	test   %edi,%edi
    563f:	75 08                	jne    5649 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xe89>
    5641:	f2 0f 10 2d 00 00 00 	movsd  0x0(%rip),%xmm5        # 5649 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xe89>
    5648:	00 
    5649:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
    564d:	66 45 0f 28 c4       	movapd %xmm12,%xmm8
    5652:	83 ff 01             	cmp    $0x1,%edi
    5655:	75 09                	jne    5660 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xea0>
    5657:	f2 44 0f 10 05 00 00 	movsd  0x0(%rip),%xmm8        # 5660 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xea0>
    565e:	00 00 
    5660:	66 45 0f 14 c0       	unpcklpd %xmm8,%xmm8
    5665:	66 41 0f 28 fc       	movapd %xmm12,%xmm7
    566a:	83 ff 02             	cmp    $0x2,%edi
    566d:	75 08                	jne    5677 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xeb7>
    566f:	f2 0f 10 3d 00 00 00 	movsd  0x0(%rip),%xmm7        # 5677 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xeb7>
    5676:	00 
    5677:	66 0f 14 ff          	unpcklpd %xmm7,%xmm7
    567b:	66 41 0f 28 f4       	movapd %xmm12,%xmm6
    5680:	83 ff 03             	cmp    $0x3,%edi
    5683:	75 08                	jne    568d <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xecd>
    5685:	f2 0f 10 35 00 00 00 	movsd  0x0(%rip),%xmm6        # 568d <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xecd>
    568c:	00 
    568d:	66 0f 14 f6          	unpcklpd %xmm6,%xmm6
    5691:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
    5696:	4d 89 dc             	mov    %r11,%r12
    5699:	48 89 f1             	mov    %rsi,%rcx
    569c:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
    56a1:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
    56a6:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
    56ab:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
    56b0:	66 44 0f 59 fd       	mulpd  %xmm5,%xmm15
    56b5:	48 8d 94 24 60 04 00 	lea    0x460(%rsp),%rdx
    56bc:	00 
    56bd:	66 45 0f 59 d8       	mulpd  %xmm8,%xmm11
    56c2:	66 44 0f 59 d7       	mulpd  %xmm7,%xmm10
    56c7:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
    56cc:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
    56d0:	66 44 0f 59 c2       	mulpd  %xmm2,%xmm8
    56d5:	66 0f 59 fa          	mulpd  %xmm2,%xmm7
    56d9:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
    56dd:	66 0f 28 19          	movapd (%rcx),%xmm3
    56e1:	48 83 c1 60          	add    $0x60,%rcx
    56e5:	49 83 c4 20          	add    $0x20,%r12
    56e9:	48 83 c2 20          	add    $0x20,%rdx
    56ed:	66 0f 28 41 c0       	movapd -0x40(%rcx),%xmm0
    56f2:	66 0f 28 49 b0       	movapd -0x50(%rcx),%xmm1
    56f7:	66 41 0f 59 de       	mulpd  %xmm14,%xmm3
    56fc:	66 0f 28 a2 a0 00 00 	movapd 0xa0(%rdx),%xmm4
    5703:	00 
    5704:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
    5709:	66 0f 59 84 24 90 00 	mulpd  0x90(%rsp),%xmm0
    5710:	00 00 
    5712:	66 0f 59 9c 24 b0 00 	mulpd  0xb0(%rsp),%xmm3
    5719:	00 00 
    571b:	66 41 0f 58 5c 24 e0 	addpd  -0x20(%r12),%xmm3
    5722:	66 41 0f 59 cd       	mulpd  %xmm13,%xmm1
    5727:	66 0f 59 8c 24 a0 00 	mulpd  0xa0(%rsp),%xmm1
    572e:	00 00 
    5730:	66 41 0f 58 4c 24 f0 	addpd  -0x10(%r12),%xmm1
    5737:	66 41 0f 59 e2       	mulpd  %xmm10,%xmm4
    573c:	66 0f 58 c3          	addpd  %xmm3,%xmm0
    5740:	66 0f 28 59 d0       	movapd -0x30(%rcx),%xmm3
    5745:	66 41 0f 59 dd       	mulpd  %xmm13,%xmm3
    574a:	66 0f 59 9c 24 80 00 	mulpd  0x80(%rsp),%xmm3
    5751:	00 00 
    5753:	66 0f 58 d9          	addpd  %xmm1,%xmm3
    5757:	66 0f 28 49 e0       	movapd -0x20(%rcx),%xmm1
    575c:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
    5761:	66 0f 59 8c 24 d0 00 	mulpd  0xd0(%rsp),%xmm1
    5768:	00 00 
    576a:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    576e:	66 0f 28 42 e0       	movapd -0x20(%rdx),%xmm0
    5773:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
    5778:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    577c:	66 0f 28 41 f0       	movapd -0x10(%rcx),%xmm0
    5781:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
    5786:	66 0f 59 84 24 c0 00 	mulpd  0xc0(%rsp),%xmm0
    578d:	00 00 
    578f:	66 0f 58 c3          	addpd  %xmm3,%xmm0
    5793:	66 0f 28 5a f0       	movapd -0x10(%rdx),%xmm3
    5798:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
    579c:	66 0f 58 c3          	addpd  %xmm3,%xmm0
    57a0:	66 0f 28 5a 40       	movapd 0x40(%rdx),%xmm3
    57a5:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
    57aa:	66 0f 58 cb          	addpd  %xmm3,%xmm1
    57ae:	66 0f 28 5a 50       	movapd 0x50(%rdx),%xmm3
    57b3:	66 41 0f 59 d8       	mulpd  %xmm8,%xmm3
    57b8:	66 0f 58 e1          	addpd  %xmm1,%xmm4
    57bc:	66 0f 28 8a b0 00 00 	movapd 0xb0(%rdx),%xmm1
    57c3:	00 
    57c4:	66 0f 59 cf          	mulpd  %xmm7,%xmm1
    57c8:	66 0f 58 c3          	addpd  %xmm3,%xmm0
    57cc:	66 0f 28 9a 00 01 00 	movapd 0x100(%rdx),%xmm3
    57d3:	00 
    57d4:	66 0f 59 de          	mulpd  %xmm6,%xmm3
    57d8:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    57dc:	66 0f 28 82 10 01 00 	movapd 0x110(%rdx),%xmm0
    57e3:	00 
    57e4:	66 41 0f 59 c1       	mulpd  %xmm9,%xmm0
    57e9:	66 0f 58 dc          	addpd  %xmm4,%xmm3
    57ed:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    57f1:	41 0f 29 5c 24 e0    	movaps %xmm3,-0x20(%r12)
    57f7:	41 0f 29 44 24 f0    	movaps %xmm0,-0x10(%r12)
    57fd:	4c 39 d1             	cmp    %r10,%rcx
    5800:	0f 85 d7 fe ff ff    	jne    56dd <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xf1d>
    5806:	83 c7 01             	add    $0x1,%edi
    5809:	66 0f 28 44 24 70    	movapd 0x70(%rsp),%xmm0
    580f:	49 83 c3 60          	add    $0x60,%r11
    5813:	4c 89 c2             	mov    %r8,%rdx
    5816:	83 ff 04             	cmp    $0x4,%edi
    5819:	0f 84 b6 00 00 00    	je     58d5 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1115>
    581f:	49 83 c0 60          	add    $0x60,%r8
    5823:	e9 c2 fd ff ff       	jmp    55ea <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0xe2a>
    5828:	f2 0f 10 06          	movsd  (%rsi),%xmm0
    582c:	48 83 c7 01          	add    $0x1,%rdi
    5830:	f2 0f 11 01          	movsd  %xmm0,(%rcx)
    5834:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    5839:	f2 0f 11 41 20       	movsd  %xmm0,0x20(%rcx)
    583e:	f2 0f 10 46 10       	movsd  0x10(%rsi),%xmm0
    5843:	f2 0f 11 41 40       	movsd  %xmm0,0x40(%rcx)
    5848:	f2 0f 10 46 18       	movsd  0x18(%rsi),%xmm0
    584d:	f2 0f 11 41 60       	movsd  %xmm0,0x60(%rcx)
    5852:	f2 0f 10 46 20       	movsd  0x20(%rsi),%xmm0
    5857:	f2 0f 11 81 80 00 00 	movsd  %xmm0,0x80(%rcx)
    585e:	00 
    585f:	f2 0f 10 46 28       	movsd  0x28(%rsi),%xmm0
    5864:	f2 0f 11 81 a0 00 00 	movsd  %xmm0,0xa0(%rcx)
    586b:	00 
    586c:	f2 0f 10 46 30       	movsd  0x30(%rsi),%xmm0
    5871:	f2 0f 11 81 c0 00 00 	movsd  %xmm0,0xc0(%rcx)
    5878:	00 
    5879:	f2 0f 10 46 38       	movsd  0x38(%rsi),%xmm0
    587e:	f2 0f 11 81 e0 00 00 	movsd  %xmm0,0xe0(%rcx)
    5885:	00 
    5886:	f2 0f 10 46 40       	movsd  0x40(%rsi),%xmm0
    588b:	f2 0f 11 81 00 01 00 	movsd  %xmm0,0x100(%rcx)
    5892:	00 
    5893:	f2 0f 10 46 48       	movsd  0x48(%rsi),%xmm0
    5898:	f2 0f 11 81 20 01 00 	movsd  %xmm0,0x120(%rcx)
    589f:	00 
    58a0:	f2 0f 10 46 50       	movsd  0x50(%rsi),%xmm0
    58a5:	f2 0f 11 81 40 01 00 	movsd  %xmm0,0x140(%rcx)
    58ac:	00 
    58ad:	f2 0f 10 46 58       	movsd  0x58(%rsi),%xmm0
    58b2:	f2 0f 11 81 60 01 00 	movsd  %xmm0,0x160(%rcx)
    58b9:	00 
    58ba:	48 83 ff 04          	cmp    $0x4,%rdi
    58be:	0f 84 cc f4 ff ff    	je     4d90 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x5d0>
    58c4:	48 83 c0 08          	add    $0x8,%rax
    58c8:	48 83 c1 08          	add    $0x8,%rcx
    58cc:	48 83 c6 60          	add    $0x60,%rsi
    58d0:	e9 34 f3 ff ff       	jmp    4c09 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x449>
    58d5:	f2 0f 10 05 00 00 00 	movsd  0x0(%rip),%xmm0        # 58dd <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x111d>
    58dc:	00 
    58dd:	48 89 da             	mov    %rbx,%rdx
    58e0:	49 01 c1             	add    %rax,%r9
    58e3:	f2 0f 10 08          	movsd  (%rax),%xmm1
    58e7:	f2 44 0f 10 60 20    	movsd  0x20(%rax),%xmm12
    58ed:	f2 44 0f 10 58 40    	movsd  0x40(%rax),%xmm11
    58f3:	f2 44 0f 10 50 60    	movsd  0x60(%rax),%xmm10
    58f9:	66 44 0f 28 e9       	movapd %xmm1,%xmm13
    58fe:	f2 0f 10 b8 c0 00 00 	movsd  0xc0(%rax),%xmm7
    5905:	00 
    5906:	f2 44 0f 10 88 80 00 	movsd  0x80(%rax),%xmm9
    590d:	00 00 
    590f:	66 45 0f 14 ec       	unpcklpd %xmm12,%xmm13
    5914:	f2 0f 10 b0 e0 00 00 	movsd  0xe0(%rax),%xmm6
    591b:	00 
    591c:	f2 44 0f 10 80 a0 00 	movsd  0xa0(%rax),%xmm8
    5923:	00 00 
    5925:	44 0f 11 2a          	movups %xmm13,(%rdx)
    5929:	66 45 0f 28 eb       	movapd %xmm11,%xmm13
    592e:	f2 0f 10 a8 00 01 00 	movsd  0x100(%rax),%xmm5
    5935:	00 
    5936:	f2 0f 10 a0 20 01 00 	movsd  0x120(%rax),%xmm4
    593d:	00 
    593e:	66 45 0f 14 ea       	unpcklpd %xmm10,%xmm13
    5943:	66 0f 54 0d 00 00 00 	andpd  0x0(%rip),%xmm1        # 594b <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x118b>
    594a:	00 
    594b:	f2 0f 10 98 40 01 00 	movsd  0x140(%rax),%xmm3
    5952:	00 
    5953:	44 0f 11 6a 10       	movups %xmm13,0x10(%rdx)
    5958:	66 45 0f 28 e9       	movapd %xmm9,%xmm13
    595d:	f2 0f 10 90 60 01 00 	movsd  0x160(%rax),%xmm2
    5964:	00 
    5965:	66 45 0f 14 e8       	unpcklpd %xmm8,%xmm13
    596a:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    596e:	44 0f 11 6a 20       	movups %xmm13,0x20(%rdx)
    5973:	66 44 0f 28 ef       	movapd %xmm7,%xmm13
    5978:	66 44 0f 14 ee       	unpcklpd %xmm6,%xmm13
    597d:	44 0f 11 6a 30       	movups %xmm13,0x30(%rdx)
    5982:	66 44 0f 28 ed       	movapd %xmm5,%xmm13
    5987:	66 44 0f 14 ec       	unpcklpd %xmm4,%xmm13
    598c:	44 0f 11 6a 40       	movups %xmm13,0x40(%rdx)
    5991:	66 44 0f 28 eb       	movapd %xmm3,%xmm13
    5996:	66 44 0f 14 ea       	unpcklpd %xmm2,%xmm13
    599b:	44 0f 11 6a 50       	movups %xmm13,0x50(%rdx)
    59a0:	0f 82 fb 00 00 00    	jb     5aa1 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x12e1>
    59a6:	66 44 0f 54 25 00 00 	andpd  0x0(%rip),%xmm12        # 59af <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x11ef>
    59ad:	00 00 
    59af:	66 41 0f 2e c4       	ucomisd %xmm12,%xmm0
    59b4:	0f 82 00 00 00 00    	jb     59ba <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x11fa>
    59ba:	66 44 0f 54 1d 00 00 	andpd  0x0(%rip),%xmm11        # 59c3 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1203>
    59c1:	00 00 
    59c3:	66 41 0f 2e c3       	ucomisd %xmm11,%xmm0
    59c8:	0f 82 00 00 00 00    	jb     59ce <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x120e>
    59ce:	66 44 0f 54 15 00 00 	andpd  0x0(%rip),%xmm10        # 59d7 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1217>
    59d5:	00 00 
    59d7:	66 41 0f 2e c2       	ucomisd %xmm10,%xmm0
    59dc:	0f 82 00 00 00 00    	jb     59e2 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1222>
    59e2:	66 44 0f 54 0d 00 00 	andpd  0x0(%rip),%xmm9        # 59eb <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x122b>
    59e9:	00 00 
    59eb:	66 41 0f 2e c1       	ucomisd %xmm9,%xmm0
    59f0:	0f 82 00 00 00 00    	jb     59f6 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1236>
    59f6:	66 44 0f 54 05 00 00 	andpd  0x0(%rip),%xmm8        # 59ff <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x123f>
    59fd:	00 00 
    59ff:	66 41 0f 2e c0       	ucomisd %xmm8,%xmm0
    5a04:	0f 82 00 00 00 00    	jb     5a0a <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x124a>
    5a0a:	66 0f 54 3d 00 00 00 	andpd  0x0(%rip),%xmm7        # 5a12 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1252>
    5a11:	00 
    5a12:	66 0f 2e c7          	ucomisd %xmm7,%xmm0
    5a16:	0f 82 00 00 00 00    	jb     5a1c <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x125c>
    5a1c:	66 0f 54 35 00 00 00 	andpd  0x0(%rip),%xmm6        # 5a24 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1264>
    5a23:	00 
    5a24:	66 0f 2e c6          	ucomisd %xmm6,%xmm0
    5a28:	0f 82 00 00 00 00    	jb     5a2e <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x126e>
    5a2e:	66 0f 54 2d 00 00 00 	andpd  0x0(%rip),%xmm5        # 5a36 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1276>
    5a35:	00 
    5a36:	66 0f 2e c5          	ucomisd %xmm5,%xmm0
    5a3a:	0f 82 00 00 00 00    	jb     5a40 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1280>
    5a40:	66 0f 54 25 00 00 00 	andpd  0x0(%rip),%xmm4        # 5a48 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1288>
    5a47:	00 
    5a48:	66 0f 2e c4          	ucomisd %xmm4,%xmm0
    5a4c:	0f 82 00 00 00 00    	jb     5a52 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1292>
    5a52:	66 0f 54 1d 00 00 00 	andpd  0x0(%rip),%xmm3        # 5a5a <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x129a>
    5a59:	00 
    5a5a:	66 0f 2e c3          	ucomisd %xmm3,%xmm0
    5a5e:	0f 82 00 00 00 00    	jb     5a64 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x12a4>
    5a64:	66 0f 54 15 00 00 00 	andpd  0x0(%rip),%xmm2        # 5a6c <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x12ac>
    5a6b:	00 
    5a6c:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    5a70:	0f 82 00 00 00 00    	jb     5a76 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x12b6>
    5a76:	48 83 c0 08          	add    $0x8,%rax
    5a7a:	48 83 c2 60          	add    $0x60,%rdx
    5a7e:	49 39 c1             	cmp    %rax,%r9
    5a81:	0f 85 5c fe ff ff    	jne    58e3 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x1123>
    5a87:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5a8b:	5b                   	pop    %rbx
    5a8c:	41 5c                	pop    %r12
    5a8e:	41 5d                	pop    %r13
    5a90:	41 5e                	pop    %r14
    5a92:	41 5f                	pop    %r15
    5a94:	5d                   	pop    %rbp
    5a95:	c3                   	ret
    5a96:	41 b9 20 00 00 00    	mov    $0x20,%r9d
    5a9c:	e9 ef f2 ff ff       	jmp    4d90 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x5d0>
    5aa1:	e9 00 00 00 00       	jmp    5aa6 <eonsim::solid_element_action_batch(eonsim::SolidElementLinearization const* const*, std::array<double, 12ul> const*, std::array<double, 12ul>*, unsigned long)+0x12e6>
    5aa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5aad:	00 00 00 

