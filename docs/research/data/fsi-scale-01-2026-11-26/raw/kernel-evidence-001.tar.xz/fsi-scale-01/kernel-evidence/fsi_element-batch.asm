0000000000009860 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)>:
    9860:	55                   	push   %rbp
    9861:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
    9865:	48 89 e5             	mov    %rsp,%rbp
    9868:	41 57                	push   %r15
    986a:	41 56                	push   %r14
    986c:	41 55                	push   %r13
    986e:	41 54                	push   %r12
    9870:	53                   	push   %rbx
    9871:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
    9875:	48 81 ec 00 25 00 00 	sub    $0x2500,%rsp
    987c:	48 89 b4 24 10 01 00 	mov    %rsi,0x110(%rsp)
    9883:	00 
    9884:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    9889:	48 83 f8 03          	cmp    $0x3,%rax
    988d:	0f 87 00 00 00 00    	ja     9893 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x33>
    9893:	31 c0                	xor    %eax,%eax
    9895:	49 89 fc             	mov    %rdi,%r12
    9898:	48 89 cb             	mov    %rcx,%rbx
    989b:	b9 10 02 00 00       	mov    $0x210,%ecx
    98a0:	48 8d bc 24 80 14 00 	lea    0x1480(%rsp),%rdi
    98a7:	00 
    98a8:	49 89 f0             	mov    %rsi,%r8
    98ab:	45 31 c9             	xor    %r9d,%r9d
    98ae:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    98b1:	b9 70 00 00 00       	mov    $0x70,%ecx
    98b6:	48 8d bc 24 80 0d 00 	lea    0xd80(%rsp),%rdi
    98bd:	00 
    98be:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    98c1:	48 8d 84 24 00 11 00 	lea    0x1100(%rsp),%rax
    98c8:	00 
    98c9:	48 8d 8c 24 80 14 00 	lea    0x1480(%rsp),%rcx
    98d0:	00 
    98d1:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
    98d8:	00 
    98d9:	48 89 c7             	mov    %rax,%rdi
    98dc:	4b 8b 34 cc          	mov    (%r12,%r9,8),%rsi
    98e0:	31 c0                	xor    %eax,%eax
    98e2:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    98e9:	00 
    98ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    98f1:	00 00 00 00 
    98f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    98fc:	00 00 00 00 
    9900:	48 8d 14 06          	lea    (%rsi,%rax,1),%rdx
    9904:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    9909:	f2 0f 10 0a          	movsd  (%rdx),%xmm1
    990d:	f2 0f 11 44 81 20    	movsd  %xmm0,0x20(%rcx,%rax,4)
    9913:	f2 0f 11 0c 81       	movsd  %xmm1,(%rcx,%rax,4)
    9918:	48 83 c0 10          	add    $0x10,%rax
    991c:	48 3d 20 04 00 00    	cmp    $0x420,%rax
    9922:	75 dc                	jne    9900 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xa0>
    9924:	49 39 d9             	cmp    %rbx,%r9
    9927:	0f 82 49 23 00 00    	jb     bc76 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x2416>
    992d:	48 8d 87 80 fc ff ff 	lea    -0x380(%rdi),%rax
    9934:	90                   	nop
    9935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    993c:	00 00 00 00 
    9940:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9947:	48 83 c0 40          	add    $0x40,%rax
    994b:	48 c7 40 e0 00 00 00 	movq   $0x0,-0x20(%rax)
    9952:	00 
    9953:	48 39 f8             	cmp    %rdi,%rax
    9956:	75 e8                	jne    9940 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xe0>
    9958:	49 83 c1 01          	add    $0x1,%r9
    995c:	49 81 c0 e0 00 00 00 	add    $0xe0,%r8
    9963:	48 83 c7 08          	add    $0x8,%rdi
    9967:	48 83 c1 08          	add    $0x8,%rcx
    996b:	49 39 d9             	cmp    %rbx,%r9
    996e:	0f 82 68 ff ff ff    	jb     98dc <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x7c>
    9974:	48 83 fb 04          	cmp    $0x4,%rbx
    9978:	0f 84 2b 02 00 00    	je     9ba9 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x349>
    997e:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    9985:	00 
    9986:	49 8b 34 24          	mov    (%r12),%rsi
    998a:	49 89 d9             	mov    %rbx,%r9
    998d:	4c 69 c3 e0 00 00 00 	imul   $0xe0,%rbx,%r8
    9994:	48 8d 8c 3c 80 14 00 	lea    0x1480(%rsp,%rdi,1),%rcx
    999b:	00 
    999c:	4c 03 84 24 10 01 00 	add    0x110(%rsp),%r8
    99a3:	00 
    99a4:	48 03 bc 24 b0 01 00 	add    0x1b0(%rsp),%rdi
    99ab:	00 
    99ac:	31 c0                	xor    %eax,%eax
    99ae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    99b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    99bc:	00 00 00 00 
    99c0:	48 8d 14 06          	lea    (%rsi,%rax,1),%rdx
    99c4:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    99c9:	f2 0f 10 0a          	movsd  (%rdx),%xmm1
    99cd:	f2 0f 11 44 81 20    	movsd  %xmm0,0x20(%rcx,%rax,4)
    99d3:	f2 0f 11 0c 81       	movsd  %xmm1,(%rcx,%rax,4)
    99d8:	48 83 c0 10          	add    $0x10,%rax
    99dc:	48 3d 20 04 00 00    	cmp    $0x420,%rax
    99e2:	75 dc                	jne    99c0 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x160>
    99e4:	49 39 d9             	cmp    %rbx,%r9
    99e7:	0f 83 2d 24 00 00    	jae    be1a <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x25ba>
    99ed:	f2 41 0f 10 40 08    	movsd  0x8(%r8),%xmm0
    99f3:	f2 41 0f 10 08       	movsd  (%r8),%xmm1
    99f8:	f2 0f 11 87 a0 fc ff 	movsd  %xmm0,-0x360(%rdi)
    99ff:	ff 
    9a00:	f2 0f 11 8f 80 fc ff 	movsd  %xmm1,-0x380(%rdi)
    9a07:	ff 
    9a08:	f2 41 0f 10 40 18    	movsd  0x18(%r8),%xmm0
    9a0e:	f2 41 0f 10 48 10    	movsd  0x10(%r8),%xmm1
    9a14:	f2 0f 11 87 e0 fc ff 	movsd  %xmm0,-0x320(%rdi)
    9a1b:	ff 
    9a1c:	f2 0f 11 8f c0 fc ff 	movsd  %xmm1,-0x340(%rdi)
    9a23:	ff 
    9a24:	f2 41 0f 10 40 28    	movsd  0x28(%r8),%xmm0
    9a2a:	f2 41 0f 10 48 20    	movsd  0x20(%r8),%xmm1
    9a30:	f2 0f 11 87 20 fd ff 	movsd  %xmm0,-0x2e0(%rdi)
    9a37:	ff 
    9a38:	f2 0f 11 8f 00 fd ff 	movsd  %xmm1,-0x300(%rdi)
    9a3f:	ff 
    9a40:	f2 41 0f 10 40 38    	movsd  0x38(%r8),%xmm0
    9a46:	f2 41 0f 10 48 30    	movsd  0x30(%r8),%xmm1
    9a4c:	f2 0f 11 87 60 fd ff 	movsd  %xmm0,-0x2a0(%rdi)
    9a53:	ff 
    9a54:	f2 0f 11 8f 40 fd ff 	movsd  %xmm1,-0x2c0(%rdi)
    9a5b:	ff 
    9a5c:	f2 41 0f 10 40 48    	movsd  0x48(%r8),%xmm0
    9a62:	f2 41 0f 10 48 40    	movsd  0x40(%r8),%xmm1
    9a68:	f2 0f 11 87 a0 fd ff 	movsd  %xmm0,-0x260(%rdi)
    9a6f:	ff 
    9a70:	f2 0f 11 8f 80 fd ff 	movsd  %xmm1,-0x280(%rdi)
    9a77:	ff 
    9a78:	f2 41 0f 10 40 58    	movsd  0x58(%r8),%xmm0
    9a7e:	f2 41 0f 10 48 50    	movsd  0x50(%r8),%xmm1
    9a84:	f2 0f 11 87 e0 fd ff 	movsd  %xmm0,-0x220(%rdi)
    9a8b:	ff 
    9a8c:	f2 0f 11 8f c0 fd ff 	movsd  %xmm1,-0x240(%rdi)
    9a93:	ff 
    9a94:	f2 41 0f 10 40 68    	movsd  0x68(%r8),%xmm0
    9a9a:	f2 41 0f 10 48 60    	movsd  0x60(%r8),%xmm1
    9aa0:	f2 0f 11 87 20 fe ff 	movsd  %xmm0,-0x1e0(%rdi)
    9aa7:	ff 
    9aa8:	f2 0f 11 8f 00 fe ff 	movsd  %xmm1,-0x200(%rdi)
    9aaf:	ff 
    9ab0:	f2 41 0f 10 48 70    	movsd  0x70(%r8),%xmm1
    9ab6:	f2 41 0f 10 40 78    	movsd  0x78(%r8),%xmm0
    9abc:	f2 0f 11 8f 40 fe ff 	movsd  %xmm1,-0x1c0(%rdi)
    9ac3:	ff 
    9ac4:	f2 0f 11 87 60 fe ff 	movsd  %xmm0,-0x1a0(%rdi)
    9acb:	ff 
    9acc:	f2 41 0f 10 80 88 00 	movsd  0x88(%r8),%xmm0
    9ad3:	00 00 
    9ad5:	f2 41 0f 10 88 80 00 	movsd  0x80(%r8),%xmm1
    9adc:	00 00 
    9ade:	f2 0f 11 87 a0 fe ff 	movsd  %xmm0,-0x160(%rdi)
    9ae5:	ff 
    9ae6:	f2 0f 11 8f 80 fe ff 	movsd  %xmm1,-0x180(%rdi)
    9aed:	ff 
    9aee:	f2 41 0f 10 80 98 00 	movsd  0x98(%r8),%xmm0
    9af5:	00 00 
    9af7:	f2 41 0f 10 88 90 00 	movsd  0x90(%r8),%xmm1
    9afe:	00 00 
    9b00:	f2 0f 11 87 e0 fe ff 	movsd  %xmm0,-0x120(%rdi)
    9b07:	ff 
    9b08:	f2 0f 11 8f c0 fe ff 	movsd  %xmm1,-0x140(%rdi)
    9b0f:	ff 
    9b10:	f2 41 0f 10 80 a8 00 	movsd  0xa8(%r8),%xmm0
    9b17:	00 00 
    9b19:	f2 41 0f 10 88 a0 00 	movsd  0xa0(%r8),%xmm1
    9b20:	00 00 
    9b22:	f2 0f 11 87 20 ff ff 	movsd  %xmm0,-0xe0(%rdi)
    9b29:	ff 
    9b2a:	f2 0f 11 8f 00 ff ff 	movsd  %xmm1,-0x100(%rdi)
    9b31:	ff 
    9b32:	f2 41 0f 10 80 b8 00 	movsd  0xb8(%r8),%xmm0
    9b39:	00 00 
    9b3b:	f2 41 0f 10 88 b0 00 	movsd  0xb0(%r8),%xmm1
    9b42:	00 00 
    9b44:	f2 0f 11 87 60 ff ff 	movsd  %xmm0,-0xa0(%rdi)
    9b4b:	ff 
    9b4c:	f2 0f 11 8f 40 ff ff 	movsd  %xmm1,-0xc0(%rdi)
    9b53:	ff 
    9b54:	f2 41 0f 10 80 c8 00 	movsd  0xc8(%r8),%xmm0
    9b5b:	00 00 
    9b5d:	f2 41 0f 10 88 c0 00 	movsd  0xc0(%r8),%xmm1
    9b64:	00 00 
    9b66:	f2 0f 11 47 a0       	movsd  %xmm0,-0x60(%rdi)
    9b6b:	f2 0f 11 4f 80       	movsd  %xmm1,-0x80(%rdi)
    9b70:	f2 41 0f 10 80 d8 00 	movsd  0xd8(%r8),%xmm0
    9b77:	00 00 
    9b79:	f2 41 0f 10 88 d0 00 	movsd  0xd0(%r8),%xmm1
    9b80:	00 00 
    9b82:	f2 0f 11 47 e0       	movsd  %xmm0,-0x20(%rdi)
    9b87:	f2 0f 11 4f c0       	movsd  %xmm1,-0x40(%rdi)
    9b8c:	49 83 c1 01          	add    $0x1,%r9
    9b90:	49 81 c0 e0 00 00 00 	add    $0xe0,%r8
    9b97:	48 83 c1 08          	add    $0x8,%rcx
    9b9b:	48 83 c7 08          	add    $0x8,%rdi
    9b9f:	49 83 f9 04          	cmp    $0x4,%r9
    9ba3:	0f 85 03 fe ff ff    	jne    99ac <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x14c>
    9ba9:	4c 8d 84 24 80 07 00 	lea    0x780(%rsp),%r8
    9bb0:	00 
    9bb1:	31 c0                	xor    %eax,%eax
    9bb3:	45 31 ed             	xor    %r13d,%r13d
    9bb6:	45 31 ff             	xor    %r15d,%r15d
    9bb9:	b9 30 00 00 00       	mov    $0x30,%ecx
    9bbe:	4c 89 c7             	mov    %r8,%rdi
    9bc1:	48 8d 94 24 00 09 00 	lea    0x900(%rsp),%rdx
    9bc8:	00 
    9bc9:	66 44 0f 28 a4 24 80 	movapd 0x1480(%rsp),%xmm12
    9bd0:	14 00 00 
    9bd3:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    9bd6:	b9 30 00 00 00       	mov    $0x30,%ecx
    9bdb:	48 89 d7             	mov    %rdx,%rdi
    9bde:	66 44 0f 28 ac 24 90 	movapd 0x1490(%rsp),%xmm13
    9be5:	14 00 00 
    9be8:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    9beb:	48 8d bc 24 80 0a 00 	lea    0xa80(%rsp),%rdi
    9bf2:	00 
    9bf3:	b9 30 00 00 00       	mov    $0x30,%ecx
    9bf8:	66 45 0f ef db       	pxor   %xmm11,%xmm11
    9bfd:	48 89 bc 24 80 01 00 	mov    %rdi,0x180(%rsp)
    9c04:	00 
    9c05:	4c 8d b4 24 80 0d 00 	lea    0xd80(%rsp),%r14
    9c0c:	00 
    9c0d:	66 45 0f 28 d3       	movapd %xmm11,%xmm10
    9c12:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    9c15:	b9 24 00 00 00       	mov    $0x24,%ecx
    9c1a:	48 8d bc 24 40 05 00 	lea    0x540(%rsp),%rdi
    9c21:	00 
    9c22:	44 0f 29 a4 24 a0 02 	movaps %xmm12,0x2a0(%rsp)
    9c29:	00 00 
    9c2b:	48 89 bc 24 e0 01 00 	mov    %rdi,0x1e0(%rsp)
    9c32:	00 
    9c33:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    9c36:	b9 24 00 00 00       	mov    $0x24,%ecx
    9c3b:	48 8d bc 24 60 06 00 	lea    0x660(%rsp),%rdi
    9c42:	00 
    9c43:	44 0f 29 ac 24 b0 02 	movaps %xmm13,0x2b0(%rsp)
    9c4a:	00 00 
    9c4c:	48 89 bc 24 18 01 00 	mov    %rdi,0x118(%rsp)
    9c53:	00 
    9c54:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    9c57:	48 8d bc 24 c0 03 00 	lea    0x3c0(%rsp),%rdi
    9c5e:	00 
    9c5f:	b9 0c 00 00 00       	mov    $0xc,%ecx
    9c64:	48 89 bc 24 90 01 00 	mov    %rdi,0x190(%rsp)
    9c6b:	00 
    9c6c:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    9c6f:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
    9c76:	00 
    9c77:	b9 0c 00 00 00       	mov    $0xc,%ecx
    9c7c:	48 89 bc 24 a0 01 00 	mov    %rdi,0x1a0(%rsp)
    9c83:	00 
    9c84:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    9c87:	48 8d 84 24 80 14 00 	lea    0x1480(%rsp),%rax
    9c8e:	00 
    9c8f:	66 0f 28 78 40       	movapd 0x40(%rax),%xmm7
    9c94:	66 0f 28 70 50       	movapd 0x50(%rax),%xmm6
    9c99:	4d 89 f2             	mov    %r14,%r10
    9c9c:	45 31 db             	xor    %r11d,%r11d
    9c9f:	48 89 84 24 90 02 00 	mov    %rax,0x290(%rsp)
    9ca6:	00 
    9ca7:	66 44 0f 28 48 20    	movapd 0x20(%rax),%xmm9
    9cad:	4c 8d 8c 24 80 14 00 	lea    0x1480(%rsp),%r9
    9cb4:	00 
    9cb5:	66 44 0f 28 40 30    	movapd 0x30(%rax),%xmm8
    9cbb:	66 0f 28 68 60       	movapd 0x60(%rax),%xmm5
    9cc0:	66 0f 28 60 70       	movapd 0x70(%rax),%xmm4
    9cc5:	66 43 0f 28 44 29 20 	movapd 0x20(%r9,%r13,1),%xmm0
    9ccc:	4c 89 c6             	mov    %r8,%rsi
    9ccf:	4c 89 c0             	mov    %r8,%rax
    9cd2:	4c 89 cf             	mov    %r9,%rdi
    9cd5:	66 41 0f 6f 9a 80 00 	movdqa 0x80(%r10),%xmm3
    9cdc:	00 00 
    9cde:	66 41 0f 6f 92 90 00 	movdqa 0x90(%r10),%xmm2
    9ce5:	00 00 
    9ce7:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    9cec:	0f 29 9c 24 00 11 00 	movaps %xmm3,0x1100(%rsp)
    9cf3:	00 
    9cf4:	0f 29 94 24 10 11 00 	movaps %xmm2,0x1110(%rsp)
    9cfb:	00 
    9cfc:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
    9d00:	66 44 0f 58 d0       	addpd  %xmm0,%xmm10
    9d05:	66 43 0f 28 44 29 30 	movapd 0x30(%r9,%r13,1),%xmm0
    9d0c:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
    9d11:	66 0f 59 c2          	mulpd  %xmm2,%xmm0
    9d15:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
    9d1a:	66 0f 28 4f 20       	movapd 0x20(%rdi),%xmm1
    9d1f:	66 0f 28 47 30       	movapd 0x30(%rdi),%xmm0
    9d24:	48 83 c0 60          	add    $0x60,%rax
    9d28:	48 83 c7 60          	add    $0x60,%rdi
    9d2c:	66 44 0f 28 70 a0    	movapd -0x60(%rax),%xmm14
    9d32:	66 44 0f 28 f9       	movapd %xmm1,%xmm15
    9d37:	66 45 0f 59 f9       	mulpd  %xmm9,%xmm15
    9d3c:	66 44 0f 59 fb       	mulpd  %xmm3,%xmm15
    9d41:	66 45 0f 5c f7       	subpd  %xmm15,%xmm14
    9d46:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
    9d4b:	66 45 0f 59 f8       	mulpd  %xmm8,%xmm15
    9d50:	44 0f 29 70 a0       	movaps %xmm14,-0x60(%rax)
    9d55:	66 44 0f 28 70 b0    	movapd -0x50(%rax),%xmm14
    9d5b:	66 44 0f 59 fa       	mulpd  %xmm2,%xmm15
    9d60:	66 45 0f 5c f7       	subpd  %xmm15,%xmm14
    9d65:	66 44 0f 28 f9       	movapd %xmm1,%xmm15
    9d6a:	66 44 0f 59 ff       	mulpd  %xmm7,%xmm15
    9d6f:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
    9d73:	44 0f 29 70 b0       	movaps %xmm14,-0x50(%rax)
    9d78:	66 44 0f 28 70 c0    	movapd -0x40(%rax),%xmm14
    9d7e:	66 44 0f 59 fb       	mulpd  %xmm3,%xmm15
    9d83:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
    9d87:	66 45 0f 5c f7       	subpd  %xmm15,%xmm14
    9d8c:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
    9d91:	66 44 0f 59 fe       	mulpd  %xmm6,%xmm15
    9d96:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
    9d9a:	44 0f 29 70 c0       	movaps %xmm14,-0x40(%rax)
    9d9f:	66 44 0f 28 70 d0    	movapd -0x30(%rax),%xmm14
    9da5:	66 44 0f 59 fa       	mulpd  %xmm2,%xmm15
    9daa:	66 0f 59 c2          	mulpd  %xmm2,%xmm0
    9dae:	66 45 0f 5c f7       	subpd  %xmm15,%xmm14
    9db3:	44 0f 29 70 d0       	movaps %xmm14,-0x30(%rax)
    9db8:	66 44 0f 28 70 e0    	movapd -0x20(%rax),%xmm14
    9dbe:	66 44 0f 5c f1       	subpd  %xmm1,%xmm14
    9dc3:	66 0f 28 48 f0       	movapd -0x10(%rax),%xmm1
    9dc8:	66 0f 5c c8          	subpd  %xmm0,%xmm1
    9dcc:	44 0f 29 70 e0       	movaps %xmm14,-0x20(%rax)
    9dd1:	0f 29 48 f0          	movaps %xmm1,-0x10(%rax)
    9dd5:	48 39 c2             	cmp    %rax,%rdx
    9dd8:	0f 85 3c ff ff ff    	jne    9d1a <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x4ba>
    9dde:	49 83 c3 01          	add    $0x1,%r11
    9de2:	49 83 c2 20          	add    $0x20,%r10
    9de6:	49 83 c1 20          	add    $0x20,%r9
    9dea:	49 83 fb 03          	cmp    $0x3,%r11
    9dee:	0f 85 d1 fe ff ff    	jne    9cc5 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x465>
    9df4:	48 8b 84 24 90 02 00 	mov    0x290(%rsp),%rax
    9dfb:	00 
    9dfc:	49 83 c7 03          	add    $0x3,%r15
    9e00:	49 81 c6 e0 00 00 00 	add    $0xe0,%r14
    9e07:	49 83 c5 60          	add    $0x60,%r13
    9e0b:	48 83 c0 60          	add    $0x60,%rax
    9e0f:	49 83 ff 0c          	cmp    $0xc,%r15
    9e13:	0f 85 76 fe ff ff    	jne    9c8f <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x42f>
    9e19:	66 0f 28 b4 24 00 1f 	movapd 0x1f00(%rsp),%xmm6
    9e20:	00 00 
    9e22:	48 89 b4 24 60 01 00 	mov    %rsi,0x160(%rsp)
    9e29:	00 
    9e2a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9e2e:	4c 8d 9c 24 80 0d 00 	lea    0xd80(%rsp),%r11
    9e35:	00 
    9e36:	f2 44 0f 10 25 00 00 	movsd  0x0(%rip),%xmm12        # 9e3f <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x5df>
    9e3d:	00 00 
    9e3f:	4d 89 dd             	mov    %r11,%r13
    9e42:	44 0f 29 94 24 c0 02 	movaps %xmm10,0x2c0(%rsp)
    9e49:	00 00 
    9e4b:	4c 8d b4 24 80 14 00 	lea    0x1480(%rsp),%r14
    9e52:	00 
    9e53:	0f 29 b4 24 f0 01 00 	movaps %xmm6,0x1f0(%rsp)
    9e5a:	00 
    9e5b:	66 0f 28 d1          	movapd %xmm1,%xmm2
    9e5f:	66 0f 28 b4 24 10 1f 	movapd 0x1f10(%rsp),%xmm6
    9e66:	00 00 
    9e68:	66 44 0f 28 ac 24 60 	movapd 0x1f60(%rsp),%xmm13
    9e6f:	1f 00 00 
    9e72:	66 44 0f 28 94 24 70 	movapd 0x1f70(%rsp),%xmm10
    9e79:	1f 00 00 
    9e7c:	48 89 94 24 70 01 00 	mov    %rdx,0x170(%rsp)
    9e83:	00 
    9e84:	66 45 0f 14 e4       	unpcklpd %xmm12,%xmm12
    9e89:	4c 8d bc 24 a0 05 00 	lea    0x5a0(%rsp),%r15
    9e90:	00 
    9e91:	4c 89 9c 24 50 01 00 	mov    %r11,0x150(%rsp)
    9e98:	00 
    9e99:	49 89 d3             	mov    %rdx,%r11
    9e9c:	48 89 94 24 40 01 00 	mov    %rdx,0x140(%rsp)
    9ea3:	00 
    9ea4:	4c 89 c2             	mov    %r8,%rdx
    9ea7:	4c 89 84 24 30 01 00 	mov    %r8,0x130(%rsp)
    9eae:	00 
    9eaf:	4d 89 f0             	mov    %r14,%r8
    9eb2:	48 89 9c 24 20 01 00 	mov    %rbx,0x120(%rsp)
    9eb9:	00 
    9eba:	31 db                	xor    %ebx,%ebx
    9ebc:	44 0f 29 9c 24 d0 02 	movaps %xmm11,0x2d0(%rsp)
    9ec3:	00 00 
    9ec5:	0f 29 b4 24 00 02 00 	movaps %xmm6,0x200(%rsp)
    9ecc:	00 
    9ecd:	66 41 0f 28 5d 10    	movapd 0x10(%r13),%xmm3
    9ed3:	4d 89 da             	mov    %r11,%r10
    9ed6:	4c 89 ee             	mov    %r13,%rsi
    9ed9:	66 41 0f 28 75 60    	movapd 0x60(%r13),%xmm6
    9edf:	66 41 0f 28 6d 70    	movapd 0x70(%r13),%xmm5
    9ee5:	4d 89 c1             	mov    %r8,%r9
    9ee8:	48 89 d7             	mov    %rdx,%rdi
    9eeb:	66 45 0f 28 b6 00 02 	movapd 0x200(%r14),%xmm14
    9ef2:	00 00 
    9ef4:	0f 29 9c 24 50 02 00 	movaps %xmm3,0x250(%rsp)
    9efb:	00 
    9efc:	66 0f 28 c6          	movapd %xmm6,%xmm0
    9f00:	66 41 0f 28 9e c0 01 	movapd 0x1c0(%r14),%xmm3
    9f07:	00 00 
    9f09:	66 45 0f 28 9e 10 02 	movapd 0x210(%r14),%xmm11
    9f10:	00 00 
    9f12:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    9f17:	66 41 0f 28 7d 00    	movapd 0x0(%r13),%xmm7
    9f1d:	66 45 0f 28 8e a0 01 	movapd 0x1a0(%r14),%xmm9
    9f24:	00 00 
    9f26:	0f 29 9c 24 40 02 00 	movaps %xmm3,0x240(%rsp)
    9f2d:	00 
    9f2e:	48 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%rax
    9f35:	00 
    9f36:	66 41 0f 28 9e d0 01 	movapd 0x1d0(%r14),%xmm3
    9f3d:	00 00 
    9f3f:	66 45 0f 28 86 b0 01 	movapd 0x1b0(%r14),%xmm8
    9f46:	00 00 
    9f48:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
    9f4f:	00 
    9f50:	0f 29 9c 24 30 02 00 	movaps %xmm3,0x230(%rsp)
    9f57:	00 
    9f58:	66 41 0f 28 5d 20    	movapd 0x20(%r13),%xmm3
    9f5e:	0f 29 9c 24 20 02 00 	movaps %xmm3,0x220(%rsp)
    9f65:	00 
    9f66:	66 41 0f 28 5d 30    	movapd 0x30(%r13),%xmm3
    9f6c:	66 0f 58 d0          	addpd  %xmm0,%xmm2
    9f70:	66 0f 28 c5          	movapd %xmm5,%xmm0
    9f74:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    9f79:	0f 29 9c 24 10 02 00 	movaps %xmm3,0x210(%rsp)
    9f80:	00 
    9f81:	66 41 0f 28 9e e0 01 	movapd 0x1e0(%r14),%xmm3
    9f88:	00 00 
    9f8a:	0f 29 94 24 d0 01 00 	movaps %xmm2,0x1d0(%rsp)
    9f91:	00 
    9f92:	0f 29 9c 24 60 02 00 	movaps %xmm3,0x260(%rsp)
    9f99:	00 
    9f9a:	66 41 0f 28 9e f0 01 	movapd 0x1f0(%r14),%xmm3
    9fa1:	00 00 
    9fa3:	0f 29 9c 24 80 02 00 	movaps %xmm3,0x280(%rsp)
    9faa:	00 
    9fab:	66 41 0f 28 5d 40    	movapd 0x40(%r13),%xmm3
    9fb1:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    9fb5:	0f 29 9c 24 70 02 00 	movaps %xmm3,0x270(%rsp)
    9fbc:	00 
    9fbd:	66 41 0f 28 5d 50    	movapd 0x50(%r13),%xmm3
    9fc3:	0f 29 8c 24 c0 01 00 	movaps %xmm1,0x1c0(%rsp)
    9fca:	00 
    9fcb:	0f 29 9c 24 90 02 00 	movaps %xmm3,0x290(%rsp)
    9fd2:	00 
    9fd3:	66 41 0f 28 49 20    	movapd 0x20(%r9),%xmm1
    9fd9:	66 0f 28 1f          	movapd (%rdi),%xmm3
    9fdd:	66 45 0f 28 fe       	movapd %xmm14,%xmm15
    9fe2:	48 83 c0 20          	add    $0x20,%rax
    9fe6:	48 83 c7 20          	add    $0x20,%rdi
    9fea:	49 83 c1 20          	add    $0x20,%r9
    9fee:	48 83 c1 20          	add    $0x20,%rcx
    9ff2:	48 83 c6 20          	add    $0x20,%rsi
    9ff6:	66 0f 28 e1          	movapd %xmm1,%xmm4
    9ffa:	66 41 0f 28 41 10    	movapd 0x10(%r9),%xmm0
    a000:	66 0f 28 57 f0       	movapd -0x10(%rdi),%xmm2
    a005:	49 83 c2 20          	add    $0x20,%r10
    a009:	66 44 0f 59 fb       	mulpd  %xmm3,%xmm15
    a00e:	66 0f 59 e6          	mulpd  %xmm6,%xmm4
    a012:	66 41 0f 58 e7       	addpd  %xmm15,%xmm4
    a017:	66 0f 58 61 e0       	addpd  -0x20(%rcx),%xmm4
    a01c:	66 45 0f 28 fb       	movapd %xmm11,%xmm15
    a021:	66 44 0f 59 fa       	mulpd  %xmm2,%xmm15
    a026:	0f 29 61 e0          	movaps %xmm4,-0x20(%rcx)
    a02a:	66 0f 28 e0          	movapd %xmm0,%xmm4
    a02e:	66 0f 59 e5          	mulpd  %xmm5,%xmm4
    a032:	66 41 0f 58 e7       	addpd  %xmm15,%xmm4
    a037:	66 0f 58 61 f0       	addpd  -0x10(%rcx),%xmm4
    a03c:	66 44 0f 28 f9       	movapd %xmm1,%xmm15
    a041:	66 44 0f 59 ff       	mulpd  %xmm7,%xmm15
    a046:	0f 29 61 f0          	movaps %xmm4,-0x10(%rcx)
    a04a:	66 0f 28 e3          	movapd %xmm3,%xmm4
    a04e:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
    a053:	66 41 0f 58 e7       	addpd  %xmm15,%xmm4
    a058:	66 0f 58 60 e0       	addpd  -0x20(%rax),%xmm4
    a05d:	66 44 0f 28 bc 24 50 	movapd 0x250(%rsp),%xmm15
    a064:	02 00 00 
    a067:	66 44 0f 59 f8       	mulpd  %xmm0,%xmm15
    a06c:	0f 29 60 e0          	movaps %xmm4,-0x20(%rax)
    a070:	66 0f 28 e2          	movapd %xmm2,%xmm4
    a074:	66 41 0f 59 e0       	mulpd  %xmm8,%xmm4
    a079:	66 41 0f 58 e7       	addpd  %xmm15,%xmm4
    a07e:	66 0f 58 60 f0       	addpd  -0x10(%rax),%xmm4
    a083:	66 44 0f 28 bc 24 20 	movapd 0x220(%rsp),%xmm15
    a08a:	02 00 00 
    a08d:	66 44 0f 59 f9       	mulpd  %xmm1,%xmm15
    a092:	66 0f 59 8c 24 70 02 	mulpd  0x270(%rsp),%xmm1
    a099:	00 00 
    a09b:	0f 29 60 f0          	movaps %xmm4,-0x10(%rax)
    a09f:	66 0f 28 a4 24 40 02 	movapd 0x240(%rsp),%xmm4
    a0a6:	00 00 
    a0a8:	66 0f 59 e3          	mulpd  %xmm3,%xmm4
    a0ac:	66 0f 59 9c 24 60 02 	mulpd  0x260(%rsp),%xmm3
    a0b3:	00 00 
    a0b5:	66 41 0f 58 e7       	addpd  %xmm15,%xmm4
    a0ba:	66 0f 58 60 40       	addpd  0x40(%rax),%xmm4
    a0bf:	66 44 0f 28 bc 24 10 	movapd 0x210(%rsp),%xmm15
    a0c6:	02 00 00 
    a0c9:	66 0f 58 cb          	addpd  %xmm3,%xmm1
    a0cd:	66 0f 58 88 a0 00 00 	addpd  0xa0(%rax),%xmm1
    a0d4:	00 
    a0d5:	66 44 0f 59 f8       	mulpd  %xmm0,%xmm15
    a0da:	66 0f 59 84 24 90 02 	mulpd  0x290(%rsp),%xmm0
    a0e1:	00 00 
    a0e3:	0f 29 60 40          	movaps %xmm4,0x40(%rax)
    a0e7:	66 0f 28 a4 24 30 02 	movapd 0x230(%rsp),%xmm4
    a0ee:	00 00 
    a0f0:	0f 29 88 a0 00 00 00 	movaps %xmm1,0xa0(%rax)
    a0f7:	66 0f 28 4e 70       	movapd 0x70(%rsi),%xmm1
    a0fc:	66 0f 59 e2          	mulpd  %xmm2,%xmm4
    a100:	66 0f 59 94 24 80 02 	mulpd  0x280(%rsp),%xmm2
    a107:	00 00 
    a109:	66 41 0f 59 ca       	mulpd  %xmm10,%xmm1
    a10e:	66 41 0f 58 e7       	addpd  %xmm15,%xmm4
    a113:	66 0f 58 60 50       	addpd  0x50(%rax),%xmm4
    a118:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    a11c:	66 0f 28 56 60       	movapd 0x60(%rsi),%xmm2
    a121:	66 0f 58 80 b0 00 00 	addpd  0xb0(%rax),%xmm0
    a128:	00 
    a129:	66 41 0f 59 d5       	mulpd  %xmm13,%xmm2
    a12e:	0f 29 60 50          	movaps %xmm4,0x50(%rax)
    a132:	0f 29 80 b0 00 00 00 	movaps %xmm0,0xb0(%rax)
    a139:	66 0f 28 46 f0       	movapd -0x10(%rsi),%xmm0
    a13e:	66 0f 5c c1          	subpd  %xmm1,%xmm0
    a142:	66 0f 28 4e e0       	movapd -0x20(%rsi),%xmm1
    a147:	66 0f 59 84 24 00 02 	mulpd  0x200(%rsp),%xmm0
    a14e:	00 00 
    a150:	66 0f 5c ca          	subpd  %xmm2,%xmm1
    a154:	66 0f 59 8c 24 f0 01 	mulpd  0x1f0(%rsp),%xmm1
    a15b:	00 00 
    a15d:	41 0f 29 42 f0       	movaps %xmm0,-0x10(%r10)
    a162:	0f 29 84 24 b0 03 00 	movaps %xmm0,0x3b0(%rsp)
    a169:	00 
    a16a:	41 0f 29 4a e0       	movaps %xmm1,-0x20(%r10)
    a16f:	0f 29 8c 24 a0 03 00 	movaps %xmm1,0x3a0(%rsp)
    a176:	00 
    a177:	4c 39 f8             	cmp    %r15,%rax
    a17a:	0f 85 53 fe ff ff    	jne    9fd3 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x773>
    a180:	48 83 c3 03          	add    $0x3,%rbx
    a184:	48 83 c2 60          	add    $0x60,%rdx
    a188:	49 83 c0 60          	add    $0x60,%r8
    a18c:	49 83 c3 60          	add    $0x60,%r11
    a190:	66 0f 28 94 24 d0 01 	movapd 0x1d0(%rsp),%xmm2
    a197:	00 00 
    a199:	49 81 c5 e0 00 00 00 	add    $0xe0,%r13
    a1a0:	49 83 ee 80          	sub    $0xffffffffffffff80,%r14
    a1a4:	66 0f 28 8c 24 c0 01 	movapd 0x1c0(%rsp),%xmm1
    a1ab:	00 00 
    a1ad:	48 83 fb 0c          	cmp    $0xc,%rbx
    a1b1:	0f 85 16 fd ff ff    	jne    9ecd <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x66d>
    a1b7:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a1bb:	66 0f ef f6          	pxor   %xmm6,%xmm6
    a1bf:	31 c0                	xor    %eax,%eax
    a1c1:	b9 30 00 00 00       	mov    $0x30,%ecx
    a1c6:	0f 29 8c 24 10 03 00 	movaps %xmm1,0x310(%rsp)
    a1cd:	00 
    a1ce:	4c 8b 9c 24 50 01 00 	mov    0x150(%rsp),%r11
    a1d5:	00 
    a1d6:	66 0f 28 8c 24 50 05 	movapd 0x550(%rsp),%xmm1
    a1dd:	00 00 
    a1df:	48 8d bc 24 00 0c 00 	lea    0xc00(%rsp),%rdi
    a1e6:	00 
    a1e7:	4c 8b 8c 24 70 01 00 	mov    0x170(%rsp),%r9
    a1ee:	00 
    a1ef:	48 8b b4 24 60 01 00 	mov    0x160(%rsp),%rsi
    a1f6:	00 
    a1f7:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
    a1fe:	00 
    a1ff:	66 0f 28 fe          	movapd %xmm6,%xmm7
    a203:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    a207:	66 0f 28 ee          	movapd %xmm6,%xmm5
    a20b:	66 0f 28 e6          	movapd %xmm6,%xmm4
    a20f:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
    a216:	00 
    a217:	4c 8b 84 24 30 01 00 	mov    0x130(%rsp),%r8
    a21e:	00 
    a21f:	66 0f 28 de          	movapd %xmm6,%xmm3
    a223:	66 0f 28 d6          	movapd %xmm6,%xmm2
    a227:	66 0f 58 8c 24 d0 05 	addpd  0x5d0(%rsp),%xmm1
    a22e:	00 00 
    a230:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    a233:	48 8b 9c 24 20 01 00 	mov    0x120(%rsp),%rbx
    a23a:	00 
    a23b:	49 8d bb 80 03 00 00 	lea    0x380(%r11),%rdi
    a242:	4c 89 d8             	mov    %r11,%rax
    a245:	66 0f 58 8c 24 50 06 	addpd  0x650(%rsp),%xmm1
    a24c:	00 00 
    a24e:	48 8d 8c 24 00 0c 00 	lea    0xc00(%rsp),%rcx
    a255:	00 
    a256:	66 0f 58 84 24 40 05 	addpd  0x540(%rsp),%xmm0
    a25d:	00 00 
    a25f:	66 0f 58 84 24 c0 05 	addpd  0x5c0(%rsp),%xmm0
    a266:	00 00 
    a268:	66 0f 58 84 24 40 06 	addpd  0x640(%rsp),%xmm0
    a26f:	00 00 
    a271:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
    a276:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
    a27d:	00 
    a27e:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
    a283:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
    a28a:	00 
    a28b:	66 0f 28 80 80 00 00 	movapd 0x80(%rax),%xmm0
    a292:	00 
    a293:	66 0f 28 08          	movapd (%rax),%xmm1
    a297:	48 05 e0 00 00 00    	add    $0xe0,%rax
    a29d:	48 83 c1 60          	add    $0x60,%rcx
    a2a1:	66 44 0f 28 40 b0    	movapd -0x50(%rax),%xmm8
    a2a7:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
    a2ac:	66 45 0f 59 c2       	mulpd  %xmm10,%xmm8
    a2b1:	66 0f 5c c8          	subpd  %xmm0,%xmm1
    a2b5:	66 0f 28 80 30 ff ff 	movapd -0xd0(%rax),%xmm0
    a2bc:	ff 
    a2bd:	66 41 0f 5c c0       	subpd  %xmm8,%xmm0
    a2c2:	66 44 0f 28 40 d0    	movapd -0x30(%rax),%xmm8
    a2c8:	0f 29 49 a0          	movaps %xmm1,-0x60(%rcx)
    a2cc:	66 0f 58 d1          	addpd  %xmm1,%xmm2
    a2d0:	66 0f 28 88 40 ff ff 	movapd -0xc0(%rax),%xmm1
    a2d7:	ff 
    a2d8:	66 45 0f 59 c2       	mulpd  %xmm10,%xmm8
    a2dd:	0f 29 41 b0          	movaps %xmm0,-0x50(%rcx)
    a2e1:	66 0f 58 d8          	addpd  %xmm0,%xmm3
    a2e5:	66 0f 28 40 c0       	movapd -0x40(%rax),%xmm0
    a2ea:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
    a2ef:	66 0f 5c c8          	subpd  %xmm0,%xmm1
    a2f3:	66 0f 28 80 50 ff ff 	movapd -0xb0(%rax),%xmm0
    a2fa:	ff 
    a2fb:	66 41 0f 5c c0       	subpd  %xmm8,%xmm0
    a300:	66 44 0f 28 40 f0    	movapd -0x10(%rax),%xmm8
    a306:	0f 29 49 c0          	movaps %xmm1,-0x40(%rcx)
    a30a:	66 0f 58 e1          	addpd  %xmm1,%xmm4
    a30e:	66 0f 28 88 60 ff ff 	movapd -0xa0(%rax),%xmm1
    a315:	ff 
    a316:	66 45 0f 59 c2       	mulpd  %xmm10,%xmm8
    a31b:	0f 29 41 d0          	movaps %xmm0,-0x30(%rcx)
    a31f:	66 0f 58 e8          	addpd  %xmm0,%xmm5
    a323:	66 0f 28 40 e0       	movapd -0x20(%rax),%xmm0
    a328:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
    a32d:	66 0f 5c c8          	subpd  %xmm0,%xmm1
    a331:	66 0f 28 80 70 ff ff 	movapd -0x90(%rax),%xmm0
    a338:	ff 
    a339:	66 41 0f 5c c0       	subpd  %xmm8,%xmm0
    a33e:	0f 29 49 e0          	movaps %xmm1,-0x20(%rcx)
    a342:	66 0f 58 f9          	addpd  %xmm1,%xmm7
    a346:	0f 29 8c 24 80 03 00 	movaps %xmm1,0x380(%rsp)
    a34d:	00 
    a34e:	0f 29 41 f0          	movaps %xmm0,-0x10(%rcx)
    a352:	66 0f 58 f0          	addpd  %xmm0,%xmm6
    a356:	0f 29 84 24 90 03 00 	movaps %xmm0,0x390(%rsp)
    a35d:	00 
    a35e:	48 39 c7             	cmp    %rax,%rdi
    a361:	0f 85 24 ff ff ff    	jne    a28b <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xa2b>
    a367:	f2 44 0f 10 15 00 00 	movsd  0x0(%rip),%xmm10        # a370 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xb10>
    a36e:	00 00 
    a370:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a374:	31 ff                	xor    %edi,%edi
    a376:	48 8d 84 24 80 14 00 	lea    0x1480(%rsp),%rax
    a37d:	00 
    a37e:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
    a385:	00 
    a386:	f2 44 0f 10 2d 00 00 	movsd  0x0(%rip),%xmm13        # a38f <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xb2f>
    a38d:	00 00 
    a38f:	4c 8d bc 24 00 16 00 	lea    0x1600(%rsp),%r15
    a396:	00 
    a397:	48 8d 8c 24 e0 04 00 	lea    0x4e0(%rsp),%rcx
    a39e:	00 
    a39f:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
    a3a6:	00 
    a3a7:	66 45 0f 14 d2       	unpcklpd %xmm10,%xmm10
    a3ac:	4c 89 8c 24 d0 01 00 	mov    %r9,0x1d0(%rsp)
    a3b3:	00 
    a3b4:	66 45 0f 14 ed       	unpcklpd %xmm13,%xmm13
    a3b9:	48 c7 84 24 80 02 00 	movq   $0x0,0x280(%rsp)
    a3c0:	00 00 00 00 00 
    a3c5:	48 89 b4 24 60 01 00 	mov    %rsi,0x160(%rsp)
    a3cc:	00 
    a3cd:	4c 89 9c 24 50 01 00 	mov    %r11,0x150(%rsp)
    a3d4:	00 
    a3d5:	48 89 94 24 40 01 00 	mov    %rdx,0x140(%rsp)
    a3dc:	00 
    a3dd:	4c 89 84 24 f0 01 00 	mov    %r8,0x1f0(%rsp)
    a3e4:	00 
    a3e5:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    a3ec:	00 
    a3ed:	48 89 9c 24 20 01 00 	mov    %rbx,0x120(%rsp)
    a3f4:	00 
    a3f5:	0f 29 9c 24 f0 04 00 	movaps %xmm3,0x4f0(%rsp)
    a3fc:	00 
    a3fd:	66 0f ef db          	pxor   %xmm3,%xmm3
    a401:	0f 29 bc 24 20 05 00 	movaps %xmm7,0x520(%rsp)
    a408:	00 
    a409:	66 44 0f 28 fb       	movapd %xmm3,%xmm15
    a40e:	66 44 0f 28 f3       	movapd %xmm3,%xmm14
    a413:	0f 29 b4 24 30 05 00 	movaps %xmm6,0x530(%rsp)
    a41a:	00 
    a41b:	0f 29 ac 24 10 05 00 	movaps %xmm5,0x510(%rsp)
    a422:	00 
    a423:	0f 29 a4 24 00 05 00 	movaps %xmm4,0x500(%rsp)
    a42a:	00 
    a42b:	0f 29 94 24 e0 04 00 	movaps %xmm2,0x4e0(%rsp)
    a432:	00 
    a433:	0f 29 84 24 20 03 00 	movaps %xmm0,0x320(%rsp)
    a43a:	00 
    a43b:	0f 29 84 24 30 03 00 	movaps %xmm0,0x330(%rsp)
    a442:	00 
    a443:	0f 29 9c 24 90 02 00 	movaps %xmm3,0x290(%rsp)
    a44a:	00 
    a44b:	44 0f 29 9c 24 c0 01 	movaps %xmm11,0x1c0(%rsp)
    a452:	00 00 
    a454:	44 0f 29 8c 24 70 01 	movaps %xmm9,0x170(%rsp)
    a45b:	00 00 
    a45d:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
    a464:	00 
    a465:	66 0f 28 31          	movapd (%rcx),%xmm6
    a469:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
    a470:	00 
    a471:	4c 8d b4 24 00 0c 00 	lea    0xc00(%rsp),%r14
    a478:	00 
    a479:	4c 8b ac 24 f0 01 00 	mov    0x1f0(%rsp),%r13
    a480:	00 
    a481:	45 31 c9             	xor    %r9d,%r9d
    a484:	45 31 d2             	xor    %r10d,%r10d
    a487:	4c 8b a4 24 10 02 00 	mov    0x210(%rsp),%r12
    a48e:	00 
    a48f:	66 0f 28 88 b0 0d 00 	movapd 0xdb0(%rax),%xmm1
    a496:	00 
    a497:	0f 29 b4 24 30 02 00 	movaps %xmm6,0x230(%rsp)
    a49e:	00 
    a49f:	66 0f 28 71 10       	movapd 0x10(%rcx),%xmm6
    a4a4:	48 8d 9c 24 e0 04 00 	lea    0x4e0(%rsp),%rbx
    a4ab:	00 
    a4ac:	66 0f 28 a0 a0 0d 00 	movapd 0xda0(%rax),%xmm4
    a4b3:	00 
    a4b4:	4c 8d 9c 24 80 14 00 	lea    0x1480(%rsp),%r11
    a4bb:	00 
    a4bc:	0f 29 b4 24 20 02 00 	movaps %xmm6,0x220(%rsp)
    a4c3:	00 
    a4c4:	66 0f 28 f1          	movapd %xmm1,%xmm6
    a4c8:	66 0f 28 cc          	movapd %xmm4,%xmm1
    a4cc:	66 0f 28 e6          	movapd %xmm6,%xmm4
    a4d0:	66 44 0f 28 03       	movapd (%rbx),%xmm8
    a4d5:	66 0f 28 7b 10       	movapd 0x10(%rbx),%xmm7
    a4da:	4c 89 f6             	mov    %r14,%rsi
    a4dd:	4c 89 da             	mov    %r11,%rdx
    a4e0:	66 0f 28 f1          	movapd %xmm1,%xmm6
    a4e4:	66 0f 28 ec          	movapd %xmm4,%xmm5
    a4e8:	66 45 0f ef c9       	pxor   %xmm9,%xmm9
    a4ed:	4c 89 e9             	mov    %r13,%rcx
    a4f0:	66 41 0f 28 93 a0 0d 	movapd 0xda0(%r11),%xmm2
    a4f7:	00 00 
    a4f9:	66 44 0f 59 c1       	mulpd  %xmm1,%xmm8
    a4fe:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
    a503:	66 41 0f 28 83 b0 0d 	movapd 0xdb0(%r11),%xmm0
    a50a:	00 00 
    a50c:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
    a510:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
    a517:	00 
    a518:	44 0f 29 b4 24 70 02 	movaps %xmm14,0x270(%rsp)
    a51f:	00 00 
    a521:	66 0f 59 f2          	mulpd  %xmm2,%xmm6
    a525:	0f 29 8c 24 60 02 00 	movaps %xmm1,0x260(%rsp)
    a52c:	00 
    a52d:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
    a531:	0f 29 9c 24 50 02 00 	movaps %xmm3,0x250(%rsp)
    a538:	00 
    a539:	66 0f 59 94 24 30 02 	mulpd  0x230(%rsp),%xmm2
    a540:	00 00 
    a542:	66 0f 59 84 24 20 02 	mulpd  0x220(%rsp),%xmm0
    a549:	00 00 
    a54b:	66 44 0f 58 c2       	addpd  %xmm2,%xmm8
    a550:	66 0f 58 f8          	addpd  %xmm0,%xmm7
    a554:	4d 8d 04 09          	lea    (%r9,%rcx,1),%r8
    a558:	66 0f 28 09          	movapd (%rcx),%xmm1
    a55c:	48 83 c0 60          	add    $0x60,%rax
    a560:	48 83 c1 60          	add    $0x60,%rcx
    a564:	66 0f 59 48 c0       	mulpd  -0x40(%rax),%xmm1
    a569:	66 41 0f 28 04 38    	movapd (%r8,%rdi,1),%xmm0
    a56f:	48 83 c2 60          	add    $0x60,%rdx
    a573:	66 0f 59 42 c0       	mulpd  -0x40(%rdx),%xmm0
    a578:	66 0f 28 98 c0 0b 00 	movapd 0xbc0(%rax),%xmm3
    a57f:	00 
    a580:	66 0f 28 90 d0 0b 00 	movapd 0xbd0(%rax),%xmm2
    a587:	00 
    a588:	66 44 0f 28 f3       	movapd %xmm3,%xmm14
    a58d:	66 0f 59 1e          	mulpd  (%rsi),%xmm3
    a591:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    a595:	66 0f 28 48 d0       	movapd -0x30(%rax),%xmm1
    a59a:	66 0f 59 49 b0       	mulpd  -0x50(%rcx),%xmm1
    a59f:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
    a5a4:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
    a5a9:	66 41 0f 28 44 38 10 	movapd 0x10(%r8,%rdi,1),%xmm0
    a5b0:	4d 8d 04 31          	lea    (%r9,%rsi,1),%r8
    a5b4:	66 0f 59 42 d0       	mulpd  -0x30(%rdx),%xmm0
    a5b9:	48 83 c6 60          	add    $0x60,%rsi
    a5bd:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    a5c1:	66 0f 28 8a c0 0b 00 	movapd 0xbc0(%rdx),%xmm1
    a5c8:	00 
    a5c9:	66 44 0f 59 f1       	mulpd  %xmm1,%xmm14
    a5ce:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
    a5d3:	66 41 0f 59 0c 38    	mulpd  (%r8,%rdi,1),%xmm1
    a5d9:	66 41 0f 58 f6       	addpd  %xmm14,%xmm6
    a5de:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
    a5e3:	66 44 0f 58 c8       	addpd  %xmm0,%xmm9
    a5e8:	66 0f 28 82 d0 0b 00 	movapd 0xbd0(%rdx),%xmm0
    a5ef:	00 
    a5f0:	66 0f 59 56 b0       	mulpd  -0x50(%rsi),%xmm2
    a5f5:	66 0f 58 cb          	addpd  %xmm3,%xmm1
    a5f9:	66 44 0f 59 f0       	mulpd  %xmm0,%xmm14
    a5fe:	66 41 0f 59 44 38 10 	mulpd  0x10(%r8,%rdi,1),%xmm0
    a605:	66 44 0f 58 c1       	addpd  %xmm1,%xmm8
    a60a:	66 41 0f 58 ee       	addpd  %xmm14,%xmm5
    a60f:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    a613:	66 0f 58 f8          	addpd  %xmm0,%xmm7
    a617:	49 39 c7             	cmp    %rax,%r15
    a61a:	0f 85 34 ff ff ff    	jne    a554 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xcf4>
    a620:	66 41 0f 28 94 24 00 	movapd 0xb00(%r12),%xmm2
    a627:	0b 00 00 
    a62a:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
    a62f:	66 41 0f 28 84 24 10 	movapd 0xb10(%r12),%xmm0
    a636:	0b 00 00 
    a639:	66 44 0f 28 b4 24 70 	movapd 0x270(%rsp),%xmm14
    a640:	02 00 00 
    a643:	66 41 0f 59 e9       	mulpd  %xmm9,%xmm5
    a648:	66 0f 28 9c 24 50 02 	movapd 0x250(%rsp),%xmm3
    a64f:	00 00 
    a651:	66 0f 28 8c 24 60 02 	movapd 0x260(%rsp),%xmm1
    a658:	00 00 
    a65a:	66 44 0f 59 c2       	mulpd  %xmm2,%xmm8
    a65f:	66 0f 58 d2          	addpd  %xmm2,%xmm2
    a663:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
    a667:	66 0f 58 c0          	addpd  %xmm0,%xmm0
    a66b:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
    a670:	66 41 0f 59 c1       	mulpd  %xmm9,%xmm0
    a675:	66 41 0f 58 f0       	addpd  %xmm8,%xmm6
    a67a:	66 0f 58 ef          	addpd  %xmm7,%xmm5
    a67e:	66 41 0f 5e f5       	divpd  %xmm13,%xmm6
    a683:	66 44 0f 58 f2       	addpd  %xmm2,%xmm14
    a688:	66 0f 58 d8          	addpd  %xmm0,%xmm3
    a68c:	66 41 0f 5e ed       	divpd  %xmm13,%xmm5
    a691:	66 44 0f 58 fe       	addpd  %xmm6,%xmm15
    a696:	66 0f 58 ac 24 90 02 	addpd  0x290(%rsp),%xmm5
    a69d:	00 00 
    a69f:	0f 29 ac 24 90 02 00 	movaps %xmm5,0x290(%rsp)
    a6a6:	00 
    a6a7:	44 3b 94 24 80 02 00 	cmp    0x280(%rsp),%r10d
    a6ae:	00 
    a6af:	0f 84 a8 17 00 00    	je     be5d <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x25fd>
    a6b5:	49 83 c2 01          	add    $0x1,%r10
    a6b9:	49 83 fa 03          	cmp    $0x3,%r10
    a6bd:	74 1d                	je     a6dc <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xe7c>
    a6bf:	49 83 c3 20          	add    $0x20,%r11
    a6c3:	48 83 c3 20          	add    $0x20,%rbx
    a6c7:	49 83 c4 20          	add    $0x20,%r12
    a6cb:	49 83 c5 20          	add    $0x20,%r13
    a6cf:	49 83 c6 20          	add    $0x20,%r14
    a6d3:	49 83 e9 20          	sub    $0x20,%r9
    a6d7:	e9 f4 fd ff ff       	jmp    a4d0 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xc70>
    a6dc:	48 8b 8c 24 00 02 00 	mov    0x200(%rsp),%rcx
    a6e3:	00 
    a6e4:	48 83 c7 20          	add    $0x20,%rdi
    a6e8:	48 83 84 24 80 02 00 	addq   $0x1,0x280(%rsp)
    a6ef:	00 01 
    a6f1:	49 83 c7 20          	add    $0x20,%r15
    a6f5:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
    a6fc:	00 
    a6fd:	48 83 84 24 40 02 00 	addq   $0x20,0x240(%rsp)
    a704:	00 20 
    a706:	48 83 84 24 10 02 00 	addq   $0x60,0x210(%rsp)
    a70d:	00 60 
    a70f:	48 83 c1 20          	add    $0x20,%rcx
    a713:	48 83 f8 03          	cmp    $0x3,%rax
    a717:	0f 85 40 fd ff ff    	jne    a45d <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xbfd>
    a71d:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
    a722:	31 c0                	xor    %eax,%eax
    a724:	b9 70 00 00 00       	mov    $0x70,%ecx
    a729:	45 31 ff             	xor    %r15d,%r15d
    a72c:	66 0f 59 94 24 e0 22 	mulpd  0x22e0(%rsp),%xmm2
    a733:	00 00 
    a735:	66 0f 28 8c 24 90 02 	movapd 0x290(%rsp),%xmm1
    a73c:	00 00 
    a73e:	4c 8d b4 24 80 14 00 	lea    0x1480(%rsp),%r14
    a745:	00 
    a746:	66 0f 59 9c 24 f0 22 	mulpd  0x22f0(%rsp),%xmm3
    a74d:	00 00 
    a74f:	66 44 0f 28 b4 24 d0 	movapd 0x1ed0(%rsp),%xmm14
    a756:	1e 00 00 
    a759:	4c 89 b4 24 50 02 00 	mov    %r14,0x250(%rsp)
    a760:	00 
    a761:	4c 8b 8c 24 d0 01 00 	mov    0x1d0(%rsp),%r9
    a768:	00 
    a769:	48 8b bc 24 b0 01 00 	mov    0x1b0(%rsp),%rdi
    a770:	00 
    a771:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
    a778:	00 
    a779:	4c 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%r8
    a780:	00 
    a781:	f3 48 ab             	rep stos %rax,%es:(%rdi)
    a784:	4c 8b a4 24 30 01 00 	mov    0x130(%rsp),%r12
    a78b:	00 
    a78c:	66 0f 28 ac 24 c0 02 	movapd 0x2c0(%rsp),%xmm5
    a793:	00 00 
    a795:	48 8d 84 24 00 11 00 	lea    0x1100(%rsp),%rax
    a79c:	00 
    a79d:	66 0f 28 c2          	movapd %xmm2,%xmm0
    a7a1:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a7a5:	49 89 c6             	mov    %rax,%r14
    a7a8:	66 0f 28 b4 24 d0 02 	movapd 0x2d0(%rsp),%xmm6
    a7af:	00 00 
    a7b1:	66 41 0f 58 c7       	addpd  %xmm15,%xmm0
    a7b6:	66 0f 58 cb          	addpd  %xmm3,%xmm1
    a7ba:	66 44 0f 28 bc 24 c0 	movapd 0x1ec0(%rsp),%xmm15
    a7c1:	1e 00 00 
    a7c4:	66 0f 59 84 24 80 22 	mulpd  0x2280(%rsp),%xmm0
    a7cb:	00 00 
    a7cd:	66 0f 28 da          	movapd %xmm2,%xmm3
    a7d1:	66 44 0f 28 8c 24 70 	movapd 0x170(%rsp),%xmm9
    a7d8:	01 00 00 
    a7db:	66 44 0f 28 9c 24 c0 	movapd 0x1c0(%rsp),%xmm11
    a7e2:	01 00 00 
    a7e5:	0f 29 ac 24 80 02 00 	movaps %xmm5,0x280(%rsp)
    a7ec:	00 
    a7ed:	66 41 0f 28 e7       	movapd %xmm15,%xmm4
    a7f2:	48 8b 9c 24 20 01 00 	mov    0x120(%rsp),%rbx
    a7f9:	00 
    a7fa:	48 8b bc 24 e0 01 00 	mov    0x1e0(%rsp),%rdi
    a801:	00 
    a802:	0f 29 b4 24 90 02 00 	movaps %xmm6,0x290(%rsp)
    a809:	00 
    a80a:	66 0f 28 bc 24 30 1f 	movapd 0x1f30(%rsp),%xmm7
    a811:	00 00 
    a813:	66 41 0f 59 e7       	mulpd  %xmm15,%xmm4
    a818:	66 0f 59 8c 24 90 22 	mulpd  0x2290(%rsp),%xmm1
    a81f:	00 00 
    a821:	48 89 f9             	mov    %rdi,%rcx
    a824:	66 0f 5c dc          	subpd  %xmm4,%xmm3
    a828:	66 0f 28 a4 24 20 1f 	movapd 0x1f20(%rsp),%xmm4
    a82f:	00 00 
    a831:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
    a835:	66 0f 59 84 24 a0 22 	mulpd  0x22a0(%rsp),%xmm0
    a83c:	00 00 
    a83e:	0f 29 9c 24 40 02 00 	movaps %xmm3,0x240(%rsp)
    a845:	00 
    a846:	66 41 0f 28 de       	movapd %xmm14,%xmm3
    a84b:	66 41 0f 59 de       	mulpd  %xmm14,%xmm3
    a850:	66 0f 5c d3          	subpd  %xmm3,%xmm2
    a854:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
    a858:	66 0f 59 8c 24 b0 22 	mulpd  0x22b0(%rsp),%xmm1
    a85f:	00 00 
    a861:	0f 29 94 24 30 02 00 	movaps %xmm2,0x230(%rsp)
    a868:	00 
    a869:	66 0f 28 94 24 c0 22 	movapd 0x22c0(%rsp),%xmm2
    a870:	00 00 
    a872:	66 0f 59 94 24 20 03 	mulpd  0x320(%rsp),%xmm2
    a879:	00 00 
    a87b:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    a87f:	66 0f 28 94 24 30 03 	movapd 0x330(%rsp),%xmm2
    a886:	00 00 
    a888:	66 0f 59 94 24 d0 22 	mulpd  0x22d0(%rsp),%xmm2
    a88f:	00 00 
    a891:	48 c7 84 24 60 02 00 	movq   $0x0,0x260(%rsp)
    a898:	00 00 00 00 00 
    a89d:	4c 89 8c 24 c0 01 00 	mov    %r9,0x1c0(%rsp)
    a8a4:	00 
    a8a5:	66 44 0f 28 94 24 b0 	movapd 0x2b0(%rsp),%xmm10
    a8ac:	02 00 00 
    a8af:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
    a8b6:	00 
    a8b7:	4c 89 e0             	mov    %r12,%rax
    a8ba:	4c 89 84 24 40 01 00 	mov    %r8,0x140(%rsp)
    a8c1:	00 
    a8c2:	49 89 d0             	mov    %rdx,%r8
    a8c5:	48 89 da             	mov    %rbx,%rdx
    a8c8:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
    a8cf:	00 
    a8d0:	44 0f 29 bc 24 d0 01 	movaps %xmm15,0x1d0(%rsp)
    a8d7:	00 00 
    a8d9:	66 0f 58 ca          	addpd  %xmm2,%xmm1
    a8dd:	44 0f 29 9c 24 b0 01 	movaps %xmm11,0x1b0(%rsp)
    a8e4:	00 00 
    a8e6:	0f 29 8c 24 00 02 00 	movaps %xmm1,0x200(%rsp)
    a8ed:	00 
    a8ee:	66 0f 28 ce          	movapd %xmm6,%xmm1
    a8f2:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
    a8f7:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
    a8fc:	66 0f 28 ac 24 a0 02 	movapd 0x2a0(%rsp),%xmm5
    a903:	00 00 
    a905:	48 89 bc 24 20 02 00 	mov    %rdi,0x220(%rsp)
    a90c:	00 
    a90d:	4d 89 c1             	mov    %r8,%r9
    a910:	49 89 cc             	mov    %rcx,%r12
    a913:	48 89 fb             	mov    %rdi,%rbx
    a916:	48 89 8c 24 10 02 00 	mov    %rcx,0x210(%rsp)
    a91d:	00 
    a91e:	4c 8b 9c 24 50 02 00 	mov    0x250(%rsp),%r11
    a925:	00 
    a926:	45 31 ed             	xor    %r13d,%r13d
    a929:	66 45 0f 28 de       	movapd %xmm14,%xmm11
    a92e:	4c 8d 94 24 80 14 00 	lea    0x1480(%rsp),%r10
    a935:	00 
    a936:	66 44 0f 28 03       	movapd (%rbx),%xmm8
    a93b:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
    a940:	4c 89 f1             	mov    %r14,%rcx
    a943:	4c 89 d7             	mov    %r10,%rdi
    a946:	66 45 0f 58 04 24    	addpd  (%r12),%xmm8
    a94c:	66 41 0f 28 5c 24 10 	movapd 0x10(%r12),%xmm3
    a953:	49 8d b1 80 fe ff ff 	lea    -0x180(%r9),%rsi
    a95a:	0f 29 bc 24 70 02 00 	movaps %xmm7,0x270(%rsp)
    a961:	00 
    a962:	66 41 0f 28 93 a0 03 	movapd 0x3a0(%r11),%xmm2
    a969:	00 00 
    a96b:	66 0f 58 5b 10       	addpd  0x10(%rbx),%xmm3
    a970:	66 43 0f 58 94 3a a0 	addpd  0x3a0(%r10,%r15,1),%xmm2
    a977:	03 00 00 
    a97a:	66 41 0f 28 83 b0 03 	movapd 0x3b0(%r11),%xmm0
    a981:	00 00 
    a983:	66 43 0f 58 84 3a b0 	addpd  0x3b0(%r10,%r15,1),%xmm0
    a98a:	03 00 00 
    a98d:	66 44 0f 59 c4       	mulpd  %xmm4,%xmm8
    a992:	66 0f 59 df          	mulpd  %xmm7,%xmm3
    a996:	66 0f 59 d4          	mulpd  %xmm4,%xmm2
    a99a:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
    a99e:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
    a9a3:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
    a9a8:	66 44 0f 59 fa       	mulpd  %xmm2,%xmm15
    a9ad:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
    a9b2:	66 44 0f 28 f0       	movapd %xmm0,%xmm14
    a9b7:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
    a9bb:	66 45 0f 59 f2       	mulpd  %xmm10,%xmm14
    a9c0:	66 44 0f 58 c2       	addpd  %xmm2,%xmm8
    a9c5:	66 0f 58 d8          	addpd  %xmm0,%xmm3
    a9c9:	66 0f 28 46 10       	movapd 0x10(%rsi),%xmm0
    a9ce:	66 0f 28 57 30       	movapd 0x30(%rdi),%xmm2
    a9d3:	48 83 c6 60          	add    $0x60,%rsi
    a9d7:	48 83 c7 60          	add    $0x60,%rdi
    a9db:	66 0f 28 7f c0       	movapd -0x40(%rdi),%xmm7
    a9e0:	48 81 c1 e0 00 00 00 	add    $0xe0,%rcx
    a9e7:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
    a9eb:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
    a9f0:	66 41 0f 59 f8       	mulpd  %xmm8,%xmm7
    a9f5:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    a9f9:	66 0f 28 56 a0       	movapd -0x60(%rsi),%xmm2
    a9fe:	66 0f 58 81 30 ff ff 	addpd  -0xd0(%rcx),%xmm0
    aa05:	ff 
    aa06:	66 41 0f 59 d7       	mulpd  %xmm15,%xmm2
    aa0b:	0f 29 81 30 ff ff ff 	movaps %xmm0,-0xd0(%rcx)
    aa12:	66 0f 58 d7          	addpd  %xmm7,%xmm2
    aa16:	66 0f 58 91 20 ff ff 	addpd  -0xe0(%rcx),%xmm2
    aa1d:	ff 
    aa1e:	0f 29 91 20 ff ff ff 	movaps %xmm2,-0xe0(%rcx)
    aa25:	49 39 f1             	cmp    %rsi,%r9
    aa28:	75 9f                	jne    a9c9 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x1169>
    aa2a:	49 83 c5 01          	add    $0x1,%r13
    aa2e:	49 83 c3 60          	add    $0x60,%r11
    aa32:	48 83 c3 20          	add    $0x20,%rbx
    aa36:	49 83 c4 60          	add    $0x60,%r12
    aa3a:	66 0f 28 bc 24 70 02 	movapd 0x270(%rsp),%xmm7
    aa41:	00 00 
    aa43:	49 83 c2 20          	add    $0x20,%r10
    aa47:	49 83 c1 20          	add    $0x20,%r9
    aa4b:	49 83 fd 03          	cmp    $0x3,%r13
    aa4f:	0f 85 e1 fe ff ff    	jne    a936 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x10d6>
    aa55:	48 8b bc 24 20 02 00 	mov    0x220(%rsp),%rdi
    aa5c:	00 
    aa5d:	66 45 0f 28 f3       	movapd %xmm11,%xmm14
    aa62:	48 83 84 24 60 02 00 	addq   $0x1,0x260(%rsp)
    aa69:	00 01 
    aa6b:	49 83 c6 20          	add    $0x20,%r14
    aa6f:	48 8b 8c 24 10 02 00 	mov    0x210(%rsp),%rcx
    aa76:	00 
    aa77:	48 8b 9c 24 60 02 00 	mov    0x260(%rsp),%rbx
    aa7e:	00 
    aa7f:	49 83 c7 60          	add    $0x60,%r15
    aa83:	48 83 84 24 50 02 00 	addq   $0x20,0x250(%rsp)
    aa8a:	00 20 
    aa8c:	48 83 c7 60          	add    $0x60,%rdi
    aa90:	48 83 c1 20          	add    $0x20,%rcx
    aa94:	48 83 fb 03          	cmp    $0x3,%rbx
    aa98:	0f 85 67 fe ff ff    	jne    a905 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x10a5>
    aa9e:	66 44 0f 28 ce       	movapd %xmm6,%xmm9
    aaa3:	49 89 c4             	mov    %rax,%r12
    aaa6:	48 89 d3             	mov    %rdx,%rbx
    aaa9:	66 0f 28 b4 24 a0 1e 	movapd 0x1ea0(%rsp),%xmm6
    aab0:	00 00 
    aab2:	66 0f 28 84 24 f0 01 	movapd 0x1f0(%rsp),%xmm0
    aab9:	00 00 
    aabb:	4c 89 c2             	mov    %r8,%rdx
    aabe:	66 0f 28 bc 24 e0 1e 	movapd 0x1ee0(%rsp),%xmm7
    aac5:	00 00 
    aac7:	4c 8d ac 24 80 14 00 	lea    0x1480(%rsp),%r13
    aace:	00 
    aacf:	66 44 0f 28 9c 24 b0 	movapd 0x1b0(%rsp),%xmm11
    aad6:	01 00 00 
    aad9:	66 44 0f 28 94 24 a0 	movapd 0x2a0(%rsp),%xmm10
    aae0:	02 00 00 
    aae3:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
    aae7:	66 44 0f 28 84 24 f0 	movapd 0x1ef0(%rsp),%xmm8
    aaee:	1e 00 00 
    aaf1:	66 0f 28 94 24 b0 1e 	movapd 0x1eb0(%rsp),%xmm2
    aaf8:	00 00 
    aafa:	66 44 0f 59 df       	mulpd  %xmm7,%xmm11
    aaff:	66 41 0f 28 ea       	movapd %xmm10,%xmm5
    ab04:	66 0f 28 8c 24 00 02 	movapd 0x200(%rsp),%xmm1
    ab0b:	00 00 
    ab0d:	66 0f 28 a4 24 b0 02 	movapd 0x2b0(%rsp),%xmm4
    ab14:	00 00 
    ab16:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
    ab1a:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
    ab21:	00 
    ab22:	4c 8b 84 24 40 01 00 	mov    0x140(%rsp),%r8
    ab29:	00 
    ab2a:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
    ab2e:	4c 8b 8c 24 c0 01 00 	mov    0x1c0(%rsp),%r9
    ab35:	00 
    ab36:	66 44 0f 28 bc 24 d0 	movapd 0x1d0(%rsp),%xmm15
    ab3d:	01 00 00 
    ab40:	66 41 0f 59 e0       	mulpd  %xmm8,%xmm4
    ab45:	48 89 c7             	mov    %rax,%rdi
    ab48:	4d 89 c2             	mov    %r8,%r10
    ab4b:	48 8b b4 24 60 01 00 	mov    0x160(%rsp),%rsi
    ab52:	00 
    ab53:	66 0f 28 d8          	movapd %xmm0,%xmm3
    ab57:	4c 8b 9c 24 50 01 00 	mov    0x150(%rsp),%r11
    ab5e:	00 
    ab5f:	66 0f 28 84 24 80 02 	movapd 0x280(%rsp),%xmm0
    ab66:	00 00 
    ab68:	48 8d 88 80 03 00 00 	lea    0x380(%rax),%rcx
    ab6f:	66 41 0f 58 db       	addpd  %xmm11,%xmm3
    ab74:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
    ab78:	66 0f 59 ee          	mulpd  %xmm6,%xmm5
    ab7c:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
    ab81:	66 0f 59 e2          	mulpd  %xmm2,%xmm4
    ab85:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
    ab89:	66 0f 58 d8          	addpd  %xmm0,%xmm3
    ab8d:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
    ab92:	66 41 0f 59 c0       	mulpd  %xmm8,%xmm0
    ab97:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    ab9b:	66 0f 28 8c 24 90 02 	movapd 0x290(%rsp),%xmm1
    aba2:	00 00 
    aba4:	66 0f 59 84 24 b0 02 	mulpd  0x2b0(%rsp),%xmm0
    abab:	00 00 
    abad:	66 41 0f 59 c8       	mulpd  %xmm8,%xmm1
    abb2:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
    abb6:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    abba:	66 41 0f 28 4a 10    	movapd 0x10(%r10),%xmm1
    abc0:	49 83 c5 60          	add    $0x60,%r13
    abc4:	49 83 c2 60          	add    $0x60,%r10
    abc8:	66 41 0f 28 7d d0    	movapd -0x30(%r13),%xmm7
    abce:	66 45 0f 28 45 c0    	movapd -0x40(%r13),%xmm8
    abd4:	48 81 c7 e0 00 00 00 	add    $0xe0,%rdi
    abdb:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
    abdf:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
    abe3:	66 44 0f 59 c3       	mulpd  %xmm3,%xmm8
    abe8:	66 0f 58 cf          	addpd  %xmm7,%xmm1
    abec:	66 41 0f 28 7a a0    	movapd -0x60(%r10),%xmm7
    abf2:	66 0f 58 8f 30 ff ff 	addpd  -0xd0(%rdi),%xmm1
    abf9:	ff 
    abfa:	66 0f 59 fd          	mulpd  %xmm5,%xmm7
    abfe:	0f 29 8f 30 ff ff ff 	movaps %xmm1,-0xd0(%rdi)
    ac05:	66 41 0f 28 4a d0    	movapd -0x30(%r10),%xmm1
    ac0b:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
    ac0f:	66 41 0f 58 f8       	addpd  %xmm8,%xmm7
    ac14:	66 0f 58 bf 20 ff ff 	addpd  -0xe0(%rdi),%xmm7
    ac1b:	ff 
    ac1c:	66 45 0f 28 45 e0    	movapd -0x20(%r13),%xmm8
    ac22:	66 44 0f 59 c3       	mulpd  %xmm3,%xmm8
    ac27:	0f 29 bf 20 ff ff ff 	movaps %xmm7,-0xe0(%rdi)
    ac2e:	66 41 0f 28 7d f0    	movapd -0x10(%r13),%xmm7
    ac34:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
    ac38:	66 0f 58 cf          	addpd  %xmm7,%xmm1
    ac3c:	66 41 0f 28 7a c0    	movapd -0x40(%r10),%xmm7
    ac42:	66 0f 58 8f 50 ff ff 	addpd  -0xb0(%rdi),%xmm1
    ac49:	ff 
    ac4a:	66 0f 59 fd          	mulpd  %xmm5,%xmm7
    ac4e:	0f 29 8f 50 ff ff ff 	movaps %xmm1,-0xb0(%rdi)
    ac55:	66 41 0f 28 4a f0    	movapd -0x10(%r10),%xmm1
    ac5b:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
    ac5f:	66 41 0f 58 f8       	addpd  %xmm8,%xmm7
    ac64:	66 0f 58 bf 40 ff ff 	addpd  -0xc0(%rdi),%xmm7
    ac6b:	ff 
    ac6c:	66 45 0f 28 42 e0    	movapd -0x20(%r10),%xmm8
    ac72:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
    ac77:	0f 29 bf 40 ff ff ff 	movaps %xmm7,-0xc0(%rdi)
    ac7e:	66 41 0f 28 7d 10    	movapd 0x10(%r13),%xmm7
    ac84:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
    ac88:	66 0f 58 cf          	addpd  %xmm7,%xmm1
    ac8c:	66 41 0f 28 7d 00    	movapd 0x0(%r13),%xmm7
    ac92:	66 0f 58 8f 70 ff ff 	addpd  -0x90(%rdi),%xmm1
    ac99:	ff 
    ac9a:	66 0f 59 fb          	mulpd  %xmm3,%xmm7
    ac9e:	0f 29 8f 70 ff ff ff 	movaps %xmm1,-0x90(%rdi)
    aca5:	66 41 0f 58 f8       	addpd  %xmm8,%xmm7
    acaa:	66 0f 58 bf 60 ff ff 	addpd  -0xa0(%rdi),%xmm7
    acb1:	ff 
    acb2:	0f 29 bf 60 ff ff ff 	movaps %xmm7,-0xa0(%rdi)
    acb9:	48 39 cf             	cmp    %rcx,%rdi
    acbc:	0f 85 f8 fe ff ff    	jne    abba <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x135a>
    acc2:	48 8b bc 24 80 01 00 	mov    0x180(%rsp),%rdi
    acc9:	00 
    acca:	4c 8b bc 24 e0 01 00 	mov    0x1e0(%rsp),%r15
    acd1:	00 
    acd2:	4c 89 8c 24 c0 01 00 	mov    %r9,0x1c0(%rsp)
    acd9:	00 
    acda:	4c 8d b4 24 80 14 00 	lea    0x1480(%rsp),%r14
    ace1:	00 
    ace2:	66 0f 28 bc 24 40 1f 	movapd 0x1f40(%rsp),%xmm7
    ace9:	00 00 
    aceb:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
    acf2:	00 
    acf3:	48 89 bc 24 b0 01 00 	mov    %rdi,0x1b0(%rsp)
    acfa:	00 
    acfb:	49 81 c7 20 01 00 00 	add    $0x120,%r15
    ad02:	0f 29 bc 24 10 02 00 	movaps %xmm7,0x210(%rsp)
    ad09:	00 
    ad0a:	66 0f 28 bc 24 50 1f 	movapd 0x1f50(%rsp),%xmm7
    ad11:	00 00 
    ad13:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
    ad1a:	00 
    ad1b:	4c 89 d8             	mov    %r11,%rax
    ad1e:	48 89 b4 24 50 01 00 	mov    %rsi,0x150(%rsp)
    ad25:	00 
    ad26:	48 89 fe             	mov    %rdi,%rsi
    ad29:	4c 89 84 24 40 01 00 	mov    %r8,0x140(%rsp)
    ad30:	00 
    ad31:	45 31 c0             	xor    %r8d,%r8d
    ad34:	0f 29 bc 24 20 02 00 	movaps %xmm7,0x220(%rsp)
    ad3b:	00 
    ad3c:	0f 29 b4 24 00 02 00 	movaps %xmm6,0x200(%rsp)
    ad43:	00 
    ad44:	44 0f 29 bc 24 f0 01 	movaps %xmm15,0x1f0(%rsp)
    ad4b:	00 00 
    ad4d:	0f 29 94 24 d0 01 00 	movaps %xmm2,0x1d0(%rsp)
    ad54:	00 
    ad55:	44 0f 29 b4 24 80 01 	movaps %xmm14,0x180(%rsp)
    ad5c:	00 00 
    ad5e:	66 44 0f 28 1a       	movapd (%rdx),%xmm11
    ad63:	66 0f 28 7a 20       	movapd 0x20(%rdx),%xmm7
    ad68:	49 89 f5             	mov    %rsi,%r13
    ad6b:	49 89 c2             	mov    %rax,%r10
    ad6e:	66 41 0f 28 9e 70 05 	movapd 0x570(%r14),%xmm3
    ad75:	00 00 
    ad77:	66 44 0f 28 52 10    	movapd 0x10(%rdx),%xmm10
    ad7d:	48 8d bc 24 80 14 00 	lea    0x1480(%rsp),%rdi
    ad84:	00 
    ad85:	66 45 0f 28 be 20 05 	movapd 0x520(%r14),%xmm15
    ad8c:	00 00 
    ad8e:	66 0f 28 72 30       	movapd 0x30(%rdx),%xmm6
    ad93:	0f 29 9c 24 60 02 00 	movaps %xmm3,0x260(%rsp)
    ad9a:	00 
    ad9b:	66 0f 28 5a 40       	movapd 0x40(%rdx),%xmm3
    ada0:	66 45 0f 28 b6 30 05 	movapd 0x530(%r14),%xmm14
    ada7:	00 00 
    ada9:	4c 8b 8c 24 a0 01 00 	mov    0x1a0(%rsp),%r9
    adb0:	00 
    adb1:	48 8b 8c 24 e0 01 00 	mov    0x1e0(%rsp),%rcx
    adb8:	00 
    adb9:	0f 29 9c 24 70 02 00 	movaps %xmm3,0x270(%rsp)
    adc0:	00 
    adc1:	66 0f 28 5a 50       	movapd 0x50(%rdx),%xmm3
    adc6:	66 45 0f 28 8e 40 05 	movapd 0x540(%r14),%xmm9
    adcd:	00 00 
    adcf:	66 45 0f 28 86 50 05 	movapd 0x550(%r14),%xmm8
    add6:	00 00 
    add8:	66 41 0f 28 ae 60 05 	movapd 0x560(%r14),%xmm5
    addf:	00 00 
    ade1:	0f 29 9c 24 50 02 00 	movaps %xmm3,0x250(%rsp)
    ade8:	00 
    ade9:	66 0f 28 09          	movapd (%rcx),%xmm1
    aded:	48 83 c1 60          	add    $0x60,%rcx
    adf1:	49 83 c2 20          	add    $0x20,%r10
    adf5:	49 83 c5 20          	add    $0x20,%r13
    adf9:	66 0f 28 9f a0 03 00 	movapd 0x3a0(%rdi),%xmm3
    ae00:	00 
    ae01:	49 83 c1 20          	add    $0x20,%r9
    ae05:	66 0f 28 84 24 10 02 	movapd 0x210(%rsp),%xmm0
    ae0c:	00 00 
    ae0e:	48 83 c7 60          	add    $0x60,%rdi
    ae12:	66 0f 28 94 24 20 02 	movapd 0x220(%rsp),%xmm2
    ae19:	00 00 
    ae1b:	66 41 0f 59 cf       	mulpd  %xmm15,%xmm1
    ae20:	66 0f 28 a4 24 70 02 	movapd 0x270(%rsp),%xmm4
    ae27:	00 00 
    ae29:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
    ae2e:	66 41 0f 59 42 e0    	mulpd  -0x20(%r10),%xmm0
    ae34:	66 41 0f 59 52 f0    	mulpd  -0x10(%r10),%xmm2
    ae3a:	66 0f 59 a7 80 03 00 	mulpd  0x380(%rdi),%xmm4
    ae41:	00 
    ae42:	66 0f 58 cb          	addpd  %xmm3,%xmm1
    ae46:	66 0f 28 9f 50 03 00 	movapd 0x350(%rdi),%xmm3
    ae4d:	00 
    ae4e:	0f 29 84 24 60 03 00 	movaps %xmm0,0x360(%rsp)
    ae55:	00 
    ae56:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
    ae5b:	0f 29 94 24 70 03 00 	movaps %xmm2,0x370(%rsp)
    ae62:	00 
    ae63:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    ae67:	66 0f 28 41 b0       	movapd -0x50(%rcx),%xmm0
    ae6c:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
    ae71:	66 0f 58 c3          	addpd  %xmm3,%xmm0
    ae75:	66 0f 28 59 c0       	movapd -0x40(%rcx),%xmm3
    ae7a:	66 41 0f 59 d9       	mulpd  %xmm9,%xmm3
    ae7f:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    ae83:	66 0f 28 97 60 03 00 	movapd 0x360(%rdi),%xmm2
    ae8a:	00 
    ae8b:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
    ae8f:	66 0f 58 da          	addpd  %xmm2,%xmm3
    ae93:	66 0f 28 51 d0       	movapd -0x30(%rcx),%xmm2
    ae98:	66 41 0f 59 d0       	mulpd  %xmm8,%xmm2
    ae9d:	66 0f 58 d9          	addpd  %xmm1,%xmm3
    aea1:	66 0f 28 8f 70 03 00 	movapd 0x370(%rdi),%xmm1
    aea8:	00 
    aea9:	66 0f 59 ce          	mulpd  %xmm6,%xmm1
    aead:	66 0f 58 d1          	addpd  %xmm1,%xmm2
    aeb1:	66 0f 28 8c 24 50 02 	movapd 0x250(%rsp),%xmm1
    aeb8:	00 00 
    aeba:	66 0f 59 8f 90 03 00 	mulpd  0x390(%rdi),%xmm1
    aec1:	00 
    aec2:	66 0f 58 d0          	addpd  %xmm0,%xmm2
    aec6:	66 0f 28 84 24 60 02 	movapd 0x260(%rsp),%xmm0
    aecd:	00 00 
    aecf:	66 0f 59 41 f0       	mulpd  -0x10(%rcx),%xmm0
    aed4:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    aed8:	66 0f 28 49 e0       	movapd -0x20(%rcx),%xmm1
    aedd:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
    aee1:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    aee5:	41 0f 29 45 f0       	movaps %xmm0,-0x10(%r13)
    aeea:	66 41 0f 58 41 f0    	addpd  -0x10(%r9),%xmm0
    aef0:	66 0f 58 cc          	addpd  %xmm4,%xmm1
    aef4:	41 0f 29 41 f0       	movaps %xmm0,-0x10(%r9)
    aef9:	66 0f 58 cb          	addpd  %xmm3,%xmm1
    aefd:	41 0f 29 4d e0       	movaps %xmm1,-0x20(%r13)
    af02:	66 41 0f 58 49 e0    	addpd  -0x20(%r9),%xmm1
    af08:	41 0f 29 49 e0       	movaps %xmm1,-0x20(%r9)
    af0d:	49 39 cf             	cmp    %rcx,%r15
    af10:	0f 85 d3 fe ff ff    	jne    ade9 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x1589>
    af16:	49 83 c0 03          	add    $0x3,%r8
    af1a:	48 83 c6 60          	add    $0x60,%rsi
    af1e:	49 83 c6 60          	add    $0x60,%r14
    af22:	48 83 c2 60          	add    $0x60,%rdx
    af26:	48 05 e0 00 00 00    	add    $0xe0,%rax
    af2c:	49 83 f8 0c          	cmp    $0xc,%r8
    af30:	0f 85 28 fe ff ff    	jne    ad5e <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x14fe>
    af36:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
    af3d:	00 
    af3e:	48 8b 8c 24 70 01 00 	mov    0x170(%rsp),%rcx
    af45:	00 
    af46:	4c 8d bc 24 80 14 00 	lea    0x1480(%rsp),%r15
    af4d:	00 
    af4e:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
    af55:	00 
    af56:	66 0f 28 84 24 30 04 	movapd 0x430(%rsp),%xmm0
    af5d:	00 00 
    af5f:	66 0f 28 8c 24 20 04 	movapd 0x420(%rsp),%xmm1
    af66:	00 00 
    af68:	66 0f 28 bc 24 00 03 	movapd 0x300(%rsp),%xmm7
    af6f:	00 00 
    af71:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    af76:	66 0f 28 b4 24 00 02 	movapd 0x200(%rsp),%xmm6
    af7d:	00 00 
    af7f:	66 44 0f 28 bc 24 f0 	movapd 0x1f0(%rsp),%xmm15
    af86:	01 00 00 
    af89:	66 41 0f 59 cc       	mulpd  %xmm12,%xmm1
    af8e:	66 0f 58 84 24 d0 03 	addpd  0x3d0(%rsp),%xmm0
    af95:	00 00 
    af97:	66 0f 28 94 24 d0 01 	movapd 0x1d0(%rsp),%xmm2
    af9e:	00 00 
    afa0:	4c 8b 84 24 40 01 00 	mov    0x140(%rsp),%r8
    afa7:	00 
    afa8:	4c 8b 8c 24 c0 01 00 	mov    0x1c0(%rsp),%r9
    afaf:	00 
    afb0:	66 0f 58 8c 24 c0 03 	addpd  0x3c0(%rsp),%xmm1
    afb7:	00 00 
    afb9:	66 44 0f 28 b4 24 80 	movapd 0x180(%rsp),%xmm14
    afc0:	01 00 00 
    afc3:	0f 29 84 24 90 04 00 	movaps %xmm0,0x490(%rsp)
    afca:	00 
    afcb:	66 0f 28 84 24 50 04 	movapd 0x450(%rsp),%xmm0
    afd2:	00 00 
    afd4:	66 44 0f 28 8c 24 80 	movapd 0x1e80(%rsp),%xmm9
    afdb:	1e 00 00 
    afde:	66 44 0f 28 84 24 90 	movapd 0x1e90(%rsp),%xmm8
    afe5:	1e 00 00 
    afe8:	0f 29 8c 24 80 04 00 	movaps %xmm1,0x480(%rsp)
    afef:	00 
    aff0:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    aff5:	66 0f 28 8c 24 40 04 	movapd 0x440(%rsp),%xmm1
    affc:	00 00 
    affe:	66 0f 58 84 24 f0 03 	addpd  0x3f0(%rsp),%xmm0
    b005:	00 00 
    b007:	66 41 0f 59 cc       	mulpd  %xmm12,%xmm1
    b00c:	66 0f 58 8c 24 e0 03 	addpd  0x3e0(%rsp),%xmm1
    b013:	00 00 
    b015:	0f 29 84 24 b0 04 00 	movaps %xmm0,0x4b0(%rsp)
    b01c:	00 
    b01d:	66 0f 28 84 24 70 04 	movapd 0x470(%rsp),%xmm0
    b024:	00 00 
    b026:	0f 29 8c 24 a0 04 00 	movaps %xmm1,0x4a0(%rsp)
    b02d:	00 
    b02e:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    b033:	66 0f 28 8c 24 60 04 	movapd 0x460(%rsp),%xmm1
    b03a:	00 00 
    b03c:	66 0f 58 84 24 10 04 	addpd  0x410(%rsp),%xmm0
    b043:	00 00 
    b045:	66 41 0f 59 cc       	mulpd  %xmm12,%xmm1
    b04a:	66 0f 58 8c 24 00 04 	addpd  0x400(%rsp),%xmm1
    b051:	00 00 
    b053:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
    b05a:	00 
    b05b:	0f 29 84 24 d0 04 00 	movaps %xmm0,0x4d0(%rsp)
    b062:	00 
    b063:	0f 29 8c 24 40 03 00 	movaps %xmm1,0x340(%rsp)
    b06a:	00 
    b06b:	0f 29 8c 24 c0 04 00 	movaps %xmm1,0x4c0(%rsp)
    b072:	00 
    b073:	0f 29 bc 24 c0 01 00 	movaps %xmm7,0x1c0(%rsp)
    b07a:	00 
    b07b:	66 0f 28 bc 24 10 03 	movapd 0x310(%rsp),%xmm7
    b082:	00 00 
    b084:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
    b08b:	00 
    b08c:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
    b093:	00 
    b094:	48 89 b4 24 20 01 00 	mov    %rsi,0x120(%rsp)
    b09b:	00 
    b09c:	4c 89 9c 24 00 01 00 	mov    %r11,0x100(%rsp)
    b0a3:	00 
    b0a4:	4d 89 c3             	mov    %r8,%r11
    b0a7:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b0ae:	00 
    b0af:	49 89 c4             	mov    %rax,%r12
    b0b2:	48 89 9c 24 e0 00 00 	mov    %rbx,0xe0(%rsp)
    b0b9:	00 
    b0ba:	31 db                	xor    %ebx,%ebx
    b0bc:	0f 29 bc 24 d0 01 00 	movaps %xmm7,0x1d0(%rsp)
    b0c3:	00 
    b0c4:	0f 29 b4 24 80 01 00 	movaps %xmm6,0x180(%rsp)
    b0cb:	00 
    b0cc:	44 0f 29 bc 24 70 01 	movaps %xmm15,0x170(%rsp)
    b0d3:	00 00 
    b0d5:	0f 29 94 24 60 01 00 	movaps %xmm2,0x160(%rsp)
    b0dc:	00 
    b0dd:	44 0f 29 b4 24 50 01 	movaps %xmm14,0x150(%rsp)
    b0e4:	00 00 
    b0e6:	66 41 0f 28 b7 40 05 	movapd 0x540(%r15),%xmm6
    b0ed:	00 00 
    b0ef:	66 45 0f 28 11       	movapd (%r9),%xmm10
    b0f4:	4c 89 e6             	mov    %r12,%rsi
    b0f7:	4d 89 dd             	mov    %r11,%r13
    b0fa:	66 45 0f 28 b7 20 05 	movapd 0x520(%r15),%xmm14
    b101:	00 00 
    b103:	66 41 0f 28 79 10    	movapd 0x10(%r9),%xmm7
    b109:	4c 89 f9             	mov    %r15,%rcx
    b10c:	48 8d 94 24 80 14 00 	lea    0x1480(%rsp),%rdx
    b113:	00 
    b114:	0f 29 b4 24 10 02 00 	movaps %xmm6,0x210(%rsp)
    b11b:	00 
    b11c:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b123:	00 
    b124:	66 41 0f 28 b7 50 05 	movapd 0x550(%r15),%xmm6
    b12b:	00 00 
    b12d:	4c 8b b4 24 90 01 00 	mov    0x190(%rsp),%r14
    b134:	00 
    b135:	4c 8b 94 24 b0 01 00 	mov    0x1b0(%rsp),%r10
    b13c:	00 
    b13d:	0f 29 b4 24 00 02 00 	movaps %xmm6,0x200(%rsp)
    b144:	00 
    b145:	66 41 0f 28 71 20    	movapd 0x20(%r9),%xmm6
    b14b:	66 45 0f 28 9f 30 05 	movapd 0x530(%r15),%xmm11
    b152:	00 00 
    b154:	48 8b bc 24 a0 01 00 	mov    0x1a0(%rsp),%rdi
    b15b:	00 
    b15c:	0f 29 b4 24 f0 01 00 	movaps %xmm6,0x1f0(%rsp)
    b163:	00 
    b164:	66 41 0f 28 71 30    	movapd 0x30(%r9),%xmm6
    b16a:	0f 29 b4 24 e0 01 00 	movaps %xmm6,0x1e0(%rsp)
    b171:	00 
    b172:	66 41 0f 28 b7 60 05 	movapd 0x560(%r15),%xmm6
    b179:	00 00 
    b17b:	0f 29 b4 24 20 02 00 	movaps %xmm6,0x220(%rsp)
    b182:	00 
    b183:	66 41 0f 28 b7 70 05 	movapd 0x570(%r15),%xmm6
    b18a:	00 00 
    b18c:	0f 29 b4 24 60 02 00 	movaps %xmm6,0x260(%rsp)
    b193:	00 
    b194:	66 41 0f 28 71 40    	movapd 0x40(%r9),%xmm6
    b19a:	0f 29 b4 24 70 02 00 	movaps %xmm6,0x270(%rsp)
    b1a1:	00 
    b1a2:	66 41 0f 28 71 50    	movapd 0x50(%r9),%xmm6
    b1a8:	0f 29 b4 24 50 02 00 	movaps %xmm6,0x250(%rsp)
    b1af:	00 
    b1b0:	66 41 0f 28 52 10    	movapd 0x10(%r10),%xmm2
    b1b6:	66 0f 58 57 10       	addpd  0x10(%rdi),%xmm2
    b1bb:	48 83 c0 60          	add    $0x60,%rax
    b1bf:	48 83 c2 20          	add    $0x20,%rdx
    b1c3:	66 41 0f 28 1a       	movapd (%r10),%xmm3
    b1c8:	66 0f 58 1f          	addpd  (%rdi),%xmm3
    b1cc:	48 83 c1 20          	add    $0x20,%rcx
    b1d0:	48 83 c7 20          	add    $0x20,%rdi
    b1d4:	66 0f 28 a1 90 06 00 	movapd 0x690(%rcx),%xmm4
    b1db:	00 
    b1dc:	66 0f 28 31          	movapd (%rcx),%xmm6
    b1e0:	49 83 c2 20          	add    $0x20,%r10
    b1e4:	49 83 c5 20          	add    $0x20,%r13
    b1e8:	66 41 0f 5e d5       	divpd  %xmm13,%xmm2
    b1ed:	66 0f 28 49 10       	movapd 0x10(%rcx),%xmm1
    b1f2:	66 0f 58 a2 10 08 00 	addpd  0x810(%rdx),%xmm4
    b1f9:	00 
    b1fa:	48 83 c6 20          	add    $0x20,%rsi
    b1fe:	66 44 0f 28 bc 24 d0 	movapd 0x1d0(%rsp),%xmm15
    b205:	01 00 00 
    b208:	66 0f 28 aa 00 08 00 	movapd 0x800(%rdx),%xmm5
    b20f:	00 
    b210:	49 83 c6 20          	add    $0x20,%r14
    b214:	66 0f 58 a9 80 06 00 	addpd  0x680(%rcx),%xmm5
    b21b:	00 
    b21c:	66 44 0f 59 f9       	mulpd  %xmm1,%xmm15
    b221:	66 41 0f 59 c8       	mulpd  %xmm8,%xmm1
    b226:	66 41 0f 5e e5       	divpd  %xmm13,%xmm4
    b22b:	66 0f 28 c2          	movapd %xmm2,%xmm0
    b22f:	66 41 0f 5c c7       	subpd  %xmm15,%xmm0
    b234:	66 45 0f 28 7d f0    	movapd -0x10(%r13),%xmm15
    b23a:	66 45 0f 59 f8       	mulpd  %xmm8,%xmm15
    b23f:	66 41 0f 5c c7       	subpd  %xmm15,%xmm0
    b244:	66 0f 59 84 24 b0 02 	mulpd  0x2b0(%rsp),%xmm0
    b24b:	00 00 
    b24d:	66 41 0f 5e dd       	divpd  %xmm13,%xmm3
    b252:	66 44 0f 28 fc       	movapd %xmm4,%xmm15
    b257:	66 44 0f 5c f9       	subpd  %xmm1,%xmm15
    b25c:	66 44 0f 59 bc 24 90 	mulpd  0x290(%rsp),%xmm15
    b263:	02 00 00 
    b266:	66 41 0f 58 c7       	addpd  %xmm15,%xmm0
    b26b:	66 0f 58 46 f0       	addpd  -0x10(%rsi),%xmm0
    b270:	66 44 0f 28 bc 24 c0 	movapd 0x1c0(%rsp),%xmm15
    b277:	01 00 00 
    b27a:	66 44 0f 59 fe       	mulpd  %xmm6,%xmm15
    b27f:	66 41 0f 59 f1       	mulpd  %xmm9,%xmm6
    b284:	0f 29 46 f0          	movaps %xmm0,-0x10(%rsi)
    b288:	66 0f 28 82 b0 04 00 	movapd 0x4b0(%rdx),%xmm0
    b28f:	00 
    b290:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    b295:	66 41 0f 5e ed       	divpd  %xmm13,%xmm5
    b29a:	66 0f 58 e0          	addpd  %xmm0,%xmm4
    b29e:	66 41 0f 28 46 e0    	movapd -0x20(%r14),%xmm0
    b2a4:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    b2a9:	66 0f 28 cb          	movapd %xmm3,%xmm1
    b2ad:	66 41 0f 5c cf       	subpd  %xmm15,%xmm1
    b2b2:	66 45 0f 28 7d e0    	movapd -0x20(%r13),%xmm15
    b2b8:	66 45 0f 59 f9       	mulpd  %xmm9,%xmm15
    b2bd:	66 0f 58 d8          	addpd  %xmm0,%xmm3
    b2c1:	66 41 0f 28 46 f0    	movapd -0x10(%r14),%xmm0
    b2c7:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    b2cc:	66 41 0f 5c cf       	subpd  %xmm15,%xmm1
    b2d1:	66 0f 59 8c 24 a0 02 	mulpd  0x2a0(%rsp),%xmm1
    b2d8:	00 00 
    b2da:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    b2de:	66 0f 28 d3          	movapd %xmm3,%xmm2
    b2e2:	66 41 0f 59 d6       	mulpd  %xmm14,%xmm2
    b2e7:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
    b2ec:	66 44 0f 5c fe       	subpd  %xmm6,%xmm15
    b2f1:	66 44 0f 59 bc 24 80 	mulpd  0x280(%rsp),%xmm15
    b2f8:	02 00 00 
    b2fb:	66 41 0f 58 cf       	addpd  %xmm15,%xmm1
    b300:	66 0f 58 4e e0       	addpd  -0x20(%rsi),%xmm1
    b305:	0f 29 4e e0          	movaps %xmm1,-0x20(%rsi)
    b309:	66 0f 28 8a a0 04 00 	movapd 0x4a0(%rdx),%xmm1
    b310:	00 
    b311:	66 41 0f 59 cc       	mulpd  %xmm12,%xmm1
    b316:	66 0f 58 cd          	addpd  %xmm5,%xmm1
    b31a:	66 0f 28 e9          	movapd %xmm1,%xmm5
    b31e:	66 41 0f 59 ea       	mulpd  %xmm10,%xmm5
    b323:	66 0f 58 d5          	addpd  %xmm5,%xmm2
    b327:	66 0f 58 50 a0       	addpd  -0x60(%rax),%xmm2
    b32c:	66 0f 28 ec          	movapd %xmm4,%xmm5
    b330:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
    b334:	0f 29 50 a0          	movaps %xmm2,-0x60(%rax)
    b338:	66 0f 28 d0          	movapd %xmm0,%xmm2
    b33c:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
    b341:	66 0f 58 d5          	addpd  %xmm5,%xmm2
    b345:	66 0f 58 50 b0       	addpd  -0x50(%rax),%xmm2
    b34a:	66 0f 28 ac 24 f0 01 	movapd 0x1f0(%rsp),%xmm5
    b351:	00 00 
    b353:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
    b357:	0f 29 50 b0          	movaps %xmm2,-0x50(%rax)
    b35b:	66 0f 28 94 24 10 02 	movapd 0x210(%rsp),%xmm2
    b362:	00 00 
    b364:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
    b368:	66 0f 58 d5          	addpd  %xmm5,%xmm2
    b36c:	66 0f 58 50 c0       	addpd  -0x40(%rax),%xmm2
    b371:	66 0f 28 ac 24 e0 01 	movapd 0x1e0(%rsp),%xmm5
    b378:	00 00 
    b37a:	66 0f 59 8c 24 70 02 	mulpd  0x270(%rsp),%xmm1
    b381:	00 00 
    b383:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
    b387:	66 0f 59 9c 24 20 02 	mulpd  0x220(%rsp),%xmm3
    b38e:	00 00 
    b390:	0f 29 50 c0          	movaps %xmm2,-0x40(%rax)
    b394:	66 0f 28 94 24 00 02 	movapd 0x200(%rsp),%xmm2
    b39b:	00 00 
    b39d:	66 0f 59 a4 24 50 02 	mulpd  0x250(%rsp),%xmm4
    b3a4:	00 00 
    b3a6:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
    b3aa:	66 0f 59 84 24 60 02 	mulpd  0x260(%rsp),%xmm0
    b3b1:	00 00 
    b3b3:	66 0f 58 cb          	addpd  %xmm3,%xmm1
    b3b7:	66 0f 58 48 e0       	addpd  -0x20(%rax),%xmm1
    b3bc:	66 0f 58 d5          	addpd  %xmm5,%xmm2
    b3c0:	66 0f 58 50 d0       	addpd  -0x30(%rax),%xmm2
    b3c5:	66 0f 58 c4          	addpd  %xmm4,%xmm0
    b3c9:	66 0f 58 40 f0       	addpd  -0x10(%rax),%xmm0
    b3ce:	0f 29 48 e0          	movaps %xmm1,-0x20(%rax)
    b3d2:	0f 29 50 d0          	movaps %xmm2,-0x30(%rax)
    b3d6:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    b3da:	49 39 c0             	cmp    %rax,%r8
    b3dd:	0f 85 cd fd ff ff    	jne    b1b0 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x1950>
    b3e3:	48 83 c3 07          	add    $0x7,%rbx
    b3e7:	49 83 c7 60          	add    $0x60,%r15
    b3eb:	49 83 c3 60          	add    $0x60,%r11
    b3ef:	49 83 c1 60          	add    $0x60,%r9
    b3f3:	48 83 84 24 b0 01 00 	addq   $0x60,0x1b0(%rsp)
    b3fa:	00 60 
    b3fc:	49 81 c4 e0 00 00 00 	add    $0xe0,%r12
    b403:	48 83 fb 1c          	cmp    $0x1c,%rbx
    b407:	0f 85 d9 fc ff ff    	jne    b0e6 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x1886>
    b40d:	66 0f 28 b4 24 80 01 	movapd 0x180(%rsp),%xmm6
    b414:	00 00 
    b416:	45 31 ff             	xor    %r15d,%r15d
    b419:	66 0f 28 94 24 60 01 	movapd 0x160(%rsp),%xmm2
    b420:	00 00 
    b422:	4c 8d 94 24 80 14 00 	lea    0x1480(%rsp),%r10
    b429:	00 
    b42a:	66 0f 28 bc 24 a0 04 	movapd 0x4a0(%rsp),%xmm7
    b431:	00 00 
    b433:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
    b43a:	00 
    b43b:	4d 89 d5             	mov    %r10,%r13
    b43e:	4c 8d b4 24 a0 15 00 	lea    0x15a0(%rsp),%r14
    b445:	00 
    b446:	66 41 0f 59 f4       	mulpd  %xmm12,%xmm6
    b44b:	66 45 0f ef db       	pxor   %xmm11,%xmm11
    b450:	66 44 0f 28 bc 24 70 	movapd 0x170(%rsp),%xmm15
    b457:	01 00 00 
    b45a:	66 44 0f 28 b4 24 50 	movapd 0x150(%rsp),%xmm14
    b461:	01 00 00 
    b464:	66 41 0f 59 d4       	mulpd  %xmm12,%xmm2
    b469:	0f 29 7c 24 30       	movaps %xmm7,0x30(%rsp)
    b46e:	66 0f 28 bc 24 b0 04 	movapd 0x4b0(%rsp),%xmm7
    b475:	00 00 
    b477:	48 8b 8c 24 40 01 00 	mov    0x140(%rsp),%rcx
    b47e:	00 
    b47f:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
    b486:	00 
    b487:	4c 8b 9c 24 00 01 00 	mov    0x100(%rsp),%r11
    b48e:	00 
    b48f:	0f 29 7c 24 20       	movaps %xmm7,0x20(%rsp)
    b494:	4c 8b a4 24 f0 00 00 	mov    0xf0(%rsp),%r12
    b49b:	00 
    b49c:	66 0f 28 bc 24 40 1d 	movapd 0x1d40(%rsp),%xmm7
    b4a3:	00 00 
    b4a5:	48 8b 9c 24 e0 00 00 	mov    0xe0(%rsp),%rbx
    b4ac:	00 
    b4ad:	0f 29 b4 24 c0 00 00 	movaps %xmm6,0xc0(%rsp)
    b4b4:	00 
    b4b5:	66 0f 28 b4 24 e0 02 	movapd 0x2e0(%rsp),%xmm6
    b4bc:	00 00 
    b4be:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    b4c5:	00 
    b4c6:	66 41 0f 59 f4       	mulpd  %xmm12,%xmm6
    b4cb:	66 44 0f 59 a4 24 f0 	mulpd  0x2f0(%rsp),%xmm12
    b4d2:	02 00 00 
    b4d5:	0f 29 b4 24 d0 00 00 	movaps %xmm6,0xd0(%rsp)
    b4dc:	00 
    b4dd:	66 0f 28 b4 24 00 1d 	movapd 0x1d00(%rsp),%xmm6
    b4e4:	00 00 
    b4e6:	44 0f 29 a4 24 a0 00 	movaps %xmm12,0xa0(%rsp)
    b4ed:	00 00 
    b4ef:	0f 29 74 24 70       	movaps %xmm6,0x70(%rsp)
    b4f4:	66 0f 28 b4 24 10 1d 	movapd 0x1d10(%rsp),%xmm6
    b4fb:	00 00 
    b4fd:	0f 29 74 24 60       	movaps %xmm6,0x60(%rsp)
    b502:	66 0f 28 b4 24 80 04 	movapd 0x480(%rsp),%xmm6
    b509:	00 00 
    b50b:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
    b510:	66 0f 28 b4 24 90 04 	movapd 0x490(%rsp),%xmm6
    b517:	00 00 
    b519:	0f 29 74 24 40       	movaps %xmm6,0x40(%rsp)
    b51e:	66 0f 28 b4 24 20 1d 	movapd 0x1d20(%rsp),%xmm6
    b525:	00 00 
    b527:	0f 29 b4 24 20 01 00 	movaps %xmm6,0x120(%rsp)
    b52e:	00 
    b52f:	66 0f 28 b4 24 30 1d 	movapd 0x1d30(%rsp),%xmm6
    b536:	00 00 
    b538:	0f 29 bc 24 30 01 00 	movaps %xmm7,0x130(%rsp)
    b53f:	00 
    b540:	66 0f 28 bc 24 50 1d 	movapd 0x1d50(%rsp),%xmm7
    b547:	00 00 
    b549:	66 0f 28 84 24 80 02 	movapd 0x280(%rsp),%xmm0
    b550:	00 00 
    b552:	66 0f 28 8c 24 90 02 	movapd 0x290(%rsp),%xmm1
    b559:	00 00 
    b55b:	0f 29 bc 24 90 00 00 	movaps %xmm7,0x90(%rsp)
    b562:	00 
    b563:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
    b568:	66 0f 28 bc 24 c0 04 	movapd 0x4c0(%rsp),%xmm7
    b56f:	00 00 
    b571:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
    b576:	0f 29 bc 24 e0 00 00 	movaps %xmm7,0xe0(%rsp)
    b57d:	00 
    b57e:	66 0f 28 bc 24 d0 04 	movapd 0x4d0(%rsp),%xmm7
    b585:	00 00 
    b587:	0f 29 bc 24 80 00 00 	movaps %xmm7,0x80(%rsp)
    b58e:	00 
    b58f:	66 0f 28 bc 24 a0 02 	movapd 0x2a0(%rsp),%xmm7
    b596:	00 00 
    b598:	66 0f 28 ef          	movapd %xmm7,%xmm5
    b59c:	66 41 0f 59 ef       	mulpd  %xmm15,%xmm5
    b5a1:	66 0f 59 bc 24 40 02 	mulpd  0x240(%rsp),%xmm7
    b5a8:	00 00 
    b5aa:	0f 29 ac 24 70 01 00 	movaps %xmm5,0x170(%rsp)
    b5b1:	00 
    b5b2:	66 0f 28 ac 24 b0 02 	movapd 0x2b0(%rsp),%xmm5
    b5b9:	00 00 
    b5bb:	66 0f 58 c7          	addpd  %xmm7,%xmm0
    b5bf:	66 0f 28 dd          	movapd %xmm5,%xmm3
    b5c3:	66 0f 59 ac 24 30 02 	mulpd  0x230(%rsp),%xmm5
    b5ca:	00 00 
    b5cc:	66 41 0f 59 de       	mulpd  %xmm14,%xmm3
    b5d1:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
    b5d8:	00 
    b5d9:	66 0f 28 c5          	movapd %xmm5,%xmm0
    b5dd:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    b5e1:	0f 29 9c 24 60 01 00 	movaps %xmm3,0x160(%rsp)
    b5e8:	00 
    b5e9:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
    b5f0:	00 
    b5f1:	66 45 0f 28 6d 20    	movapd 0x20(%r13),%xmm13
    b5f7:	66 44 0f 28 16       	movapd (%rsi),%xmm10
    b5fc:	4c 89 df             	mov    %r11,%rdi
    b5ff:	48 89 c2             	mov    %rax,%rdx
    b602:	66 0f 28 7c 24 70    	movapd 0x70(%rsp),%xmm7
    b608:	66 41 0f 28 df       	movapd %xmm15,%xmm3
    b60d:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
    b612:	66 0f 28 4c 24 50    	movapd 0x50(%rsp),%xmm1
    b618:	66 41 0f 59 dd       	mulpd  %xmm13,%xmm3
    b61d:	66 45 0f 28 65 30    	movapd 0x30(%r13),%xmm12
    b623:	66 0f 28 64 24 60    	movapd 0x60(%rsp),%xmm4
    b629:	44 0f 29 94 24 90 01 	movaps %xmm10,0x190(%rsp)
    b630:	00 00 
    b632:	66 0f 28 c7          	movapd %xmm7,%xmm0
    b636:	66 0f 28 ef          	movapd %xmm7,%xmm5
    b63a:	66 44 0f 28 4e 10    	movapd 0x10(%rsi),%xmm9
    b640:	66 44 0f 28 84 24 30 	movapd 0x230(%rsp),%xmm8
    b647:	02 00 00 
    b64a:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
    b64f:	66 45 0f 28 55 40    	movapd 0x40(%r13),%xmm10
    b655:	4c 8d 84 24 80 14 00 	lea    0x1480(%rsp),%r8
    b65c:	00 
    b65d:	44 0f 29 8c 24 80 01 	movaps %xmm9,0x180(%rsp)
    b664:	00 00 
    b666:	66 41 0f 59 cd       	mulpd  %xmm13,%xmm1
    b66b:	66 41 0f 59 d4       	mulpd  %xmm12,%xmm2
    b670:	66 0f 59 df          	mulpd  %xmm7,%xmm3
    b674:	66 0f 28 bc 24 40 02 	movapd 0x240(%rsp),%xmm7
    b67b:	00 00 
    b67d:	66 0f 58 9c 24 c0 00 	addpd  0xc0(%rsp),%xmm3
    b684:	00 00 
    b686:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    b68a:	66 0f 28 c7          	movapd %xmm7,%xmm0
    b68e:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
    b693:	66 0f 59 d4          	mulpd  %xmm4,%xmm2
    b697:	66 0f 58 94 24 b0 00 	addpd  0xb0(%rsp),%xmm2
    b69e:	00 00 
    b6a0:	66 41 0f 59 cf       	mulpd  %xmm15,%xmm1
    b6a5:	66 0f 59 c5          	mulpd  %xmm5,%xmm0
    b6a9:	66 0f 28 ec          	movapd %xmm4,%xmm5
    b6ad:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
    b6b2:	66 45 0f 28 4d 50    	movapd 0x50(%r13),%xmm9
    b6b8:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    b6bc:	66 0f 28 44 24 40    	movapd 0x40(%rsp),%xmm0
    b6c2:	66 0f 58 8c 24 d0 00 	addpd  0xd0(%rsp),%xmm1
    b6c9:	00 00 
    b6cb:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    b6d0:	66 0f 58 c4          	addpd  %xmm4,%xmm0
    b6d4:	66 41 0f 28 e0       	movapd %xmm8,%xmm4
    b6d9:	66 41 0f 59 e4       	mulpd  %xmm12,%xmm4
    b6de:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
    b6e3:	66 0f 59 e5          	mulpd  %xmm5,%xmm4
    b6e7:	66 0f 58 c4          	addpd  %xmm4,%xmm0
    b6eb:	66 41 0f 28 e7       	movapd %xmm15,%xmm4
    b6f0:	66 0f 58 84 24 a0 00 	addpd  0xa0(%rsp),%xmm0
    b6f7:	00 00 
    b6f9:	66 41 0f 59 e2       	mulpd  %xmm10,%xmm4
    b6fe:	66 0f 59 a4 24 20 01 	mulpd  0x120(%rsp),%xmm4
    b705:	00 00 
    b707:	66 0f 58 dc          	addpd  %xmm4,%xmm3
    b70b:	66 41 0f 28 e6       	movapd %xmm14,%xmm4
    b710:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
    b715:	66 0f 59 e6          	mulpd  %xmm6,%xmm4
    b719:	66 0f 58 e2          	addpd  %xmm2,%xmm4
    b71d:	66 0f 28 56 20       	movapd 0x20(%rsi),%xmm2
    b722:	0f 29 94 24 60 02 00 	movaps %xmm2,0x260(%rsp)
    b729:	00 
    b72a:	66 0f 28 56 30       	movapd 0x30(%rsi),%xmm2
    b72f:	66 0f 28 ec          	movapd %xmm4,%xmm5
    b733:	66 0f 28 a4 24 20 01 	movapd 0x120(%rsp),%xmm4
    b73a:	00 00 
    b73c:	0f 29 94 24 50 02 00 	movaps %xmm2,0x250(%rsp)
    b743:	00 
    b744:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
    b74a:	66 0f 59 a4 24 60 02 	mulpd  0x260(%rsp),%xmm4
    b751:	00 00 
    b753:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
    b758:	66 0f 58 d4          	addpd  %xmm4,%xmm2
    b75c:	66 0f 28 e7          	movapd %xmm7,%xmm4
    b760:	66 41 0f 28 7d 70    	movapd 0x70(%r13),%xmm7
    b766:	66 41 0f 59 e2       	mulpd  %xmm10,%xmm4
    b76b:	66 0f 59 a4 24 20 01 	mulpd  0x120(%rsp),%xmm4
    b772:	00 00 
    b774:	66 41 0f 59 d7       	mulpd  %xmm15,%xmm2
    b779:	66 0f 58 d4          	addpd  %xmm4,%xmm2
    b77d:	66 0f 28 a4 24 50 02 	movapd 0x250(%rsp),%xmm4
    b784:	00 00 
    b786:	66 0f 59 e6          	mulpd  %xmm6,%xmm4
    b78a:	66 0f 58 d1          	addpd  %xmm1,%xmm2
    b78e:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
    b794:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
    b799:	66 0f 58 cc          	addpd  %xmm4,%xmm1
    b79d:	66 41 0f 28 e0       	movapd %xmm8,%xmm4
    b7a2:	66 45 0f 28 45 60    	movapd 0x60(%r13),%xmm8
    b7a8:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
    b7ad:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
    b7b2:	66 0f 59 e6          	mulpd  %xmm6,%xmm4
    b7b6:	66 0f 58 cc          	addpd  %xmm4,%xmm1
    b7ba:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    b7be:	66 0f 28 e1          	movapd %xmm1,%xmm4
    b7c2:	66 0f 28 4e 40       	movapd 0x40(%rsi),%xmm1
    b7c7:	0f 29 8c 24 20 02 00 	movaps %xmm1,0x220(%rsp)
    b7ce:	00 
    b7cf:	66 0f 28 46 50       	movapd 0x50(%rsi),%xmm0
    b7d4:	66 0f 59 8c 24 30 01 	mulpd  0x130(%rsp),%xmm1
    b7db:	00 00 
    b7dd:	0f 29 84 24 70 02 00 	movaps %xmm0,0x270(%rsp)
    b7e4:	00 
    b7e5:	66 0f 28 c1          	movapd %xmm1,%xmm0
    b7e9:	66 0f 28 8c 24 e0 00 	movapd 0xe0(%rsp),%xmm1
    b7f0:	00 00 
    b7f2:	66 41 0f 59 c8       	mulpd  %xmm8,%xmm1
    b7f7:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    b7fb:	66 0f 28 8c 24 40 02 	movapd 0x240(%rsp),%xmm1
    b802:	00 00 
    b804:	66 41 0f 59 c8       	mulpd  %xmm8,%xmm1
    b809:	66 0f 59 8c 24 30 01 	mulpd  0x130(%rsp),%xmm1
    b810:	00 00 
    b812:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
    b817:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    b81b:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
    b820:	66 41 0f 59 c8       	mulpd  %xmm8,%xmm1
    b825:	66 0f 59 8c 24 30 01 	mulpd  0x130(%rsp),%xmm1
    b82c:	00 00 
    b82e:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    b832:	66 0f 59 84 24 a0 02 	mulpd  0x2a0(%rsp),%xmm0
    b839:	00 00 
    b83b:	66 0f 58 cb          	addpd  %xmm3,%xmm1
    b83f:	66 0f 59 8c 24 80 02 	mulpd  0x280(%rsp),%xmm1
    b846:	00 00 
    b848:	66 0f 28 9c 24 80 00 	movapd 0x80(%rsp),%xmm3
    b84f:	00 00 
    b851:	66 0f 59 df          	mulpd  %xmm7,%xmm3
    b855:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    b859:	66 0f 58 40 60       	addpd  0x60(%rax),%xmm0
    b85e:	66 0f 28 8c 24 70 02 	movapd 0x270(%rsp),%xmm1
    b865:	00 00 
    b867:	0f 29 40 60          	movaps %xmm0,0x60(%rax)
    b86b:	66 0f 28 c3          	movapd %xmm3,%xmm0
    b86f:	66 0f 28 9c 24 90 00 	movapd 0x90(%rsp),%xmm3
    b876:	00 00 
    b878:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
    b87c:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    b880:	66 0f 28 8c 24 30 02 	movapd 0x230(%rsp),%xmm1
    b887:	00 00 
    b889:	66 0f 59 cf          	mulpd  %xmm7,%xmm1
    b88d:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
    b892:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
    b896:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    b89a:	66 0f 28 cf          	movapd %xmm7,%xmm1
    b89e:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
    b8a3:	66 0f 58 c4          	addpd  %xmm4,%xmm0
    b8a7:	66 0f 59 84 24 b0 02 	mulpd  0x2b0(%rsp),%xmm0
    b8ae:	00 00 
    b8b0:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
    b8b4:	66 0f 58 cd          	addpd  %xmm5,%xmm1
    b8b8:	66 41 0f 28 aa 80 0e 	movapd 0xe80(%r10),%xmm5
    b8bf:	00 00 
    b8c1:	66 0f 59 8c 24 90 02 	mulpd  0x290(%rsp),%xmm1
    b8c8:	00 00 
    b8ca:	0f 29 ac 24 f0 01 00 	movaps %xmm5,0x1f0(%rsp)
    b8d1:	00 
    b8d2:	66 41 0f 28 aa 90 0e 	movapd 0xe90(%r10),%xmm5
    b8d9:	00 00 
    b8db:	0f 29 ac 24 e0 01 00 	movaps %xmm5,0x1e0(%rsp)
    b8e2:	00 
    b8e3:	66 41 0f 28 aa a0 0e 	movapd 0xea0(%r10),%xmm5
    b8ea:	00 00 
    b8ec:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    b8f0:	66 0f 58 40 70       	addpd  0x70(%rax),%xmm0
    b8f5:	0f 29 ac 24 d0 01 00 	movaps %xmm5,0x1d0(%rsp)
    b8fc:	00 
    b8fd:	66 41 0f 28 aa b0 0e 	movapd 0xeb0(%r10),%xmm5
    b904:	00 00 
    b906:	0f 29 ac 24 c0 01 00 	movaps %xmm5,0x1c0(%rsp)
    b90d:	00 
    b90e:	66 41 0f 28 aa c0 0e 	movapd 0xec0(%r10),%xmm5
    b915:	00 00 
    b917:	0f 29 40 70          	movaps %xmm0,0x70(%rax)
    b91b:	0f 29 ac 24 b0 01 00 	movaps %xmm5,0x1b0(%rsp)
    b922:	00 
    b923:	66 41 0f 28 aa d0 0e 	movapd 0xed0(%r10),%xmm5
    b92a:	00 00 
    b92c:	0f 29 ac 24 a0 01 00 	movaps %xmm5,0x1a0(%rsp)
    b933:	00 
    b934:	66 41 0f 28 aa e0 0e 	movapd 0xee0(%r10),%xmm5
    b93b:	00 00 
    b93d:	0f 29 ac 24 00 02 00 	movaps %xmm5,0x200(%rsp)
    b944:	00 
    b945:	4c 8b 8c 24 18 01 00 	mov    0x118(%rsp),%r9
    b94c:	00 
    b94d:	66 41 0f 28 aa f0 0e 	movapd 0xef0(%r10),%xmm5
    b954:	00 00 
    b956:	44 0f 29 bc 24 00 01 	movaps %xmm15,0x100(%rsp)
    b95d:	00 00 
    b95f:	0f 29 ac 24 10 02 00 	movaps %xmm5,0x210(%rsp)
    b966:	00 
    b967:	44 0f 29 b4 24 f0 00 	movaps %xmm14,0xf0(%rsp)
    b96e:	00 00 
    b970:	66 41 0f 28 09       	movapd (%r9),%xmm1
    b975:	49 83 c0 60          	add    $0x60,%r8
    b979:	66 41 0f 28 80 80 08 	movapd 0x880(%r8),%xmm0
    b980:	00 00 
    b982:	49 83 c1 60          	add    $0x60,%r9
    b986:	66 41 0f 28 90 90 08 	movapd 0x890(%r8),%xmm2
    b98d:	00 00 
    b98f:	48 83 c2 20          	add    $0x20,%rdx
    b993:	48 83 c7 20          	add    $0x20,%rdi
    b997:	66 41 0f 28 a0 a0 08 	movapd 0x8a0(%r8),%xmm4
    b99e:	00 00 
    b9a0:	66 41 0f 59 cd       	mulpd  %xmm13,%xmm1
    b9a5:	66 44 0f 28 f0       	movapd %xmm0,%xmm14
    b9aa:	66 44 0f 28 bc 24 70 	movapd 0x270(%rsp),%xmm15
    b9b1:	02 00 00 
    b9b4:	66 45 0f 59 f5       	mulpd  %xmm13,%xmm14
    b9b9:	66 0f 28 da          	movapd %xmm2,%xmm3
    b9bd:	66 0f 28 ec          	movapd %xmm4,%xmm5
    b9c1:	66 0f 59 84 24 90 01 	mulpd  0x190(%rsp),%xmm0
    b9c8:	00 00 
    b9ca:	66 0f 59 94 24 80 01 	mulpd  0x180(%rsp),%xmm2
    b9d1:	00 00 
    b9d3:	66 41 0f 59 ea       	mulpd  %xmm10,%xmm5
    b9d8:	66 41 0f 59 dc       	mulpd  %xmm12,%xmm3
    b9dd:	66 0f 59 a4 24 60 02 	mulpd  0x260(%rsp),%xmm4
    b9e4:	00 00 
    b9e6:	66 45 0f 58 f3       	addpd  %xmm11,%xmm14
    b9eb:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    b9ef:	66 41 0f 28 41 b0    	movapd -0x50(%r9),%xmm0
    b9f5:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
    b9fa:	66 41 0f 58 ee       	addpd  %xmm14,%xmm5
    b9ff:	66 41 0f 58 db       	addpd  %xmm11,%xmm3
    ba04:	66 41 0f 58 cb       	addpd  %xmm11,%xmm1
    ba09:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    ba0d:	66 41 0f 28 90 b0 08 	movapd 0x8b0(%r8),%xmm2
    ba14:	00 00 
    ba16:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
    ba1b:	66 45 0f 59 f1       	mulpd  %xmm9,%xmm14
    ba20:	66 41 0f 58 c3       	addpd  %xmm11,%xmm0
    ba25:	66 0f 59 94 24 50 02 	mulpd  0x250(%rsp),%xmm2
    ba2c:	00 00 
    ba2e:	66 44 0f 58 f3       	addpd  %xmm3,%xmm14
    ba33:	66 41 0f 28 59 c0    	movapd -0x40(%r9),%xmm3
    ba39:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
    ba3e:	66 0f 58 dc          	addpd  %xmm4,%xmm3
    ba42:	66 41 0f 28 61 d0    	movapd -0x30(%r9),%xmm4
    ba48:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
    ba4d:	66 0f 58 d9          	addpd  %xmm1,%xmm3
    ba51:	66 41 0f 28 88 c0 08 	movapd 0x8c0(%r8),%xmm1
    ba58:	00 00 
    ba5a:	66 0f 58 e2          	addpd  %xmm2,%xmm4
    ba5e:	66 41 0f 28 51 f0    	movapd -0x10(%r9),%xmm2
    ba64:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
    ba68:	66 0f 58 e0          	addpd  %xmm0,%xmm4
    ba6c:	66 41 0f 28 80 d0 08 	movapd 0x8d0(%r8),%xmm0
    ba73:	00 00 
    ba75:	66 44 0f 59 f8       	mulpd  %xmm0,%xmm15
    ba7a:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
    ba7e:	66 41 0f 58 d7       	addpd  %xmm15,%xmm2
    ba83:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
    ba88:	66 0f 58 d4          	addpd  %xmm4,%xmm2
    ba8c:	66 0f 28 a4 24 60 01 	movapd 0x160(%rsp),%xmm4
    ba93:	00 00 
    ba95:	66 0f 59 e2          	mulpd  %xmm2,%xmm4
    ba99:	66 0f 28 94 24 50 01 	movapd 0x150(%rsp),%xmm2
    baa0:	00 00 
    baa2:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
    baa6:	66 41 0f 28 41 e0    	movapd -0x20(%r9),%xmm0
    baac:	66 41 0f 59 c0       	mulpd  %xmm8,%xmm0
    bab1:	66 0f 58 d4          	addpd  %xmm4,%xmm2
    bab5:	66 0f 58 52 f0       	addpd  -0x10(%rdx),%xmm2
    baba:	66 0f 28 a4 24 20 02 	movapd 0x220(%rsp),%xmm4
    bac1:	00 00 
    bac3:	66 0f 59 e1          	mulpd  %xmm1,%xmm4
    bac7:	66 41 0f 59 c8       	mulpd  %xmm8,%xmm1
    bacc:	0f 29 52 f0          	movaps %xmm2,-0x10(%rdx)
    bad0:	66 0f 28 94 24 e0 01 	movapd 0x1e0(%rsp),%xmm2
    bad7:	00 00 
    bad9:	66 0f 59 57 70       	mulpd  0x70(%rdi),%xmm2
    bade:	66 0f 58 52 70       	addpd  0x70(%rdx),%xmm2
    bae3:	66 0f 58 c4          	addpd  %xmm4,%xmm0
    bae7:	66 0f 58 cd          	addpd  %xmm5,%xmm1
    baeb:	66 0f 59 8c 24 40 01 	mulpd  0x140(%rsp),%xmm1
    baf2:	00 00 
    baf4:	66 0f 58 c3          	addpd  %xmm3,%xmm0
    baf8:	66 0f 59 84 24 70 01 	mulpd  0x170(%rsp),%xmm0
    baff:	00 00 
    bb01:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    bb05:	66 0f 58 42 e0       	addpd  -0x20(%rdx),%xmm0
    bb0a:	0f 29 42 e0          	movaps %xmm0,-0x20(%rdx)
    bb0e:	66 0f 28 84 24 f0 01 	movapd 0x1f0(%rsp),%xmm0
    bb15:	00 00 
    bb17:	66 0f 59 47 60       	mulpd  0x60(%rdi),%xmm0
    bb1c:	66 0f 58 42 60       	addpd  0x60(%rdx),%xmm0
    bb21:	66 0f 28 8c 24 d0 01 	movapd 0x1d0(%rsp),%xmm1
    bb28:	00 00 
    bb2a:	66 0f 59 8f 40 01 00 	mulpd  0x140(%rdi),%xmm1
    bb31:	00 
    bb32:	66 0f 28 9c 24 b0 01 	movapd 0x1b0(%rsp),%xmm3
    bb39:	00 00 
    bb3b:	66 0f 59 9f 20 02 00 	mulpd  0x220(%rdi),%xmm3
    bb42:	00 
    bb43:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    bb47:	66 0f 28 84 24 c0 01 	movapd 0x1c0(%rsp),%xmm0
    bb4e:	00 00 
    bb50:	66 0f 59 87 50 01 00 	mulpd  0x150(%rdi),%xmm0
    bb57:	00 
    bb58:	66 0f 58 d9          	addpd  %xmm1,%xmm3
    bb5c:	66 0f 28 8c 24 a0 01 	movapd 0x1a0(%rsp),%xmm1
    bb63:	00 00 
    bb65:	66 0f 59 8f 30 02 00 	mulpd  0x230(%rdi),%xmm1
    bb6c:	00 
    bb6d:	66 0f 58 c2          	addpd  %xmm2,%xmm0
    bb71:	66 0f 28 94 24 00 02 	movapd 0x200(%rsp),%xmm2
    bb78:	00 00 
    bb7a:	66 0f 59 97 00 03 00 	mulpd  0x300(%rdi),%xmm2
    bb81:	00 
    bb82:	66 0f 58 c8          	addpd  %xmm0,%xmm1
    bb86:	66 0f 28 84 24 10 02 	movapd 0x210(%rsp),%xmm0
    bb8d:	00 00 
    bb8f:	66 0f 59 87 10 03 00 	mulpd  0x310(%rdi),%xmm0
    bb96:	00 
    bb97:	66 0f 58 d3          	addpd  %xmm3,%xmm2
    bb9b:	66 0f 58 c1          	addpd  %xmm1,%xmm0
    bb9f:	0f 29 52 60          	movaps %xmm2,0x60(%rdx)
    bba3:	0f 29 42 70          	movaps %xmm0,0x70(%rdx)
    bba7:	4d 39 c6             	cmp    %r8,%r14
    bbaa:	0f 85 c0 fd ff ff    	jne    b970 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x2110>
    bbb0:	49 83 c7 07          	add    $0x7,%r15
    bbb4:	49 83 c5 60          	add    $0x60,%r13
    bbb8:	48 83 c6 60          	add    $0x60,%rsi
    bbbc:	49 83 ea 80          	sub    $0xffffffffffffff80,%r10
    bbc0:	66 44 0f 28 bc 24 00 	movapd 0x100(%rsp),%xmm15
    bbc7:	01 00 00 
    bbca:	48 05 e0 00 00 00    	add    $0xe0,%rax
    bbd0:	66 44 0f 28 b4 24 f0 	movapd 0xf0(%rsp),%xmm14
    bbd7:	00 00 00 
    bbda:	49 83 ff 1c          	cmp    $0x1c,%r15
    bbde:	0f 85 0d fa ff ff    	jne    b5f1 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x1d91>
    bbe4:	4c 8b bc 24 10 01 00 	mov    0x110(%rsp),%r15
    bbeb:	00 
    bbec:	4c 8b 74 24 18       	mov    0x18(%rsp),%r14
    bbf1:	48 89 9c 24 b0 02 00 	mov    %rbx,0x2b0(%rsp)
    bbf8:	00 
    bbf9:	31 db                	xor    %ebx,%ebx
    bbfb:	4c 8d a9 80 fc ff ff 	lea    -0x380(%rcx),%r13
    bc02:	4c 89 f0             	mov    %r14,%rax
    bc05:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    bc0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bc11:	00 00 00 00 
    bc15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bc1c:	00 00 00 00 
    bc20:	f2 41 0f 10 45 00    	movsd  0x0(%r13),%xmm0
    bc26:	49 83 c5 20          	add    $0x20,%r13
    bc2a:	48 83 c0 08          	add    $0x8,%rax
    bc2e:	f2 0f 11 40 f8       	movsd  %xmm0,-0x8(%rax)
    bc33:	49 39 cd             	cmp    %rcx,%r13
    bc36:	75 e8                	jne    bc20 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x23c0>
    bc38:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    bc3c:	4c 89 f2             	mov    %r14,%rdx
    bc3f:	4c 89 fe             	mov    %r15,%rsi
    bc42:	48 83 c3 01          	add    $0x1,%rbx
    bc46:	49 81 c7 e0 00 00 00 	add    $0xe0,%r15
    bc4d:	49 81 c6 e0 00 00 00 	add    $0xe0,%r14
    bc54:	e8 27 81 ff ff       	call   3d80 <eonsim::(anonymous namespace)::cached_face_action(eonsim::FsiElementLinearization const&, std::array<double, 28ul> const&, std::array<double, 28ul>&)>
    bc59:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    bc5d:	48 3b 9c 24 b0 02 00 	cmp    0x2b0(%rsp),%rbx
    bc64:	00 
    bc65:	72 94                	jb     bbfb <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x239b>
    bc67:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    bc6b:	5b                   	pop    %rbx
    bc6c:	41 5c                	pop    %r12
    bc6e:	41 5d                	pop    %r13
    bc70:	41 5e                	pop    %r14
    bc72:	41 5f                	pop    %r15
    bc74:	5d                   	pop    %rbp
    bc75:	c3                   	ret
    bc76:	f2 41 0f 10 40 08    	movsd  0x8(%r8),%xmm0
    bc7c:	f2 41 0f 10 08       	movsd  (%r8),%xmm1
    bc81:	f2 0f 11 87 a0 fc ff 	movsd  %xmm0,-0x360(%rdi)
    bc88:	ff 
    bc89:	f2 0f 11 8f 80 fc ff 	movsd  %xmm1,-0x380(%rdi)
    bc90:	ff 
    bc91:	f2 41 0f 10 40 18    	movsd  0x18(%r8),%xmm0
    bc97:	f2 41 0f 10 48 10    	movsd  0x10(%r8),%xmm1
    bc9d:	f2 0f 11 87 e0 fc ff 	movsd  %xmm0,-0x320(%rdi)
    bca4:	ff 
    bca5:	f2 0f 11 8f c0 fc ff 	movsd  %xmm1,-0x340(%rdi)
    bcac:	ff 
    bcad:	f2 41 0f 10 40 28    	movsd  0x28(%r8),%xmm0
    bcb3:	f2 41 0f 10 48 20    	movsd  0x20(%r8),%xmm1
    bcb9:	f2 0f 11 87 20 fd ff 	movsd  %xmm0,-0x2e0(%rdi)
    bcc0:	ff 
    bcc1:	f2 0f 11 8f 00 fd ff 	movsd  %xmm1,-0x300(%rdi)
    bcc8:	ff 
    bcc9:	f2 41 0f 10 40 38    	movsd  0x38(%r8),%xmm0
    bccf:	f2 41 0f 10 48 30    	movsd  0x30(%r8),%xmm1
    bcd5:	f2 0f 11 87 60 fd ff 	movsd  %xmm0,-0x2a0(%rdi)
    bcdc:	ff 
    bcdd:	f2 0f 11 8f 40 fd ff 	movsd  %xmm1,-0x2c0(%rdi)
    bce4:	ff 
    bce5:	f2 41 0f 10 40 48    	movsd  0x48(%r8),%xmm0
    bceb:	f2 41 0f 10 48 40    	movsd  0x40(%r8),%xmm1
    bcf1:	f2 0f 11 87 a0 fd ff 	movsd  %xmm0,-0x260(%rdi)
    bcf8:	ff 
    bcf9:	f2 0f 11 8f 80 fd ff 	movsd  %xmm1,-0x280(%rdi)
    bd00:	ff 
    bd01:	f2 41 0f 10 40 58    	movsd  0x58(%r8),%xmm0
    bd07:	f2 41 0f 10 48 50    	movsd  0x50(%r8),%xmm1
    bd0d:	f2 0f 11 87 e0 fd ff 	movsd  %xmm0,-0x220(%rdi)
    bd14:	ff 
    bd15:	f2 0f 11 8f c0 fd ff 	movsd  %xmm1,-0x240(%rdi)
    bd1c:	ff 
    bd1d:	f2 41 0f 10 40 68    	movsd  0x68(%r8),%xmm0
    bd23:	f2 41 0f 10 48 60    	movsd  0x60(%r8),%xmm1
    bd29:	f2 0f 11 87 20 fe ff 	movsd  %xmm0,-0x1e0(%rdi)
    bd30:	ff 
    bd31:	f2 0f 11 8f 00 fe ff 	movsd  %xmm1,-0x200(%rdi)
    bd38:	ff 
    bd39:	f2 41 0f 10 48 70    	movsd  0x70(%r8),%xmm1
    bd3f:	f2 41 0f 10 40 78    	movsd  0x78(%r8),%xmm0
    bd45:	f2 0f 11 8f 40 fe ff 	movsd  %xmm1,-0x1c0(%rdi)
    bd4c:	ff 
    bd4d:	f2 0f 11 87 60 fe ff 	movsd  %xmm0,-0x1a0(%rdi)
    bd54:	ff 
    bd55:	f2 41 0f 10 80 88 00 	movsd  0x88(%r8),%xmm0
    bd5c:	00 00 
    bd5e:	f2 41 0f 10 88 80 00 	movsd  0x80(%r8),%xmm1
    bd65:	00 00 
    bd67:	f2 0f 11 87 a0 fe ff 	movsd  %xmm0,-0x160(%rdi)
    bd6e:	ff 
    bd6f:	f2 0f 11 8f 80 fe ff 	movsd  %xmm1,-0x180(%rdi)
    bd76:	ff 
    bd77:	f2 41 0f 10 80 98 00 	movsd  0x98(%r8),%xmm0
    bd7e:	00 00 
    bd80:	f2 41 0f 10 88 90 00 	movsd  0x90(%r8),%xmm1
    bd87:	00 00 
    bd89:	f2 0f 11 87 e0 fe ff 	movsd  %xmm0,-0x120(%rdi)
    bd90:	ff 
    bd91:	f2 0f 11 8f c0 fe ff 	movsd  %xmm1,-0x140(%rdi)
    bd98:	ff 
    bd99:	f2 41 0f 10 80 a8 00 	movsd  0xa8(%r8),%xmm0
    bda0:	00 00 
    bda2:	f2 41 0f 10 88 a0 00 	movsd  0xa0(%r8),%xmm1
    bda9:	00 00 
    bdab:	f2 0f 11 87 20 ff ff 	movsd  %xmm0,-0xe0(%rdi)
    bdb2:	ff 
    bdb3:	f2 0f 11 8f 00 ff ff 	movsd  %xmm1,-0x100(%rdi)
    bdba:	ff 
    bdbb:	f2 41 0f 10 80 b8 00 	movsd  0xb8(%r8),%xmm0
    bdc2:	00 00 
    bdc4:	f2 41 0f 10 88 b0 00 	movsd  0xb0(%r8),%xmm1
    bdcb:	00 00 
    bdcd:	f2 0f 11 87 60 ff ff 	movsd  %xmm0,-0xa0(%rdi)
    bdd4:	ff 
    bdd5:	f2 0f 11 8f 40 ff ff 	movsd  %xmm1,-0xc0(%rdi)
    bddc:	ff 
    bddd:	f2 41 0f 10 80 c8 00 	movsd  0xc8(%r8),%xmm0
    bde4:	00 00 
    bde6:	f2 41 0f 10 88 c0 00 	movsd  0xc0(%r8),%xmm1
    bded:	00 00 
    bdef:	f2 0f 11 47 a0       	movsd  %xmm0,-0x60(%rdi)
    bdf4:	f2 0f 11 4f 80       	movsd  %xmm1,-0x80(%rdi)
    bdf9:	f2 41 0f 10 80 d8 00 	movsd  0xd8(%r8),%xmm0
    be00:	00 00 
    be02:	f2 41 0f 10 88 d0 00 	movsd  0xd0(%r8),%xmm1
    be09:	00 00 
    be0b:	f2 0f 11 47 e0       	movsd  %xmm0,-0x20(%rdi)
    be10:	f2 0f 11 4f c0       	movsd  %xmm1,-0x40(%rdi)
    be15:	e9 3e db ff ff       	jmp    9958 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xf8>
    be1a:	48 8d 87 80 fc ff ff 	lea    -0x380(%rdi),%rax
    be21:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    be28:	00 00 
    be2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    be31:	00 00 00 00 
    be35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    be3c:	00 00 00 00 
    be40:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    be47:	48 83 c0 40          	add    $0x40,%rax
    be4b:	48 c7 40 e0 00 00 00 	movq   $0x0,-0x20(%rax)
    be52:	00 
    be53:	48 39 c7             	cmp    %rax,%rdi
    be56:	75 e8                	jne    be40 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x25e0>
    be58:	e9 2f dd ff ff       	jmp    9b8c <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0x32c>
    be5d:	66 44 0f 58 9c 24 20 	addpd  0x320(%rsp),%xmm11
    be64:	03 00 00 
    be67:	66 44 0f 58 8c 24 30 	addpd  0x330(%rsp),%xmm9
    be6e:	03 00 00 
    be71:	44 0f 29 9c 24 20 03 	movaps %xmm11,0x320(%rsp)
    be78:	00 00 
    be7a:	44 0f 29 8c 24 30 03 	movaps %xmm9,0x330(%rsp)
    be81:	00 00 
    be83:	e9 2d e8 ff ff       	jmp    a6b5 <eonsim::fsi_element_action_batch(eonsim::FsiElementLinearization const* const*, std::array<double, 28ul> const*, std::array<double, 28ul>*, unsigned long)+0xe55>
    be88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    be8f:	00 

