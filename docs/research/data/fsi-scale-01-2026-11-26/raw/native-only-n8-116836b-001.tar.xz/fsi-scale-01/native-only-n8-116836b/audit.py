#!/usr/bin/env python3
"""Independently compare saved 116836b native-only and existing FP64 outputs.

No solver or tracked driver is imported or executed. Read-only VTU/CSV helpers
are extracted from the immutable earlier independent audit script, skipping its
campaign entry point, so the prior physical audit artifacts remain unchanged.
"""
import ast
import collections
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
AUDIT_HELPER = WORK.parent / 'audit-physical-116836b.py'
LIMIT = 2e-9
helper_names = {'need', 'digest', 'records', 'history', 'difference', 'load_piece', 'volume'}
helper_tree = ast.parse(AUDIT_HELPER.read_text())
helper_code = ast.Module(body=[node for node in helper_tree.body
                              if isinstance(node, ast.FunctionDef) and node.name in helper_names], type_ignores=[])
need_names = {node.name for node in helper_code.body}
assert need_names == helper_names
exec(compile(helper_code, str(AUDIT_HELPER), 'exec'), globals())

result = dict(status='running', errors=[], read_only=True,
              helper_path=str(AUDIT_HELPER), helper_sha256=digest(AUDIT_HELPER),
              audit_sha256=digest(__file__), runs=[])


def audit_run(directory, mode, cfg):
    log = (directory / (mode + '.log')).read_text()
    trace = history(directory / (mode + '.csv'))
    reports = records(log, 'solver_report')
    linear = records(log, 'linear_residual')
    fields = records(log, 'field_residual')
    hierarchy = records(log, 'pc_monolithic_mg')
    storage = records(log, 'pc_monolithic_mg_storage')
    smoothers = records(log, 'pc_monolithic_mg_smoother')
    stats = records(log, 'monolithic_mg_stats')
    need(log.count('status=success') == 1 and not any(x in log for x in
         ('linear_residual_unavailable', 'linear_iteration_limit_residual ', 'step_retry=')),
         (mode, 'Incomplete or rejected trajectory'))
    need(len(trace) == len(reports) == cfg['fsi']['steps'] == 3, (mode, 'Accepted steps missing'))
    dt = cfg['fsi']['dt']
    for index, row in enumerate(trace, 1):
        need(row['step'] == index and abs(row['accepted_dt']-dt) <= 1e-13 and
             abs(row['time']-index*dt) <= 1e-13, (mode, 'Accepted time grid changed'))
        need(abs(row['evaluation_body_balance']) <= LIMIT and abs(row['evaluation_power_balance']) <= LIMIT,
             (mode, 'Force/power balance gate failed'))
        need(min(v for k, v in row.items() if k.endswith('_j')) > 0, 'Invalid deformation Jacobian')
    for row in reports:
        need(int(row['ranks']) == 2 and int(row['snes_reason']) > 0 and int(row['ksp_reason']) > 0 and
             row['ksp'] == 'fgmres' and int(row['linear_started']) == int(row['linear_completed']),
             (mode, 'Solver incomplete'))
        need(int(row['matrix_free']) == int(row['inexact_linear_solves']) == int(row['recycle_vectors']) == 0,
             (mode, 'Unexpected other optimization'))
    need(sum(int(row['linear_completed']) for row in reports) == len(linear), 'Missing correction evidence')
    ratios = []
    for row in linear:
        norm, rhs = float(row['norm']), float(row['rhs_norm'])
        need(math.isfinite(norm) and math.isfinite(rhs) and min(norm, rhs) >= 0, 'Invalid residual')
        ratios.append(norm/(1e-12 + 1e-10*rhs))
    need(ratios and max(ratios) <= 1, (mode, 'Original residual gate failed', ratios))
    names = {row['name'] for row in fields}
    need({'mesh','velocity','pressure','structure'} <= names and
         collections.Counter(row['name'] for row in fields) == {name: 3 for name in names},
         'Final physical acceptance missing')
    physical_ratios = []
    for row in fields:
        actual_limit = float(row['limit'])
        configured_limit = cfg['solver']['absolute_tolerance'] + cfg['solver']['relative_tolerance']*float(row['initial_rms'])
        need(math.isclose(actual_limit, configured_limit, rel_tol=5e-14) and
             float(row['constraint_limit']) == cfg['solver']['absolute_tolerance'], 'Physical gate changed')
        need(row['accepted'] == '1' and 0 <= float(row['rms']) <= actual_limit and
             0 <= float(row['constraint_max']) <= float(row['constraint_limit']), 'Physical gate failed')
        physical_ratios.append(float(row['rms'])/actual_limit)
    native = mode == 'mono_native_fp32'
    need(hierarchy and all(row['native_fp32'] == str(int(native)) and row['field_scaling'] == '0' and
         row['fsi_candidates'] == '0' and row['cycle'] == 'v' and row['smoother'] == 'vanka'
         for row in hierarchy), 'Native-only comparison is confounded')
    transfers = records(log, 'pc_monolithic_mg_level')
    need(all(int(row['rows']) > int(row['coarse_rows']) and float(row['reproduction_error']) <= 1e-9 and
         float(row['energy_after']) <= float(row['energy_before'])*(1+1e-10)+1e-12 for row in transfers),
         'Hierarchy transfer gate failed')
    last_storage = {int(row['rank']): row for row in storage}
    last_smoothers = {(int(row['rank']),int(row['level'])): row for row in smoothers}
    need(set(last_storage) == {0,1}, 'Missing rank-local coefficient storage')
    storage_total = {key: sum(int(row[key]) for row in last_storage.values()) for key in
                     ('fp32_value_bytes','retained_fp64_operator_bytes','released_fp64_operator_bytes')}
    storage_total.update({key: sum(int(row[key]) for row in last_smoothers.values()) for key in
                         ('fp32_patch_bytes','retained_fp64_patch_bytes','fp32_patches','patches')})
    need(storage_total['released_fp64_operator_bytes'] > 0 if native else storage_total['released_fp64_operator_bytes'] == 0,
         'Native release status wrong')
    need(storage_total['retained_fp64_patch_bytes'] == 0 if native else storage_total['fp32_patch_bytes'] == 0,
         'Patch precision status wrong')
    # The native fp32 value total includes patch/lifting coefficients, not LU factors.
    storage_total['retained_coefficient_bytes'] = (storage_total['fp32_value_bytes'] +
        storage_total['retained_fp64_operator_bytes'] + storage_total['retained_fp64_patch_bytes'])
    first_storage, first_smoothers = {}, {}
    for row in storage:
        first_storage.setdefault(int(row['rank']), row)
    for row in smoothers:
        first_smoothers.setdefault((int(row['rank']), int(row['level'])), row)
    initial_total = {key: sum(int(row[key]) for row in first_storage.values()) for key in
                     ('fp32_value_bytes','retained_fp64_operator_bytes','released_fp64_operator_bytes')}
    initial_total.update({key: sum(int(row[key]) for row in first_smoothers.values()) for key in
                         ('fp32_patch_bytes','retained_fp64_patch_bytes','fp32_patches','patches')})
    initial_total['retained_coefficient_bytes'] = (initial_total['fp32_value_bytes'] +
        initial_total['retained_fp64_operator_bytes'] + initial_total['retained_fp64_patch_bytes'])
    rss = []
    for step, row in enumerate(reports, 1):
        item = dict(step=step, **{k:int(float(row[k])) for k in
                    ('rss_max_bytes','rss_sum_bytes','peak_rss_max_bytes','peak_rss_sum_bytes')})
        need(item['peak_rss_max_bytes'] >= item['rss_max_bytes'] and
             item['peak_rss_sum_bytes'] >= item['rss_sum_bytes'], 'Normalized RSS invariant failed')
        item['rss_rank_values_unordered'] = [item['rss_sum_bytes']-item['rss_max_bytes'],item['rss_max_bytes']]
        item['peak_rss_rank_values_unordered'] = [item['peak_rss_sum_bytes']-item['peak_rss_max_bytes'],
                                               item['peak_rss_max_bytes']]
        rss.append(item)
    snapshots = [volume(directory / f'{mode}_step{int(row["step"])}', 2) for row in trace]
    final = volume(directory / mode, 2)
    final_consistency = difference(snapshots[-1][0], final[0])
    need(snapshots[-1][1] == final[1], 'Final saved topology changed')
    summary = dict(mode=mode, status='passed', dofs=int(reports[-1]['dofs']), accepted_steps=len(trace),
                   corrections=len(linear), outer_iterations=sum(int(row['linear_iterations']) for row in reports),
                   max_true_residual_ratio=max(ratios), max_physical_acceptance_ratio=max(physical_ratios),
                   true_residual_checks=sum(int(row['true_residual_checks']) for row in reports),
                   true_residual_rejections=sum(int(row['true_residual_rejections']) for row in reports),
                   nnz=max(int(row['nnz']) for row in reports),
                   peak_rss_max_bytes=max(row['peak_rss_max_bytes'] for row in rss),
                   peak_rss_sum_bytes=max(row['peak_rss_sum_bytes'] for row in rss),
                   rss_max_bytes=max(row['rss_max_bytes'] for row in rss),
                   rss_sum_bytes=max(row['rss_sum_bytes'] for row in rss),
                   rss_steps=rss, rank_id_rss_available=False, raw_system_peak_rss_available=False,
                   solver_records=reports, linear_records=linear, field_records=fields,
                   hierarchy_records=hierarchy, storage_records=storage, smoother_records=smoothers,
                   hierarchy_stats=stats, last_reported_storage_by_rank=last_storage,
                   last_reported_storage_total=storage_total,
                   first_reported_storage_by_rank=first_storage,
                   first_reported_storage_total=initial_total,
                   volume_audits=[x[2] for x in snapshots]+[final[2]],
                   final_matches_last_step=final_consistency)
    result['runs'].append(summary)
    return trace, snapshots, final, summary


def compare_runs(reference, candidate):
    a, b = reference, candidate
    histories = {}
    for first, second in zip(a[0], b[0]):
        need(first.keys() == second.keys(), 'CSV columns differ')
        for name in first.keys()-{'snes_iterations'}:
            histories[name] = max(histories.get(name,0.), abs(first[name]-second[name]))
    need(max(histories.values()) <= LIMIT, 'CSV physical discrepancy')
    fields = []
    for first, second in zip(a[1], b[1]):
        need(first[1] == second[1], 'Volume topology or identity differs')
        fields.append(difference(first[0],second[0]))
    need(a[2][1] == b[2][1], 'Final topology differs')
    final = difference(a[2][0],b[2][0])
    return dict(final_difference=final, accepted_step_differences=fields,
                field_max_difference=max(final['maximum'],*[x['maximum'] for x in fields]),
                history_max_difference=max(histories.values()), history_differences=histories)


try:
    invocation = json.loads((WORK/'invocation.json').read_text())
    result.update(build_source=invocation['build_source'], executable_sha256=invocation['binary_sha256'],
                  invocation_sha256=digest(WORK/'invocation.json'))
    need(invocation['status'] == 'passed' and invocation['exit_code'] == 0, 'Native process failed')
    need(digest(invocation['binary']) == invocation['binary_sha256'], 'Binary changed')
    need(digest(invocation['original_receipt']) == invocation['original_receipt_sha256'], 'Reference receipt changed')
    for entry in invocation['input_hashes']+invocation['candidate_inputs']:
        need(digest(entry['path']) == entry['sha256'] and Path(entry['path']).stat().st_size == entry['bytes'],
             ('Input/partition changed',entry['path']))
    before = invocation['original_command']
    after = invocation['command'][2:]
    expected = list(before)
    expected[expected.index('-case')+1] = str(WORK/'mono_native_fp32.json')
    expected += ['-monolithic_mg_native_fp32','true']
    need(after == expected, 'Unexpected command option change')
    old_case = Path(before[before.index('-case')+1])
    cfg = json.loads(old_case.read_text())
    new_cfg = json.loads((WORK/'mono_native_fp32.json').read_text())
    new_cfg['output'] = cfg['output']
    need(new_cfg == cfg, 'Physical input changed')
    reference_receipt = json.loads(Path(invocation['original_receipt']).read_text())
    old_run = next(r for c in reference_receipt['cases'] if c['name']=='scaling-n8-r2'
                   for r in c['runs'] if r['mode']=='mono')
    for artifact in old_run['artifacts']:
        need(digest(artifact['path']) == artifact['sha256'] and Path(artifact['path']).stat().st_size == artifact['bytes'],
             ('Existing FP64 artifact changed',artifact['path']))
    result['reference_artifacts_verified'] = len(old_run['artifacts'])
    fp64 = audit_run(old_case.parent,'mono',cfg)
    native = audit_run(WORK,'mono_native_fp32',cfg)
    result['native_vs_fp64'] = compare_runs(fp64,native)
    # Also retain the already available direct oracle without executing it.
    direct_history = history(old_case.parent/'direct.csv')
    direct_steps = [volume(old_case.parent/f'direct_step{int(row["step"])}',2) for row in direct_history]
    direct_final = volume(old_case.parent/'direct',2)
    direct = (direct_history,direct_steps,direct_final)
    result['native_vs_direct'] = compare_runs(direct,native)
    result['fp64_vs_direct'] = compare_runs(direct,fp64)
    a, b = fp64[3], native[3]
    result['comparison'] = dict(iteration_change=b['outer_iterations']-a['outer_iterations'],
        retained_coefficient_ratio=b['last_reported_storage_total']['retained_coefficient_bytes']/a['last_reported_storage_total']['retained_coefficient_bytes'],
        initial_retained_coefficient_ratio=b['first_reported_storage_total']['retained_coefficient_bytes']/a['first_reported_storage_total']['retained_coefficient_bytes'],
        single_observation_peak_rss_max_ratio=b['peak_rss_max_bytes']/a['peak_rss_max_bytes'],
        single_observation_peak_rss_sum_ratio=b['peak_rss_sum_bytes']/a['peak_rss_sum_bytes'],
        single_observation_current_rss_max_ratio=b['rss_max_bytes']/a['rss_max_bytes'])
    result['candidate_artifacts'] = [dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p))
                                     for p in sorted(WORK.glob('mono_native_fp32*')) if p.is_file()]
    result['status'] = 'passed'
    result['limitations'] = [
        'One newly executed native run versus one existing FP64 observation; no cost timing claim or repeated RSS inference.',
        'Per-rank RSS IDs were not logged. Two-rank unordered values are derived from logged sum and maximum, retaining their printed precision; rank identity and raw OS peak remain unavailable.',
        'Coefficient totals use each mode\'s last emitted storage report. FP64 emitted one initial hierarchy report; native emitted reports at every rebuild.',
        'FP32 value bytes already include native patch/lifting coefficients; total coefficient bytes avoid counting those twice. LU factors are not included in these counters.',
        'Coefficient totals exclude LU factors, sparse indices, vectors, MPI buffers, outer P, allocator metadata, and transient setup allocations.',
        'Original-operator norms are checked from saved solver diagnostics; this audit does not reconstruct J from VTU.'
    ]
except BaseException as exc:
    result['status']='failed'
    result['errors'].append(str(exc))
finally:
    (WORK/'independent-audit.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in
        ('runs','native_vs_fp64','native_vs_direct','fp64_vs_direct','candidate_artifacts')},indent=2))
    for row in result['runs']:
        print(json.dumps({k:row[k] for k in ('mode','accepted_steps','corrections','outer_iterations',
            'max_true_residual_ratio','true_residual_checks','true_residual_rejections','peak_rss_max_bytes',
            'peak_rss_sum_bytes','rss_steps','last_reported_storage_total')},indent=2))
    for key in ('native_vs_fp64','native_vs_direct','fp64_vs_direct'):
        if key in result:
            print(key,json.dumps({k:v for k,v in result[key].items() if k.endswith('_max_difference')}))
sys.exit(0 if result['status']=='passed' else 1)
