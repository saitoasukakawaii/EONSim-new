#!/usr/bin/env python3
"""Prepare, or explicitly execute once, the fixed-source native RSS pair.

Default invocation only writes inputs and a reviewable plan. --execute is
required to launch the two solver processes after the other campaign finishes.
No tracked driver is imported; exact argv is derived from the saved 116 n8 run.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'build/fsi-scale-01'
WORK = BASE/'native-paired-30e2941'
SOURCE = '30e29411431d4f721f1a9aa4b9b55fc685f70e7b'
BINARY = BASE/'eonsim-30e2941'
BINARY_SHA = 'bfadbb0c3aab7d3c9507560aaac3940a352f76f16f3de285fb254b8872bd782f'
REFERENCE = BASE/'grid-scaling-116836b/1795705006766920222/results.json'
LOCKED = '/workspace/scratch/ae740e1dde63/EONSim-new/build/locked.sh'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stamp(path):
    path=Path(path)
    return dict(path=str(path),sha256=digest(path),bytes=path.stat().st_size)


def save(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,indent=2)+'\n')
    temporary.replace(path)


def prepare():
    assert digest(BINARY)==BINARY_SHA,'Fixed binary hash changed'
    original=json.loads(REFERENCE.read_text())
    old=next(row for row in original['commands'] if row['label']=='mono' and
             'scaling-n8-r2/mono.log' in row['log'])
    old_case=Path(old['command'][old['command'].index('-case')+1])
    cfg=json.loads(old_case.read_text())
    partition=Path(old['command'][old['command'].index('-partition')+1])
    plan=dict(status='prepared',build_source=SOURCE,binary=stamp(BINARY),
              source_argv_receipt=stamp(REFERENCE),source_argv=old['command'],
              script=stamp(__file__),cwd=str(ROOT),runs=[],
              input_hashes=[stamp(old_case),*[stamp(old_case.parent/name) for name in ('fluid.msh','solid.msh')],
                            *[stamp(p) for p in sorted(partition.rglob('*')) if p.is_file()]],
              common_option_additions=['-solver_rank_report'],
              native_only_option_additions=['-monolithic_mg_native_fp32','true'],
              scope='Two single observations, same published binary and input; no timing claim, no reruns.',
              normalized_peak_definition='max(observed current RSS, raw system peak)',
              old_regression_preserved=str(BASE/'native-only-n8-116836b'))
    WORK.mkdir(exist_ok=True)
    for mode in ('mono','mono_native_fp32'):
        directory=WORK/mode;directory.mkdir(exist_ok=True)
        for name in ('fluid.msh','solid.msh'):
            shutil.copyfile(old_case.parent/name,directory/name)
        config=dict(cfg,output=str(directory/(mode+'.vtu')))
        case=directory/(mode+'.json');save(case,config)
        command=list(old['command'])
        command[command.index(original['executable'])]=str(BINARY)
        command[command.index('-case')+1]=str(case)
        command+=['-solver_rank_report']
        if mode=='mono_native_fp32':command+=['-monolithic_mg_native_fp32','true']
        plan['runs'].append(dict(mode=mode,status='prepared',command=['bash',LOCKED,*command],
            case=stamp(case),mesh_inputs=[stamp(directory/name) for name in ('fluid.msh','solid.msh')],
            log=str(directory/(mode+'.log'))))
    save(WORK/'invocation.json',plan)
    return plan


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true',help='Launch the authorized pair exactly once')
    args=parser.parse_args()
    path=WORK/'invocation.json'
    if path.exists():
        plan=json.loads(path.read_text())
        assert plan['status']=='prepared','Pair already started; preserved runs may not be overwritten'
        assert plan['script']==stamp(__file__),'Prepared script changed'
    else:plan=prepare()
    for item in [plan['binary'],plan['source_argv_receipt'],*plan['input_hashes']]:
        assert stamp(item['path'])==item,('Prepared source artifact changed',item['path'])
    for run in plan['runs']:
        for item in [run['case'],*run['mesh_inputs']]:
            assert stamp(item['path'])==item,('Prepared input changed',item['path'])
        assert not Path(run['log']).exists(),'Existing solver log must not be overwritten'
    if not args.execute:
        print('PREPARED ONLY:',path)
        print('No solver process was launched.')
        return
    plan.update(status='running',started_unix=time.time())
    save(path,plan)
    for run in plan['runs']:
        run.update(status='running',started_unix=time.time());save(path,plan)
        with Path(run['log']).open('w') as output:
            try:
                completed=subprocess.run(run['command'],cwd=ROOT,stdout=output,stderr=subprocess.STDOUT,timeout=600)
                run.update(exit_code=completed.returncode,status='passed' if completed.returncode==0 else 'failed')
            except subprocess.TimeoutExpired:
                run.update(status='failed',timeout=True)
        run.update(finished_unix=time.time(),log_sha256=digest(run['log']))
        run['artifacts']=[stamp(p) for p in sorted(Path(run['log']).parent.glob(run['mode']+'*')) if p.is_file()]
        save(path,plan)
        print(run['mode'],run['status'],flush=True)
    plan.update(status='passed' if all(run['status']=='passed' for run in plan['runs']) else 'failed',
                finished_unix=time.time())
    assert digest(BINARY)==BINARY_SHA,'Fixed binary changed during pair'
    save(path,plan)
    raise SystemExit(0 if plan['status']=='passed' else 1)


if __name__=='__main__':main()
