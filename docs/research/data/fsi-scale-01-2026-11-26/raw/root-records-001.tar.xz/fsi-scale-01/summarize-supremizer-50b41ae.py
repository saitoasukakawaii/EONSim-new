#!/usr/bin/env python3
"""Compact an independent audit without recomputing or rerunning the solver."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('audit', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
audit = json.loads(args.audit.read_text())
if audit['status'] != 'passed':
    raise RuntimeError('A failed audit cannot become a passed summary')
summary = {key: audit[key] for key in ('build_source', 'driver_source_commit', 'executable_sha256',
           'driver_sha256', 'receipt_sha256', 'driver_matches_production_source')}
summary.update(status='physical_and_independent_audit_passed', independent_audit=str(args.audit),
               independent_audit_sha256=hashlib.sha256(args.audit.read_bytes()).hexdigest(),
               campaign=audit['campaign'], rows=[])
if 'finite_window_goal' in audit:
    summary['finite_window_goal'] = audit['finite_window_goal']
    if any(g['status'] != 'met' for g in audit['finite_window_goal']['modes'].values()):
        summary['status'] += '_convergence_target_open'
summary['checks'] = {key: audit[key] for key in ('runs', 'accepted_steps', 'linear_corrections',
       'artifact_hashes_verified', 'volume_pieces_parsed', 'command_logs_verified', 'max_field_difference',
       'max_history_difference', 'max_ghost_difference', 'max_strict_linear_ratio', 'max_inexact_linear_ratio',
       'true_residual_checks', 'true_residual_rejections')}
for case in audit['cases']:
    for run in case['runs']:
        row = {key: run[key] for key in ('mode', 'status', 'dofs', 'accepted_steps', 'corrections',
               'outer_iterations', 'iterations_per_correction', 'field_max_difference', 'history_max_difference',
               'max_true_residual_ratio', 'linear_gate', 'true_residual_checks', 'true_residual_rejections',
               'nnz', 'timings')}
        row.update(case=case['name'], ranks=case['ranks'])
        for key in ('last_hierarchy_storage_sum_across_ranks', 'storage_note', 'circuit_defect',
                    'nnz_reduction_fraction', 'matrix_free_actions', 'matrix_free_preparations',
                    'matrix_free_overlapped_actions', 'assembled_pc_reuses', 'inexact_linear_solves',
                    'recycle_projections'):
            if key in run:
                row[key] = run[key]
        if 'pressure_pair_evidence' in run:
            pairs = run['pressure_pair_evidence']['fine_level_records']
            row['pressure_pairs'] = dict(scope=run['pressure_pair_evidence']['scope'],
                minimum_local_singular=min(float(p['pressure_pair_min_singular']) for p in pairs),
                maximum_setup_relative_change=max(float(p['pressure_pair_relative_change']) for p in pairs),
                counts_by_setup=[dict(modes=int(p['pressure_supremizer_modes']),
                                     aggregates=int(p['pressure_paired_aggregates'])) for p in pairs])
        if 'mg_work' in run:
            row['last_work_by_rank_path_generation'] = run['mg_work']['last_by_rank_path_generation']
            row['work_scope'] = run['mg_work']['scope']
        summary['rows'].append(row)
summary['limitations'] = audit['limitations']
args.output.write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key != 'rows'}, indent=2))
