#!/usr/bin/env python3
"""Archive the complete FSI evidence directory after all campaigns have stopped.

Default invocation is a read-only inventory. Final creation requires --write:

  python build/fsi-scale-01/archive-evidence.py --write
  python build/fsi-scale-01/archive-evidence.py --verify docs/research/data/fsi-scale-01-2026-11-26

The script creates raw/*.tar.xz, raw-manifest.json and raw-SHA256SUMS.txt only.
README, summary and provenance documents are maintained separately. Each raw
archive extracts paths below fsi-scale-01/ and contains complete files. Volumes
are split by campaign and measured compressed size; an indivisible single file
above the soft target is explicitly recorded. Never redirect a live archive log
into the source directory: source changes during archiving cause an error.
"""
import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import shutil
import stat
import sys
import tarfile
import tempfile


PREFIX = 'fsi-scale-01'
CACHE_COMPONENTS = {'__pycache__', 'cache', '.pytest_cache', '.mypy_cache', '.ruff_cache'}
SQLITE_SUFFIXES = ('.sqlite', '.sqlite3', '.sqlite-wal', '.sqlite-shm', '.sqlite-journal',
                   '.sqlite3-wal', '.sqlite3-shm', '.sqlite3-journal')
MANIFEST = 'raw-manifest.json'
SUMS = 'raw-SHA256SUMS.txt'
BLOCK = 1024 * 1024


def sha_file(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(BLOCK):
            value.update(chunk)
    return value.hexdigest()


def signature(path):
    value = path.stat(follow_symlinks=False)
    return value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_mode


def inventory(source, hashes=False):
    included, excluded = [], []
    for directory, dirs, files in os.walk(source, followlinks=False):
        dirs.sort()
        files.sort()
        for name in dirs:
            if (Path(directory) / name).is_symlink():
                raise RuntimeError(f'Unexpected directory symlink: {Path(directory) / name}')
        for name in files:
            path = Path(directory) / name
            relative = path.relative_to(source).as_posix()
            before = signature(path)
            if not stat.S_ISREG(before[-1]):
                raise RuntimeError(f'Unexpected non-regular evidence file: {path}')
            with path.open('rb') as stream:
                header = stream.read(16)
            reason = None
            if set(PurePosixPath(relative).parts) & CACHE_COMPONENTS or path.suffix in ('.pyc', '.pyo'):
                reason = 'rebuildable Python/tool cache'
            elif header.startswith(b'\x7fELF'):
                reason = 'ELF binary; build/source and executable hashes remain in original receipts'
            elif header == b'SQLite format 3\x00' or name.endswith(SQLITE_SUFFIXES):
                reason = 'rebuildable SQLite field-audit spool or sidecar; original VTU data retained'
            common = {'path': relative, 'bytes': before[2], '_signature': before}
            if reason is not None:
                entry = {**common, 'reason': reason}
                if hashes and header.startswith(b'\x7fELF'):
                    entry['sha256'] = sha_file(path)
                    if signature(path) != before:
                        raise RuntimeError(f'Excluded binary changed while hashing: {relative}')
                excluded.append(entry)
                continue
            entry = {**common,
                     'campaign': PurePosixPath(relative).parts[0] if '/' in relative else '.',
                     'tar_member': f'{PREFIX}/{relative}', 'original_mtime_ns': before[3],
                     'original_mode': stat.S_IMODE(before[4])}
            if hashes:
                entry['sha256'] = sha_file(path)
                if signature(path) != before:
                    raise RuntimeError(f'Evidence changed while hashing: {relative}')
            included.append(entry)
    return sorted(included, key=lambda row: row['path']), sorted(excluded, key=lambda row: row['path'])


class HashingReader:
    def __init__(self, stream):
        self.stream = stream
        self.hash = hashlib.sha256()
        self.bytes = 0

    def read(self, size=-1):
        data = self.stream.read(size)
        self.hash.update(data)
        self.bytes += len(data)
        return data


def write_volume(source, entries, path, compression_level):
    with tarfile.open(path, 'w:xz', format=tarfile.PAX_FORMAT, preset=compression_level) as archive:
        for entry in entries:
            source_path = source / entry['path']
            if signature(source_path) != entry['_signature']:
                raise RuntimeError(f'Evidence changed before archiving: {entry["path"]}')
            info = tarfile.TarInfo(entry['tar_member'])
            info.size = entry['bytes']
            info.mode = 0o644
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            with source_path.open('rb') as stream:
                reader = HashingReader(stream)
                archive.addfile(info, reader)
            if (reader.bytes != entry['bytes'] or reader.hash.hexdigest() != entry['sha256'] or
                    signature(source_path) != entry['_signature']):
                raise RuntimeError(f'Evidence changed during archiving: {entry["path"]}')


def split_point(entries):
    halfway = sum(row['bytes'] for row in entries) / 2
    total = 0
    for index, row in enumerate(entries[:-1], 1):
        total += row['bytes']
        if total >= halfway:
            return index
    return max(1, len(entries) // 2)


def public(row):
    return {key: value for key, value in row.items() if not key.startswith('_')}


def verify_archive(path, entries):
    expected = {row['tar_member']: row for row in entries}
    seen = set()
    with tarfile.open(path, 'r:xz') as archive:
        for member in archive:
            if not member.isfile() or member.name not in expected or member.name in seen:
                raise RuntimeError(f'Unexpected archive member: {path}: {member.name}')
            row = expected[member.name]
            if member.size != row['bytes']:
                raise RuntimeError(f'Archive member size differs: {member.name}')
            value = hashlib.sha256()
            stream = archive.extractfile(member)
            while chunk := stream.read(BLOCK):
                value.update(chunk)
            if value.hexdigest() != row['sha256']:
                raise RuntimeError(f'Archive member hash differs: {member.name}')
            seen.add(member.name)
    if seen != expected.keys():
        raise RuntimeError(f'Archive is missing evidence files: {path}')


def verify_output(output):
    manifest = json.loads((output / MANIFEST).read_text())
    expected_archives = {row['path']: row for row in manifest['archives']}
    actual_archives = {path.relative_to(output).as_posix() for path in (output / 'raw').glob('*.tar.xz')}
    if actual_archives != expected_archives.keys():
        raise RuntimeError('Published archive set differs from manifest')
    grouped = defaultdict(list)
    for row in manifest['files']:
        if row['archive'] not in expected_archives:
            raise RuntimeError(f'Unknown archive reference: {row["path"]}')
        grouped[row['archive']].append(row)
    for name, archive in expected_archives.items():
        path = output / name
        if path.stat().st_size != archive['bytes'] or sha_file(path) != archive['sha256']:
            raise RuntimeError(f'Archive bytes/hash differs: {name}')
        verify_archive(path, grouped[name])
    expected_sums = {MANIFEST: sha_file(output / MANIFEST),
                     **{name: row['sha256'] for name, row in expected_archives.items()}}
    actual_sums = {}
    for line in (output / SUMS).read_text().splitlines():
        value, name = line.split('  ', 1)
        if name in actual_sums:
            raise RuntimeError(f'Duplicate SHA256SUMS entry: {name}')
        actual_sums[name] = value
    if actual_sums != expected_sums:
        raise RuntimeError('SHA256SUMS differs from manifest/archive data')
    return {'status': 'verified', 'archives': len(expected_archives), 'files': len(manifest['files']),
            'compressed_bytes': sum(row['bytes'] for row in expected_archives.values())}


def create(source, output, target, level):
    if output == source or source in output.parents:
        raise RuntimeError('Output must be outside the evidence source directory')
    for name in ('raw', MANIFEST, SUMS):
        if (output / name).exists():
            raise RuntimeError(f'Refusing to replace existing archive output: {output / name}')
    included, excluded = inventory(source, hashes=True)
    if not included:
        raise RuntimeError('No evidence files found')
    grouped = defaultdict(list)
    for entry in included:
        grouped[entry['campaign']].append(entry)
    output.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.fsi-scale-01-archive-', dir=output.parent))
    try:
        (stage / 'raw').mkdir()
        sequence = 0

        def compress(entries):
            nonlocal sequence
            sequence += 1
            path = stage / f'candidate-{sequence:06d}.tar.xz'
            write_volume(source, entries, path, level)
            if path.stat().st_size <= target or len(entries) == 1:
                return [(path, entries)]
            path.unlink()
            at = split_point(entries)
            return compress(entries[:at]) + compress(entries[at:])

        archives = []
        used_stems = set()
        for campaign, entries in sorted(grouped.items()):
            stem = 'root-records' if campaign == '.' else re.sub(r'[^A-Za-z0-9_.-]+', '-', campaign)
            if stem in used_stems:
                stem += '-' + hashlib.sha256(campaign.encode()).hexdigest()[:8]
            used_stems.add(stem)
            volumes = compress(entries)
            for index, (temporary, members) in enumerate(volumes, 1):
                relative = f'raw/{stem}-{index:03d}.tar.xz'
                destination = stage / relative
                temporary.rename(destination)
                verify_archive(destination, members)
                for member in members:
                    member['archive'] = relative
                archive = {'path': relative, 'campaign': campaign, 'volume': index,
                           'bytes': destination.stat().st_size, 'sha256': sha_file(destination),
                           'file_count': len(members), 'uncompressed_file_bytes': sum(row['bytes'] for row in members),
                           'oversized_single_file': destination.stat().st_size > target}
                archives.append(archive)
                print(json.dumps({'archive': relative, 'bytes': archive['bytes'],
                                  'files': len(members), 'oversized_single_file': archive['oversized_single_file']}), flush=True)
        after_included, after_excluded = inventory(source)
        before = {row['path']: row['_signature'] for row in included + excluded}
        after = {row['path']: row['_signature'] for row in after_included + after_excluded}
        if before != after:
            raise RuntimeError('Evidence directory changed during archiving; no final archive published')
        manifest = {'schema': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
                    'source_directory': str(source), 'archive_path_prefix': PREFIX,
                    'archive_script_sha256': sha_file(Path(__file__)), 'python_version': platform.python_version(),
                    'target_archive_bytes': target, 'compression': {'format': 'tar.xz', 'xz_preset': level},
                    'policy': 'All regular evidence files, independent of passed/failed/interrupted status; only listed binaries/cache/spools excluded. Original input/log/VTU/CSV/partition/receipt bytes are unchanged.',
                    'tar_metadata_policy': 'Paths relative to evidence root under fsi-scale-01/; uid/gid/mtime=0 and mode0644 for deterministic transport; original mode/mtime retained per file.',
                    'source_provenance_policy': 'Actual build/source/driver/binary provenance remains in each original receipt; archive creation time is not a source/build assertion.',
                    'files': [public(row) for row in included],
                    'excluded': [public(row) for row in excluded], 'archives': archives,
                    'totals': {'included_files': len(included), 'excluded_files': len(excluded),
                               'included_bytes': sum(row['bytes'] for row in included),
                               'excluded_bytes': sum(row['bytes'] for row in excluded),
                               'archive_bytes': sum(row['bytes'] for row in archives),
                               'oversized_archives': sum(row['oversized_single_file'] for row in archives)}}
        (stage / MANIFEST).write_text(json.dumps(manifest, indent=2, allow_nan=False) + '\n')
        sums = {MANIFEST: sha_file(stage / MANIFEST), **{row['path']: row['sha256'] for row in archives}}
        (stage / SUMS).write_text(''.join(f'{value}  {name}\n' for name, value in sorted(sums.items())))
        verified = verify_output(stage)
        output.mkdir(parents=True, exist_ok=True)
        for name in ('raw', MANIFEST, SUMS):
            if (output / name).exists():
                raise RuntimeError(f'Archive destination appeared during execution: {output / name}')
        for name in ('raw', MANIFEST, SUMS):
            (stage / name).rename(output / name)
        print(json.dumps({**verified, 'output': str(output)}, indent=2))
    finally:
        shutil.rmtree(stage)


def main():
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--source', type=Path, default=base)
    parser.add_argument('--output', type=Path,
                        default=base.parents[1] / 'docs/research/data/fsi-scale-01-2026-11-26')
    parser.add_argument('--target-bytes', type=int, default=3_000_000,
                        help='Soft compressed-volume target; oversized single files are explicitly listed')
    parser.add_argument('--compression-level', type=int, choices=range(10), default=6)
    action = parser.add_mutually_exclusive_group()
    action.add_argument('--write', action='store_true', help='Create archives after all numerical/analysis writers stop')
    action.add_argument('--verify', type=Path, metavar='ARCHIVE_DIRECTORY', help='Verify an already-created archive collection')
    action.add_argument('--plan', action='store_true', help='Read-only inventory, also the default action')
    args = parser.parse_args()
    if args.verify:
        print(json.dumps(verify_output(args.verify.resolve()), indent=2))
        return
    if args.target_bytes < 1024:
        parser.error('--target-bytes must be at least 1024')
    source, output = args.source.resolve(), args.output.resolve()
    if not source.is_dir():
        parser.error('Source evidence directory does not exist')
    if args.write:
        create(source, output, args.target_bytes, args.compression_level)
        return
    included, excluded = inventory(source)
    campaigns = defaultdict(lambda: {'files': 0, 'bytes': 0})
    for row in included:
        campaigns[row['campaign']]['files'] += 1
        campaigns[row['campaign']]['bytes'] += row['bytes']
    print(json.dumps({'status': 'plan_only_no_files_written', 'source': str(source), 'output': str(output),
                      'target_archive_bytes': args.target_bytes, 'campaigns': dict(campaigns),
                      'included_files': len(included), 'included_bytes': sum(row['bytes'] for row in included),
                      'excluded_files': len(excluded), 'excluded_bytes': sum(row['bytes'] for row in excluded),
                      'excluded': [public(row) for row in excluded]}, indent=2))


if __name__ == '__main__':
    main()
