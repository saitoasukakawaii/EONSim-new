#!/usr/bin/env python3
"""Write source-linked evidence metadata; does not run numerical verification."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import shutil
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[2]
src = root / 'build/fsi-scale-01'
dst = root / 'docs/research/data/fsi-scale-01-2026-11-26'
source = '50b41ae19067bd8853a482ab853805e23c096ec5'
tree = '7f66c8b02d62ed67606f7bf5f94fd5af34915f6e'
def read(path):
    return json.loads((src/path).read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

grid = read('grid-supremizer-50b41ae-summary.json')
physical = read('physical-supremizer-50b41ae-summary.json')
native = read('native-paired-30e2941/summary.json')
unit = read('unit-50b41ae-summary.json')
receipt = read('ci-50b41ae/receipt/receipt.json')
assert grid['build_source'] == physical['build_source'] == source
assert receipt['head'] == source and receipt['tree'] == tree and receipt['status'] == 'passed'
assert all(t['status']=='passed' for t in unit['tests']) and len(unit['tests'])==3
pylog=(src/'python-fsi-runner-50b41ae.log').read_text()
assert re.search(r'Ran 19 tests?\b',pylog) and re.search(r'^OK\s*$',pylog,re.M)
ci_pylog=(src/'ci-50b41ae/selection-job.log').read_text()
assert re.search(r'Ran 19 tests?\b',ci_pylog)
junit=ET.parse(src/'ci-50b41ae/numerics/cloud-3.23.7-release/evidence/junit.xml').getroot()
assert junit.attrib['tests']=='4' and junit.attrib['failures']=='0' and junit.attrib['skipped']=='0'
binary_hash=sha(src/'eonsim-50b41ae')
assert binary_hash==grid['executable_sha256']==physical['executable_sha256']
build={
 'build_source':source,'verified_tree':tree,'mode':'Release','petsc':'3.23.7',
 'targets':['eonsim','verify_monolithic_fsi_mg'],'parallel':2,
 'command':'bash /workspace/scratch/ae740e1dde63/EONSim-new/build/locked.sh cmake --build build/release --target eonsim verify_monolithic_fsi_mg -j 2',
 'build_log':'build-50b41ae.log','build_log_sha256':sha(src/'build-50b41ae.log'),
 'executable':'eonsim-50b41ae','executable_sha256':binary_hash,
 'ctest_command':"bash /workspace/scratch/ae740e1dde63/EONSim-new/build/locked.sh ctest --test-dir build/release --no-tests=error -R '^monolithic_fsi_mg_mpi[124]$' --output-on-failure --output-junit build/fsi-scale-01/unit-50b41ae.xml",
 'ctest':unit,'python_methods':19,'python_log':'python-fsi-runner-50b41ae.log',
 'record_kind':'metadata assembled after execution from preserved source publication, build, test, and fixed-binary evidence',
 'sequence':'complete source and full remote tree verified before Release build and numerical execution',
 'warnings':'Full compiler output retained; successful build is not a warning-free claim.'}
write(src/'build-50b41ae.json',build)
copies={
 'grid-supremizer-50b41ae-summary.json':'grid-final.json',
 'physical-supremizer-50b41ae-summary.json':'physical-final.json',
 'grid-supremizer-50b41ae-independent-audit.json':'grid-final-audit.json',
 'physical-supremizer-50b41ae-independent-audit.json':'physical-final-audit.json',
 'grid-kcycle-30-summary.json':'grid-kcycle-30.json',
 'native-paired-30e2941/summary.json':'native-pair-30.json',
 'paired-actions-6378-summary.json':'paired-actions-6378.json',
 'cluster-smoke-6378-summary.json':'cluster-smoke-6378.json',
 'ci-50b41ae/receipt/receipt.json':'source-ci-receipt.json',
 'ci-50b41ae/download-verification.json':'source-ci-artifact-hashes.json'}
curated=dst/'summaries'
curated.mkdir(exist_ok=True)
index=[]
for original, name in copies.items():
    shutil.copyfile(src/original,curated/name)
    index.append({'path':'summaries/'+name,'original':'fsi-scale-01/'+original,'sha256':sha(curated/name),'bytes':(curated/name).stat().st_size})
features=[
 {'priority':'P0','feature':'FSI Multigrid Convergence Optimization','implementation':'weighted physical restriction, bounded K-cycle, pressure supremizers','validation':'passed fixed-window original equation and physical gates','target_status':'open','threshold_max_min_mean_iterations':1.3,'observed_supremizer_ratio':grid['finite_window_goal']['modes']['mono_supremizer']['observed_ratio']},
 {'priority':'P0','feature':'Reduced Assembled Preconditioner','implementation':'smaller AIJ/COO graph for approximate P; exact full matrix-free Jacobian action','validation':'AIJ/COO and final physical combination passed','target_status':'implemented_bounded_validation','nnz_domains':[10170,7788],'nnz_moving_rcr':[14639,11418]},
 {'priority':'P0','feature':'Physics-aware Block Scaling','implementation':'two-sided semantic field scaling; physical weighted first restriction','validation':'manufactured, 1/2/4-rank and physical checks passed','target_status':'implemented_bounded_validation','limitation':'does not prove uniform conditioning for general FSI'},
 {'priority':'P0','feature':'FSI-aware Coarse Space','implementation':'physical candidates and bounded selected pressure-velocity response pairs','validation':'candidate reproduction and actual FP64 coarse pairing checked','target_status':'implemented_bounded_validation','limitation':'selected fine-level pairs; no all-level global inf-sup guarantee'},
 {'priority':'P1','feature':'Adaptive Vanka Patch Selection','implementation':'interface or strong interentity growth; preserve all core rows','validation':'MPI unit and physical combinations passed','target_status':'implemented_bounded_validation'},
 {'priority':'P1','feature':'Partial Assembly','implementation':'current-Newton quadrature intermediates for fluid/solid; independent P lag','validation':'exact-action, physics, and three paired cost observations passed','target_status':'implemented_bounded_validation','limitation':'no standalone cache preparation timer'},
 {'priority':'P1','feature':'Native FP32 Multigrid','implementation':'float sparse level operations/transfers and local factors; compact patches and setup release','validation':'MPI lifecycle/failure recovery and same-source FP64/FP32 pair passed','target_status':'implemented_bounded_validation','peak_rss_max_ratio':native['comparison']['peak_rss_max_ratio'],'limitation':'outer P, coarse solve, PETSc vectors/MPI remain FP64; no measured bandwidth-halving claim'},
 {'priority':'P1','feature':'SIMD Matrix-free Kernels','implementation':'four-cell SoA fluid/solid/ALE direction batches and scalar tails','validation':'exact actions, physical checks, packed machine-code evidence, three paired costs','target_status':'implemented_bounded_validation','limitation':'no universal end-to-end speedup claim'},
 {'priority':'P1','feature':'Matrix-free MPI Overlap','implementation':'start direction halo, compute owned cells, finish halo/ports; failure drain','validation':'MPI correctness, failure recovery, physical and single-host paired costs','target_status':'implemented_bounded_validation','limitation':'multinode overlap benefit unmeasured'},
 {'priority':'P2','feature':'Adaptive Inexact Newton','implementation':'bounded EW-II forcing with unchanged final physical acceptance','validation':'actual forcing and physical gates passed','target_status':'implemented_bounded_validation','max_inexact_residual_to_requested_gate':physical['checks']['max_inexact_linear_ratio']},
 {'priority':'P2','feature':'Krylov Subspace Recycling','implementation':'bounded successful correction span; current-operator images and checked initial projection','validation':'cross-step projection counters and original residual gates passed','target_status':'implemented_bounded_validation','limitation':'correction-space recycling, not full Arnoldi/GCRO-DR'},
 {'priority':'P2','feature':'Large-scale FSI Benchmark','implementation':'strong/weak launcher, minimum DoF/host gates and disk-backed topology/field audit','validation':'eight single-host strong/weak smoke runs passed','target_status':'open','maximum_actual_dofs':10387,'maximum_actual_hosts':1,'million_dof_runs':0,'multinode_runs':0}]
summary={
 'task':'FSI-SCALE-01','pr':'https://github.com/saitoasukakawaii/EONSim-new/pull/64',
 'source_commit':source,'source_tree':tree,'fixed_binary_sha256':binary_hash,
 'overall_status':'implementation_and_bounded_validation_complete; convergence_and_large_scale_qualification_open',
 'source_protocol':'source completed and remote full tree verified before each affected build or numerical retest',
 'recorded_utc':datetime.now(timezone.utc).isoformat(),'user_timezone':'Asia/Shanghai',
 'features':features,
 'latest_local_tests':{'mpi_mg_executed':3,'mpi_mg_passed':3,'python_methods_executed':19,'python_methods_passed':19},
 'latest_grid':grid['checks'],'latest_physical':physical['checks'],
 'finite_window_goal':grid['finite_window_goal'],
 'source_ci':{'run_id':45853312807,'status':'success','website_run_id':45853312823,'website_status':'success','source':source,'merge_preview':receipt['commit'],'tree':receipt['tree'],'release_executed':len(receipt['executed']),'release_reused':len(receipt['reused']),'release_covered':len(receipt['covered']),'release_failed':0,'release_skipped':0,'python_methods_executed':19,'receipt':'summaries/source-ci-receipt.json','artifact_hashes':'summaries/source-ci-artifact-hashes.json'},
 'preserved_failure_classes':['initial wrapper exit126','initial projected-gradient roundoff MG failures','missing action telemetry audit failures','recursive/true residual mismatch','early reason publication guard defect','current/peak RSS telemetry mismatch','interrupted weak smoke','native FP32 peak RSS regression before lifecycle fix','Python negative-test exception expectation error','zero-test CTest selection is not a pass'],
 'not_claimed':['near mesh independence','million-DoF or multinode validation','uniform global inf-sup stability','universal end-to-end speedup','whole-process memory or bandwidth halving','offline reconstruction of unsaved J,b,dx'],
 'curated_evidence':index,
 'raw_evidence':{'manifest':'raw-manifest.json','checksums':'raw-SHA256SUMS.txt','archives_directory':'raw','path_mapping':'fsi-scale-01/... -> build/fsi-scale-01/...','binary_policy':'ELF excluded; exact source and SHA256 recorded','excluded_rebuildable':'SQLite audit spools and Python caches'},
 'merge_status':'See GitHub PR for final documentation head checks and protected head-pinned squash result; no merge is asserted by this premerge record.'}
write(dst/'summary.json',summary)
print(json.dumps({'curated_files':len(index),'source':source,'ci_executed':len(receipt['executed']),'ci_reused':len(receipt['reused']),'grid_runs':grid['checks']['runs'],'physical_runs':physical['checks']['runs'],'native_peak_ratio':native['comparison']['peak_rss_max_ratio']},indent=2))
