#!/usr/bin/env python3
"""Run only the two authorized fixed-source campaigns, retaining exact invocations."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'build/fsi-scale-01'
SOURCE = '50b41ae19067bd8853a482ab853805e23c096ec5'
BINARY = BASE / 'eonsim-50b41ae'
BINARY_SHA = 'dea9ab78339d4d07a8a83bac11fb22f733898d45ef681d51b99f71adfa3522e7'
WRAPPER = '/workspace/scratch/ae740e1dde63/EONSim-new/build/locked.sh'
MPI = '/workspace/scratch/ae740e1dde63/EONSim-new/.cloud/petsc-3.23.7/bin/mpiexec'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('kind', choices=('grid', 'physical'))
args = parser.parse_args()
label = ('grid-supremizer' if args.kind == 'grid' else 'physical-supremizer') + '-50b41ae'
invocation = BASE / (label + '-invocation.json')
console = BASE / (label + '-console.log')
if invocation.exists() or console.exists():
    raise RuntimeError('Preserve existing campaign evidence; this invocation already exists')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
if sha(BINARY) != BINARY_SHA:
    raise RuntimeError('Fixed binary hash differs from the authorized artifact')
driver = ROOT / 'tests/verify_fsi_multigrid.py'
published_driver = subprocess.check_output(['git', 'show', SOURCE + ':tests/verify_fsi_multigrid.py'], cwd=ROOT)
if hashlib.sha256(published_driver).hexdigest() != sha(driver):
    raise RuntimeError('Driver differs from published source')
modes = ['mono_optimized', 'mono_supremizer'] if args.kind == 'grid' else [
         'mono_optimized', 'mono_kcycle', 'mono_supremizer', 'mono_all']
sections = ['scaling'] if args.kind == 'grid' else ['default', 'moving']
command = ['bash', WRAPPER, 'python', str(driver), '--executable', str(BINARY), '--mpiexec', MPI,
           '--sections', *sections, '--modes', *modes, '--work', str(BASE / label), '--build-source', SOURCE]
record = dict(command=command, status='running', build_source=SOURCE,
              driver_source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              driver_matches_build_source=True, driver_sha256=sha(driver), executable_sha256=BINARY_SHA,
              started_utc=datetime.now(timezone.utc).isoformat(), console_log=str(console),
              expected_runs=9 if args.kind == 'grid' else 15)
if args.kind == 'grid':
    record['declared_target'] = dict(subdivisions=[4, 6, 8], ranks=2,
                                    max_min_iterations_per_correction=1.3,
                                    strict_linear_gate='1e-12 + 1e-10*rhs_norm',
                                    field_absolute_limit=2e-9, physical_acceptance_independent=True)
def save():
    invocation.write_text(json.dumps(record, indent=2) + '\n')
save()
started = time.monotonic()
returncode = None
try:
    with console.open('x') as stream:
        returncode = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT).returncode
    record.update(status='completed' if returncode == 0 else 'failed', returncode=returncode)
except KeyboardInterrupt:
    record.update(status='interrupted', returncode=130)
    returncode = 130
    raise
finally:
    record.update(wall_seconds=time.monotonic() - started, finished_utc=datetime.now(timezone.utc).isoformat(),
                  console_sha256=sha(console))
    save()
    print(json.dumps(record, indent=2), flush=True)
raise SystemExit(returncode)
