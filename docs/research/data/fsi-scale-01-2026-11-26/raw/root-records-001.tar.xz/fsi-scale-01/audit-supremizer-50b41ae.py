#!/usr/bin/env python3
"""Read-only, independent audit of the fixed 50b41ae pressure-pair campaigns.

Uses only the Python standard library and saved artifacts. It never invokes
EONSim, imports a campaign parser, or changes a numerical acceptance threshold.
Reported residual norms are checked against their gates; this audit does not
reconstruct the original operator from saved visualization files.
"""
import argparse
import collections
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'build/fsi-scale-01'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--campaign', type=Path, required=True)
parser.add_argument('--invocation', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--kind', choices=('grid', 'physical'), required=True)
args = parser.parse_args()
CAMPAIGN, DEST = args.campaign.resolve(), args.output.resolve()
SOURCE = '50b41ae19067bd8853a482ab853805e23c096ec5'
LIMIT = 2e-9
result = dict(status='running', build_source=SOURCE,
              campaign=str(CAMPAIGN), checks=[], cases=[], errors=[])


def need(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def records(log, name):
    return [dict(re.findall(r'(\w+)=([^\s]+)', line))
            for line in log.splitlines() if line.startswith(name + ' ')]


def history(path):
    with path.open() as stream:
        rows = [{k: float(v) for k, v in row.items()} for row in csv.DictReader(stream)]
    need(rows and all(math.isfinite(v) for row in rows for v in row.values()),
         f'Invalid history {path}')
    return rows


def difference(first, second):
    need(first.keys() == second.keys(), 'Physical field keys differ')
    largest = 0.0
    by_field = {}
    where = None
    for key, values in first.items():
        need(len(values) == len(second[key]), 'Physical field widths differ')
        error = max((abs(x-y) for x, y in zip(values, second[key])), default=0.)
        by_field[key[-1]] = max(error, by_field.get(key[-1], 0.))
        if error > largest:
            largest, where = error, key
    need(largest <= LIMIT, ('Physical field gate failed', largest, where))
    return dict(maximum=largest, by_field=by_field, location=where)


def load_piece(path):
    root = ET.parse(path).getroot()
    piece = root.find('.//Piece')
    count = int(piece.attrib['NumberOfPoints'])
    arrays = {}
    for array in piece.findall('./PointData/DataArray'):
        name = array.attrib['Name']
        need(name not in arrays, ('Duplicate point data', path, name))
        width = int(array.attrib.get('NumberOfComponents', '1'))
        data = tuple(map(float, (array.text or '').split()))
        need(width > 0 and len(data) == width*count and all(map(math.isfinite, data)),
             ('Invalid point data', path, name))
        arrays[name] = (width, data)
    coord = piece.find('./Points/DataArray')
    coordinates = tuple(map(float, (coord.text or '').split()))
    need(len(coordinates) == 3*count and all(map(math.isfinite, coordinates)),
         ('Invalid coordinates', path))
    arrays['coordinates'] = (3, coordinates)
    need({'mesh_node_id', 'owner'} <= arrays.keys(), ('Missing identity', path))
    ids, owners = arrays['mesh_node_id'][1], arrays['owner'][1]
    need(len(set(ids)) == count and all(x.is_integer() for x in ids + owners),
         ('Invalid identity', path))
    cells = {a.attrib['Name']: tuple(map(int, (a.text or '').split()))
             for a in piece.findall('./Cells/DataArray')}
    cell_data = {a.attrib['Name']: tuple(map(int, (a.text or '').split()))
                 for a in piece.findall('./CellData/DataArray')}
    connectivity, offsets, types = (cells[k] for k in ('connectivity', 'offsets', 'types'))
    need(len(offsets) == len(types) == int(piece.attrib['NumberOfCells']) and
         offsets and offsets[-1] == len(connectivity) and
         all(0 <= x < count for x in connectivity), ('Invalid cells', path))
    previous = 0
    canonical = []
    for index, offset in enumerate(offsets):
        need(offset > previous, ('Invalid cell offsets', path))
        canonical.append((types[index], tuple(int(ids[i]) for i in connectivity[previous:offset]),
                          tuple((name, values[index]) for name, values in sorted(cell_data.items()))))
        previous = offset
    topology = dict(point_ids=ids, owners=owners, cells=canonical)
    return arrays, set(ids[i] for i in connectivity), topology


def volume(stem, ranks):
    owner_values, ghost_values, topologies = {}, [], {}
    pieces = 0
    for domain in ('', '_solid'):
        loaded = []
        support = set()
        for rank in range(ranks):
            suffix = domain + (f'_rank{rank}' if ranks > 1 else '') + '.vtu'
            path = stem.with_name(stem.name + suffix)
            arrays, local_support, topology = load_piece(path)
            loaded.append(arrays)
            support |= local_support
            topologies[suffix] = topology
            pieces += 1
        need(support, 'Empty physical domain')
        for rank, arrays in enumerate(loaded):
            for index, (node, owner) in enumerate(zip(arrays['mesh_node_id'][1], arrays['owner'][1])):
                need(0 <= owner < ranks, 'Owner outside communicator')
                if node not in support:
                    continue
                for name, (width, values) in arrays.items():
                    if name in ('mesh_node_id', 'owner', 'algebra_node_id'):
                        continue
                    key = (domain or 'fluid', int(node), name)
                    value = values[width*index:width*(index+1)]
                    if owner == rank:
                        need(key not in owner_values, ('Duplicate owner', key))
                        owner_values[key] = value
                    else:
                        ghost_values.append((key, value))
    ghost_error = 0.
    for key, values in ghost_values:
        need(key in owner_values and len(values) == len(owner_values[key]), ('Missing owner', key))
        ghost_error = max(ghost_error, max(abs(x-y) for x, y in zip(values, owner_values[key])))
    need(owner_values and ghost_error <= LIMIT, ('Ghost/owner gate failed', ghost_error))
    return owner_values, topologies, dict(pieces=pieces, owned_field_tuples=len(owner_values),
                                         ghost_field_tuples=len(ghost_values), ghost_max_difference=ghost_error)


def audit_work(log, ranks, mode):
    integer_fields = ('applications', 'level_matvecs', 'zero_start_skips', 'coarse_revisits',
                      'coarse_solves', 'coarse_iterations', 'smoother_applications',
                      'coarse_krylov_directions', 'coarse_krylov_rank_drops',
                      'coarse_krylov_rejections', 'coarse_krylov_reductions')
    generation, step = None, 0
    snapshots, deltas, groups, latest = [], [], {}, {}
    expected_cycle = 'k' if mode in ('mono_kcycle', 'mono_all') else 'v'
    for line in log.splitlines():
        if line.startswith('solver_report '):
            generation = int(records(line, 'solver_report')[0]['solver_generation'])
            step += 1
            groups[step] = []
        elif line.startswith('monolithic_mg_stats '):
            need(generation is not None, 'MG work precedes accepted-solve report')
            original = records(line, 'monolithic_mg_stats')[0]
            values = {key: int(original[key]) for key in integer_fields}
            ratio = float(original['coarse_krylov_max_residual_ratio'])
            need(original['cycle'] == expected_cycle and all(value >= 0 for value in values.values()) and
                 math.isfinite(ratio) and 0 <= ratio <= 1, 'Invalid actual MG cycle/work')
            rank, path = int(original['rank']), original['path']
            need(0 <= rank < ranks and path, 'Invalid MG rank/path')
            key = rank, path, generation
            old = latest.get(key)
            delta = {field: values[field] - (old['counters'][field] if old else 0) for field in integer_fields}
            need(all(value >= 0 for value in delta.values()), 'Cumulative work decreased within generation')
            item = dict(rank=rank, path=path, solver_generation=generation, accepted_step=step,
                        levels=int(original['levels']), counters=values,
                        coarse_krylov_max_residual_ratio=ratio)
            snapshots.append(item)
            deltas.append(dict(rank=rank, path=path, solver_generation=generation, accepted_step=step,
                               counters=delta))
            latest[key] = item
            groups[step].append((rank, path))
    need(groups and all(groups.values()), 'Missing MG accepted-step work')
    for entries in groups.values():
        paths = {path for _, path in entries}
        need(collections.Counter(entries) == collections.Counter((rank, path) for rank in range(ranks) for path in paths),
             'Missing or duplicate rank/path work')
    if mode in ('mono_kcycle', 'mono_all'):
        need(all(any(row['counters'][field] > 0 for row in snapshots) for field in
                 ('coarse_krylov_directions', 'coarse_solves', 'level_matvecs', 'smoother_applications')),
             'K-cycle actual coarse work absent')
    else:
        need(all(row['counters']['coarse_krylov_directions'] == 0 for row in snapshots),
             'V-cycle comparison executed K directions')
    return dict(snapshots=snapshots, accepted_step_deltas=deltas,
                last_by_rank_path_generation=list(latest.values()),
                scope='Cumulative snapshots are not summed. Counts are rank-local; VecNorm/VecDot requests are not measured MPI collectives.')


def audit_case(case, receipt):
    directory = CAMPAIGN / case['name']
    ranks, cfg = case['ranks'], case['configuration']
    expected_steps = cfg.get('time_control', {}).get('step_sizes', [cfg['fsi']['dt']]*cfg['fsi']['steps'])
    reference = None
    case_result = dict(name=case['name'], ranks=ranks, runs=[])
    result['cases'].append(case_result)
    for original in case['runs']:
        mode = original['mode']
        row = dict(mode=mode, status='running')
        case_result['runs'].append(row)
        need(original['status'] == 'passed', ('Driver failure retained', case['name'], mode))
        log = (directory / (mode + '.log')).read_text()
        trace = history(directory / (mode + '.csv'))
        reports = records(log, 'solver_report')
        linear = records(log, 'linear_residual')
        fields = records(log, 'field_residual')
        need(log.count('status=success') == 1 and not any(marker in log for marker in
             ('linear_residual_unavailable', 'linear_iteration_limit_residual ', 'step_retry=')),
             ('Incomplete/rejected run', mode))
        need(len(trace) == len(expected_steps) == len(reports), 'Incomplete accepted time grid')
        elapsed = 0.
        for step, (entry, dt) in enumerate(zip(trace, expected_steps), 1):
            elapsed += dt
            need(entry['step'] == step and abs(entry['accepted_dt'] - dt) <= 1e-13 and
                 abs(entry['time'] - elapsed) <= 1e-13, 'Accepted time grid differs from input')
            need(abs(entry['evaluation_body_balance']) <= LIMIT and
                 abs(entry['evaluation_power_balance']) <= LIMIT, 'Force/power balance gate failed')
            need(min(value for name, value in entry.items() if name.endswith('_j')) > 0,
                 'Nonpositive output deformation Jacobian')
        for report in reports:
            need(int(report['ranks']) == ranks and int(report['snes_reason']) > 0 and
                 int(report['ksp_reason']) > 0 and int(report['linear_started']) == int(report['linear_completed'])
                 and report['ksp'] == ('preonly' if mode == 'direct' else 'fgmres'),
                 ('Incomplete solver', report))
            need(float(report['peak_rss_max_bytes']) >= float(report['rss_max_bytes']) and
                 float(report['peak_rss_sum_bytes']) >= float(report['rss_sum_bytes']),
                 'Normalized RSS invariant failed')
        need(sum(int(report['linear_completed']) for report in reports) == len(linear) > 0,
             'Missing original-operator residual record')
        ratios, strict_ratios = [], []
        for residual in linear:
            norm, rhs = float(residual['norm']), float(residual['rhs_norm'])
            need(math.isfinite(norm) and math.isfinite(rhs) and min(norm, rhs) >= 0.,
                 'Invalid true residual')
            strict_target = 1e-12 + 1e-10 * rhs
            strict_ratios.append(norm / strict_target)
            target = strict_target
            if mode == 'mono_all':
                relative, absolute = float(residual['requested_rtol']), float(residual['requested_atol'])
                need(residual['forcing'] == '1' and math.isfinite(relative + absolute) and
                     0 < relative <= .5 and 0 <= absolute <= 1e-12, 'Invalid inexact request')
                target = (absolute + relative * rhs) * (1 + 64 * math.ulp(1.))
            ratios.append(norm / target)
        need(max(ratios) <= 1., ('True residual gate failed', case['name'], mode, max(ratios)))
        names = {f['name'] for f in fields}
        need({'velocity', 'pressure', 'mesh', 'structure'} <= names and
             collections.Counter(f['name'] for f in fields) == {name: len(trace) for name in names},
             'Incomplete final physical acceptance')
        field_ratios, constraint_ratios = [], []
        for field in fields:
            rms, limit = float(field['rms']), float(field['limit'])
            maximum, constraint_limit = float(field['constraint_max']), float(field['constraint_limit'])
            need(field['accepted'] == '1' and 0 <= rms <= limit and 0 <= maximum <= constraint_limit,
                 ('Physical acceptance failed', field))
            expected_limit = cfg['solver']['absolute_tolerance'] + cfg['solver']['relative_tolerance']*float(field['initial_rms'])
            need(math.isclose(limit, expected_limit, rel_tol=5e-14, abs_tol=0.),
                 ('Physical field gate changed from input', field))
            need(constraint_limit == cfg['solver']['absolute_tolerance'], 'Constraint gate changed from input')
            field_ratios.append(rms / limit)
            constraint_ratios.append(maximum / constraint_limit)
        snapshots = [volume(directory / f'{mode}_step{int(step["step"])}', ranks) for step in trace]
        final = volume(directory / mode, ranks)
        final_matches_last = difference(snapshots[-1][0], final[0])
        need(snapshots[-1][1] == final[1], 'Final topology differs from final accepted step')
        if reference is None:
            need(mode == 'direct', 'First mode is not the direct oracle')
            reference = (trace, snapshots, final, original['nnz'])
        baseline_trace, baseline_snapshots, baseline_final, reference_nnz = reference
        history_diffs = {}
        for base, current in zip(baseline_trace, trace):
            need(base.keys() == current.keys(), 'History columns differ')
            for name in base.keys() - {'snes_iterations'}:
                history_diffs[name] = max(history_diffs.get(name, 0.), abs(base[name]-current[name]))
        need(max(history_diffs.values()) <= LIMIT, 'History physical gate failed')
        final_diff = difference(baseline_final[0], final[0])
        step_diffs = []
        for base, current in zip(baseline_snapshots, snapshots):
            need(base[1] == current[1], 'Node identity, ownership, or cell topology changed')
            step_diffs.append(difference(base[0], current[0]))
        need(baseline_final[1] == final[1], 'Final node/owner/cell topology changed')
        row.update(accepted_steps=len(trace), corrections=len(linear),
                   dofs=int(reports[-1]['dofs']), outer_iterations=sum(int(r['linear_iterations']) for r in reports),
                   true_residual_checks=sum(int(r['true_residual_checks']) for r in reports),
                   true_residual_rejections=sum(int(r['true_residual_rejections']) for r in reports),
                   nnz=max(int(r['nnz']) for r in reports),
                   max_true_residual_ratio=max(ratios),
                   linear_gate='requested inexact forcing' if mode == 'mono_all' else '1e-12 + 1e-10*rhs_norm',
                   max_fixed_gate_ratio_diagnostic=max(strict_ratios),
                   max_physical_acceptance_ratio=max(field_ratios),
                   max_constraint_acceptance_ratio=max(constraint_ratios),
                   final_difference=final_diff, accepted_step_differences=step_diffs,
                   field_max_difference=max(final_diff['maximum'], *(d['maximum'] for d in step_diffs)),
                   history_max_difference=max(history_diffs.values()), history_differences=history_diffs,
                   final_matches_last_step=final_matches_last,
                   volume_audits=[s[2] for s in snapshots] + [final[2]],
                   linear_records=linear, solver_records=reports, final_field_records=fields,
                   accepted_time_grid=[dict(step=r['step'], time=r['time'], dt=r['accepted_dt']) for r in trace])
        if mode == 'mono_all':
            preconditioner = records(log, 'fsi_preconditioner')
            need(preconditioner and all(p['reduced'] == '1' and p['stores_full_jacobian'] == '0'
                 for p in preconditioner), 'Reduced P full-Jacobian storage claim missing')
            need(row['nnz'] < reference_nnz, 'Reduced P did not reduce the actual sparse graph')
            row['nnz_reduction_fraction'] = 1 - row['nnz'] / reference_nnz
            action = records(log, 'fsi_action_report')
            need(len(action) == len(trace) and all(a['partial_assembly'] == a['simd'] == a['overlap'] == '1'
                 for a in action), 'Action mechanism missing')
            need(all(int(a['prepared_cells']) > 0 and int(a['cached_actions']) > 0 and
                 int(a['simd_batches']) > 0 and int(a['cache_bytes']) > 0 for a in action),
                 'Action mechanism performed no work')
            row['action_records'] = action
            for counter in ('matrix_free_actions', 'matrix_free_preparations', 'matrix_free_overlapped_actions',
                            'assembled_pc_reuses', 'inexact_linear_solves', 'recycle_projections'):
                row[counter] = sum(int(r[counter]) for r in reports)
            need(row['inexact_linear_solves'] == len(linear) and row['recycle_projections'] > 0 and
                 row['matrix_free_overlapped_actions'] == row['matrix_free_actions'] > 0 and
                 row['assembled_pc_reuses'] > 0, 'Optimized mechanism count mismatch')
        if mode != 'direct':
            hierarchy = records(log, 'pc_monolithic_mg')
            transfer = records(log, 'pc_monolithic_mg_level')
            smoother = records(log, 'pc_monolithic_mg_smoother')
            storage = records(log, 'pc_monolithic_mg_storage')
            need(hierarchy and transfer and all(int(h['levels']) >= 2 for h in hierarchy), 'No hierarchy')
            need(all(int(t['rows']) > int(t['coarse_rows']) and float(t['reproduction_error']) <= 1e-9 and
                 float(t['energy_after']) <= float(t['energy_before'])*(1+1e-10)+1e-12 for t in transfer),
                 'Transfer reproduction or energy gate failed')
            row.update(hierarchy_records=hierarchy, transfer_records=transfer, storage_records=storage,
                       smoother_records=smoother, mg_work=audit_work(log, ranks, mode))
            requested_cycle = 'k' if mode in ('mono_kcycle', 'mono_all') else 'v'
            need(all(h['cycle'] == requested_cycle for h in hierarchy), 'Requested hierarchy cycle changed')
            if mode in ('mono_supremizer', 'mono_all'):
                need(all(h['pressure_supremizers'] == '1' for h in hierarchy),
                     'Requested pressure supremizer option absent')
                pairs = []
                for t in transfer:
                    count, aggregates = int(t['pressure_supremizer_modes']), int(t['pressure_paired_aggregates'])
                    sigma, change = float(t['pressure_pair_min_singular']), float(t['pressure_pair_relative_change'])
                    need(count >= 0 and aggregates >= 0 and math.isfinite(sigma) and sigma >= 0 and
                         math.isfinite(change) and 0 <= change <= 1e-10, 'Invalid pressure-pair metrics')
                    if int(t['level']) == 0:
                        need(0 < aggregates <= count <= 2*aggregates and sigma > 0,
                             'Fine-level pressure-pair activation absent')
                        pairs.append(t)
                    else:
                        need(count == aggregates == 0, 'Pressure-pair enrichment outside semantic fine level')
                need(len(pairs) == len(hierarchy), 'Missing fine-level pairing setup')
                row['pressure_pair_evidence'] = dict(fine_level_records=pairs,
                    scope='Aggregate-local pairs, not a global inf-sup bound. Relative change checks FP64 setup '
                          'coupling before/after energy minimization, not native FP32 action preservation to 1e-10.')
            else:
                need(all(h['pressure_supremizers'] == '0' for h in hierarchy),
                     'Control mode unexpectedly enabled pressure supremizers')
            if mode in ('mono_optimized', 'mono_kcycle', 'mono_supremizer', 'mono_all'):
                need(all(h['native_fp32'] == h['fsi_candidates'] == h['field_scaling'] == '1' for h in hierarchy),
                     'Native/scaling/candidate mechanism absent')
                last_storage = {int(s['rank']): s for s in storage}
                last_smoothers = {(int(s['rank']), int(s['level'])): s for s in smoother}
                need(set(last_storage) == set(range(ranks)), 'Missing final rank-local storage')
                total = {k: sum(int(s[k]) for s in last_storage.values()) for k in
                         ('fp32_value_bytes', 'retained_fp64_operator_bytes', 'released_fp64_operator_bytes')}
                total.update({k: sum(int(s[k]) for s in last_smoothers.values()) for k in
                             ('fp32_patches', 'fp32_patch_bytes', 'retained_fp64_patch_bytes', 'factor_bytes',
                              'native_sparse_patches', 'native_dense_patches', 'native_index_bytes')})
                need(total['fp32_value_bytes'] > 0 and total['released_fp64_operator_bytes'] > 0 and
                     total['fp32_patches'] > 0 and total['retained_fp64_patch_bytes'] == 0,
                     'Native FP32 coefficient/patch conversion not observed')
                row['last_hierarchy_storage_sum_across_ranks'] = total
                row['storage_note'] = ('Last refresh only; float coefficients exclude dense factors and indices, reported separately. '
                                       'Not an RSS reduction or a ratio against released operator bytes.')
        if 'rcr_outlet' in cfg['fsi']['domains']:
            model = cfg['fsi']['domains']['rcr_outlet']
            faces = [f for f in history(directory / (mode + '_pressure_faces.csv')) if f['tag'] == model['tag']]
            need(len(faces) == len(trace), 'Missing pressure-face history')
            worst = 0.
            for current, face in zip(trace, faces):
                need(current['step'] == face['step'] and current['time'] == face['time'], 'RCR history time mismatch')
                need(current['rcr_tag'] == model['tag'], 'RCR tag mismatch')
                for phase in ('stage', 'endpoint'):
                    flow = face[phase + '_outward_flow']
                    capacitor = current[phase + '_capacitor_pressure']
                    pressure = face[phase + '_prescribed_pressure']
                    defects = [current[phase+'_rcr_flow']-flow, current[phase+'_rcr_pressure']-pressure,
                               pressure-capacitor-model['proximal_resistance']*flow,
                               face[phase+'_pressure_power']+flow*pressure]
                    if phase == 'stage':
                        defects += [model['compliance']*current['stage_capacitor_rate']-flow+
                                    (capacitor-model['distal_pressure'])/model['distal_resistance'],
                                    current['applied_pressure']-pressure]
                    worst = max(worst, *map(abs, defects))
            need(worst < 2e-10, ('RCR circuit gate failed', worst))
            row['circuit_defect'] = worst
        for name in ('dofs', 'accepted_steps', 'corrections', 'outer_iterations', 'nnz',
                     'max_true_residual_ratio', 'field_max_difference', 'history_max_difference'):
            need(math.isclose(row[name], original[name], rel_tol=2e-14, abs_tol=1e-30),
                 ('Independent result differs from receipt', case['name'], mode, name, row[name], original[name]))
        row['iterations_per_correction'] = row['outer_iterations'] / row['corrections']
        row['timings'] = {key: sum(float(r[key]) for r in reports) for key in
                          ('solve_seconds', 'linear_seconds', 'assembly_seconds', 'setup_seconds', 'schur_setup_seconds')}
        row['artifact_hashes_verified'] = 0
        for artifact in original['artifacts']:
            path = Path(artifact['path'])
            need(path.stat().st_size == artifact['bytes'] and digest(path) == artifact['sha256'],
                 ('Artifact changed since campaign', path))
            row['artifact_hashes_verified'] += 1
        row['status'] = 'passed'


try:
    receipt = json.loads((CAMPAIGN / 'results.json').read_text())
    invocation = json.loads(args.invocation.read_text())
    need(receipt['status'] == 'passed' and invocation['status'] == 'completed' and invocation['returncode'] == 0 and
         not receipt['failures'] and receipt['build_source'] == invocation['build_source'] == SOURCE and
         receipt['source_commit'] == invocation['driver_source_commit'] and invocation['driver_matches_build_source'],
         'Campaign receipt/source mismatch')
    result['executable_sha256'] = digest(receipt['executable'])
    result['driver_sha256'] = digest(ROOT / 'tests/verify_fsi_multigrid.py')
    result['receipt_sha256'] = digest(CAMPAIGN / 'results.json')
    result['driver_source_commit'] = receipt['source_commit']
    result['driver_matches_production_source'] = invocation['driver_matches_build_source']
    result['audit_script_sha256'] = digest(__file__)
    need(result['executable_sha256'] == receipt['executable_sha256'] == invocation['executable_sha256'] and
         result['driver_sha256'] == receipt['driver_sha256'],
         'Fixed binary/driver changed')
    result['command_logs_verified'] = 0
    for command in receipt['commands']:
        need(command['status'] == 'passed' and digest(command['log']) == command['log_sha256'],
             ('Command log changed or failed', command['label']))
        result['command_logs_verified'] += 1
    expected_names = {'scaling-n4-r2', 'scaling-n6-r2', 'scaling-n8-r2'} if args.kind == 'grid' else {
                      'domains-r1', 'domains-r2', 'moving-rcr'}
    expected_modes = {'direct', 'mono_optimized', 'mono_supremizer'} if args.kind == 'grid' else {
                      'direct', 'mono_optimized', 'mono_kcycle', 'mono_supremizer', 'mono_all'}
    need({c['name'] for c in receipt['cases']} == expected_names and len(receipt['cases']) == 3,
         'Campaign case inventory changed')
    for case in receipt['cases']:
        need({r['mode'] for r in case['runs']} == expected_modes and len(case['runs']) == len(expected_modes),
             'Campaign mode inventory changed')
        audit_case(case, receipt)
    runs = [r for c in result['cases'] for r in c['runs']]
    result.update(status='passed', runs=len(runs), accepted_steps=sum(r['accepted_steps'] for r in runs),
                  linear_corrections=sum(r['corrections'] for r in runs),
                  artifact_hashes_verified=sum(r['artifact_hashes_verified'] for r in runs),
                  volume_pieces_parsed=sum(v['pieces'] for r in runs for v in r['volume_audits']),
                  max_field_difference=max(r['field_max_difference'] for r in runs),
                  max_history_difference=max(r['history_max_difference'] for r in runs),
                  max_ghost_difference=max(v['ghost_max_difference'] for r in runs for v in r['volume_audits']),
                  max_strict_linear_ratio=max(r['max_true_residual_ratio'] for r in runs if r['mode'] != 'mono_all'),
                  max_inexact_linear_ratio=max((r['max_true_residual_ratio'] for r in runs if r['mode'] == 'mono_all'), default=None),
                  true_residual_checks=sum(r['true_residual_checks'] for r in runs),
                  true_residual_rejections=sum(r['true_residual_rejections'] for r in runs))
    if args.kind == 'grid':
        result['finite_window_goal'] = dict(maximum_ratio=1.3, subdivisions=[4, 6, 8], modes={})
        need(receipt['mesh_convergence_goal']['maximum_ratio'] == 1.3, 'Declared target changed')
        for mode in ('mono_optimized', 'mono_supremizer'):
            points = [r for r in runs if r['mode'] == mode]
            need(len(points) == 3, 'Incomplete fixed convergence window')
            values = [r['iterations_per_correction'] for r in points]
            ratio = max(values) / min(values)
            goal = dict(status='met' if ratio <= 1.3 else 'open', observed_ratio=ratio,
                        dofs=[r['dofs'] for r in points], iterations_per_correction=values)
            need(goal['status'] == receipt['mesh_convergence_goal']['modes'][mode]['status'] and
                 math.isclose(ratio, receipt['mesh_convergence_goal']['modes'][mode]['observed_ratio'], rel_tol=1e-14),
                 'Independent convergence assessment differs')
            result['finite_window_goal']['modes'][mode] = goal
    result['checks'] = ['Fixed source, executable, driver and artifact hashes',
                        'All accepted prescribed step sizes and successful Newton/Krylov reasons',
                        'Each logged original-operator norm against the unchanged applicable linear gate',
                        'Each final physical and constraint gate against the configured tolerance',
                        'Every accepted-step and final fluid/solid volume VTU field and coordinate vs direct',
                        'Volume node identity, ownership, connectivity and cell identifiers',
                        'Ghost fields vs owners, final output vs final accepted step',
                        'Every CSV physical column except the intentionally variable Newton iteration count',
                        'Native FP32 final coefficient/patch storage across ranks',
                        'Hierarchy transfer reproduction/energy and actual cumulative V/K work counters',
                        'Fine aggregate pressure pairs and FP64 setup coupling preservation; no global inf-sup claim']
    result['limitations'] = ['Residual norms originate from solver diagnostics; visualization cannot reconstruct J.',
                             'Storage values are coefficient counts from the final hierarchy, not measured total memory savings.',
                             'Small single-host cases only; any n4/6/8 convergence target is a finite window. Correctness-run timings are not a repeated speedup study or multi-node claim.']
except BaseException as exc:
    result['status'] = 'failed'
    result['errors'].append(str(exc))
finally:
    DEST.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('cases', 'checks')}, indent=2))
sys.exit(0 if result['status'] == 'passed' else 1)
