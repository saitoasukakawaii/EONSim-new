"""Summarize an existing paired-actions receipt, without executing a solver."""
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def records(text, prefix):
    rows = []
    for line in text.splitlines():
        if not line.startswith(prefix + ' '):
            continue
        row = {}
        for token in line.split()[1:]:
            if '=' not in token:
                continue
            key, value = token.split('=', 1)
            try:
                row[key] = int(value)
            except ValueError:
                try:
                    row[key] = float(value)
                    assert math.isfinite(row[key])
                except ValueError:
                    row[key] = value
        rows.append(row)
    return rows


def describe(values):
    return {'median': statistics.median(values), 'minimum': min(values),
            'maximum': max(values), 'samples': values}


def main():
    path, output = map(Path, sys.argv[1:])
    original = json.loads(path.read_text())
    assert original['status'] == 'passed' and len(original['cases']) == 1
    case = original['cases'][0]
    modes = ('mono_mf', 'mono_partial', 'mono_simd', 'mono_overlap')
    samples = [row for row in case['runs'] if row['timing_sample']]
    assert len(samples) == 12 and all(row['status'] == 'passed' for row in samples)
    report = {
        'status': 'passed_local_paired_cost_measurement',
        'source_commit': original['build_source'], 'driver_source_commit': original['source_commit'],
        'executable': original['executable'], 'executable_sha256': original['executable_sha256'],
        'original_results': str(path), 'original_results_sha256': digest(path),
        'ranks': case['ranks'], 'subdivisions': case['subdivisions'],
        'timing_repeats': original['timing_repeats'], 'expected_steps': original['expected_steps'],
        'runs': [], 'mode_statistics': {}, 'per_step_statistics': {}, 'paired_comparisons': {},
        'qualifications': [
            'Single shared host, two ranks, small physical case; these local costs are not an assertion of stable total speedup or cluster scaling.',
            'All modes use identical exact KSP relative/absolute tolerances and unchanged physical field/history gates.',
            'Statistics include three successful timing samples; reference and warmups are excluded.',
            'Timings marked rank0 are rank0 observations, not global maxima. fsi_action_report cell/event counters are global sums.',
            'owned_cells and halo_cells are current partition list sizes, not cell-action event totals; preserve them per step without summing over time.',
            'Baseline mono_mf does not request fsi_assembly_report, so its missing action report is recorded as null, not zero.',
            'Paired ratios compare candidate and baseline from the same timing round; a ratio below1 means less measured candidate time.',
        ],
    }
    solver_sums = ('linear_seconds', 'solve_seconds', 'assembly_seconds',
                   'matrix_free_seconds_rank0', 'matrix_free_overlap_seconds_rank0',
                   'matrix_free_ghost_seconds_rank0', 'matrix_free_actions',
                   'matrix_free_preparations', 'matrix_free_overlapped_actions',
                   'true_residual_checks', 'true_residual_rejections')
    action_sums = ('prepared_cells', 'cached_actions', 'simd_batches')
    common_options = None
    for row in samples:
        command = row['command']
        options = {name: command[command.index(name)+1] for name in
                   ('-ksp_type', '-ksp_rtol', '-ksp_atol', '-ksp_norm_type', '-ksp_pc_side')}
        assert common_options is None or options == common_options
        common_options = options
        log_path = Path(row['log'])
        assert digest(log_path) == row['log_sha256']
        text = log_path.read_text()
        solver = records(text, 'solver_report')
        actions = records(text, 'fsi_action_report')
        history_path = log_path.parent / 'solution.csv'
        with history_path.open() as stream:
            history = list(csv.DictReader(stream))
        assert len(solver) == len(history) == original['expected_steps']
        assert len(actions) == (0 if row['mode'] == 'mono_mf' else len(solver))
        item = {key: row[key] for key in
                ('mode', 'label', 'dofs', 'outer_iterations', 'corrections', 'wall_seconds',
                 'field_max_difference', 'history_max_difference', 'max_true_residual_ratio')}
        item.update(repeat=int(row['label'].split('-')[1]), placement=row['placement'],
                    log=str(log_path), log_sha256=row['log_sha256'],
                    per_step=[{'step': int(trace['step']), 'time': float(trace['time']),
                               'solver_report': solve, 'fsi_action_report': actions[index] if actions else None}
                              for index, (trace, solve) in enumerate(zip(history, solver))])
        item['totals'] = {key: sum(solve[key] for solve in solver) for key in solver_sums}
        item['totals']['mean_action_seconds_rank0'] = (
            item['totals']['matrix_free_seconds_rank0'] / item['totals']['matrix_free_actions'])
        if actions:
            item['action_totals'] = {key: sum(action[key] for action in actions) for key in action_sums}
            item['cache_bytes_peak_report'] = max(action['cache_bytes'] for action in actions)
        else:
            item['action_totals'] = None
            item['cache_bytes_peak_report'] = None
        report['runs'].append(item)
    report['common_solver_options'] = common_options
    for mode in modes:
        rows = sorted((row for row in report['runs'] if row['mode'] == mode), key=lambda row: row['repeat'])
        assert [row['repeat'] for row in rows] == [1, 2, 3]
        assert len({row['dofs'] for row in rows}) == 1
        stats = {key: describe([row[key] for row in rows]) for key in
                 ('wall_seconds', 'outer_iterations', 'corrections', 'field_max_difference',
                  'history_max_difference', 'max_true_residual_ratio')}
        stats.update({key: describe([row['totals'][key] for row in rows])
                      for key in (*solver_sums, 'mean_action_seconds_rank0')})
        report['mode_statistics'][mode] = stats
        by_step = []
        for index in range(original['expected_steps']):
            steps = [row['per_step'][index] for row in rows]
            entry = {'step': steps[0]['step'], 'time': steps[0]['time'],
                     'solver_report': {key: describe([step['solver_report'][key] for step in steps])
                                       for key in (*solver_sums, 'linear_iterations')},
                     'fsi_action_report': None}
            if all(step['fsi_action_report'] is not None for step in steps):
                keys = steps[0]['fsi_action_report'].keys()
                entry['fsi_action_report'] = {
                    key: describe([step['fsi_action_report'][key] for step in steps]) for key in keys}
            by_step.append(entry)
        report['per_step_statistics'][mode] = by_step
    for baseline_mode, candidate_mode in (('mono_mf', 'mono_partial'), ('mono_mf', 'mono_simd'),
                                          ('mono_mf', 'mono_overlap'), ('mono_partial', 'mono_simd')):
        base = {row['repeat']: row for row in report['runs'] if row['mode'] == baseline_mode}
        candidate = {row['repeat']: row for row in report['runs'] if row['mode'] == candidate_mode}
        pairs = []
        for repeat in (1, 2, 3):
            first, second = base[repeat], candidate[repeat]
            ratios = {'wall_seconds': second['wall_seconds']/first['wall_seconds']}
            ratios.update({key: second['totals'][key]/first['totals'][key] for key in
                           ('linear_seconds', 'solve_seconds', 'assembly_seconds', 'matrix_free_seconds_rank0',
                            'mean_action_seconds_rank0')})
            pairs.append({'repeat': repeat, 'candidate_over_baseline': ratios})
        report['paired_comparisons'][candidate_mode + '_vs_' + baseline_mode] = {
            'pairs': pairs, 'ratio_statistics': {key: describe([pair['candidate_over_baseline'][key] for pair in pairs])
                                                for key in pairs[0]['candidate_over_baseline']}}
    report['observed_scale'] = original['observed_scale']
    report['maximum_field_difference'] = max(row['field_max_difference'] for row in report['runs'])
    report['maximum_true_residual_gate_ratio'] = max(row['max_true_residual_ratio'] for row in report['runs'])
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(output)
    for mode, stats in report['mode_statistics'].items():
        print(mode, 'wall', stats['wall_seconds'], 'action', stats['matrix_free_seconds_rank0'],
              'iterations', stats['outer_iterations']['samples'])
    for name, comparison in report['paired_comparisons'].items():
        print(name, 'wall ratio', comparison['ratio_statistics']['wall_seconds'],
              'action ratio', comparison['ratio_statistics']['matrix_free_seconds_rank0'])


if __name__ == '__main__':
    main()
