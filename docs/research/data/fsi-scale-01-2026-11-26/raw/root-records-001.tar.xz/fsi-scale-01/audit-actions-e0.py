"""Independently inspect already-produced e0 artifacts; never launch a solver."""
import csv
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'build/fsi-scale-01/physical-actions/1795703452631949515'
SOURCE = BASE / 'results.json'
OUT = ROOT / 'build/fsi-scale-01/actions-e0-audit.json'
LIMIT = 2e-9


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def records(text, prefix):
    return [dict(token.split('=', 1) for token in line.split()[1:] if '=' in token)
            for line in text.splitlines() if line.startswith(prefix + ' ')]


def snapshot(directory, stem, ranks):
    fields, topology, ghost_error = {}, {}, 0.0
    for domain in ('', '_solid'):
        observations, supported, domain_cells = {}, set(), {}
        for rank in range(ranks):
            suffix = f'_rank{rank}' if ranks > 1 else ''
            path = directory / (stem + domain + suffix + '.vtu')
            piece = ET.parse(path).find('.//Piece')
            n, nc = int(piece.get('NumberOfPoints')), int(piece.get('NumberOfCells'))

            def arrays(group):
                found = {}
                for array in piece.findall(group + '/DataArray'):
                    vals = [float(x) for x in (array.text or '').split()]
                    assert all(math.isfinite(x) for x in vals), (path, 'nonfinite')
                    found[array.get('Name', 'coordinates')] = (
                        int(array.get('NumberOfComponents', '1')), vals)
                return found

            points, point_data = arrays('Points'), arrays('PointData')
            cell_data, cells = arrays('CellData'), arrays('Cells')
            ids = point_data['mesh_node_id'][1]
            owners = point_data['owner'][1]
            assert len(ids) == len(owners) == n and len(set(ids)) == n
            assert all(x.is_integer() for x in ids + owners)
            assert all(0 <= x < ranks for x in owners)
            values = {'coordinates': points['coordinates'], **{
                key: row for key, row in point_data.items()
                if key not in ('mesh_node_id', 'owner', 'algebra_node_id')}}
            assert all(len(vals) == n * components for components, vals in values.values())
            for index, node_id in enumerate(ids):
                item = {key: tuple(vals[index*components:(index+1)*components])
                        for key, (components, vals) in values.items()}
                observations.setdefault(int(node_id), []).append((rank, int(owners[index]), item))
            conn, offsets, types = (cells[key][1] for key in ('connectivity', 'offsets', 'types'))
            cell_ids, tags = (cell_data[key][1] for key in ('mesh_element_id', 'physical_tag'))
            assert len(offsets) == len(types) == len(cell_ids) == len(tags) == nc
            start = 0
            for end, cell_id, tag, kind in zip(offsets, cell_ids, tags, types):
                assert all(x.is_integer() for x in (end, cell_id, tag, kind))
                end = int(end)
                assert start < end <= len(conn)
                idx = conn[start:end]
                assert all(x.is_integer() and 0 <= x < n for x in idx)
                node_ids = tuple(int(ids[int(index)]) for index in idx)
                assert int(cell_id) not in domain_cells, (path, 'duplicate cell')
                domain_cells[int(cell_id)] = (int(tag), int(kind), node_ids)
                supported.update(node_ids)
                start = end
            assert start == len(conn)
        for node_id in supported:
            observed = observations[node_id]
            owner_rows = [item for rank, owner, item in observed if rank == owner]
            assert len(owner_rows) == 1, (stem, domain, node_id, 'invalid ownership')
            owner_value = owner_rows[0]
            for _, _, item in observed:
                assert item.keys() == owner_value.keys()
                for key in item:
                    assert len(item[key]) == len(owner_value[key])
                    ghost_error = max(ghost_error, max(abs(x-y) for x, y in zip(item[key], owner_value[key])))
            fields[domain, node_id] = owner_value
        topology[domain] = domain_cells
    assert ghost_error <= LIMIT, ('ghost discrepancy', ghost_error)
    return fields, topology, ghost_error


def field_difference(expected, actual):
    assert expected[0].keys() == actual[0].keys()
    assert expected[1] == actual[1], 'cell topology changed'
    worst, field_max = 0.0, {}
    for node, a in expected[0].items():
        b = actual[0][node]
        assert a.keys() == b.keys()
        for key in a:
            assert len(a[key]) == len(b[key])
            diff = max(abs(x-y) for x, y in zip(a[key], b[key]))
            field_max[key] = max(field_max.get(key, 0.0), diff)
            worst = max(worst, diff)
    assert worst <= LIMIT, ('field discrepancy', worst)
    return worst, field_max


def history(path):
    with path.open() as stream:
        rows = [{key: float(value) for key, value in row.items()}
                for row in csv.DictReader(stream)]
    assert len(rows) == 3
    assert all(math.isfinite(x) for row in rows for x in row.values())
    assert [row['step'] for row in rows] == [1.0, 2.0, 3.0]
    return rows


def main():
    original = json.loads(SOURCE.read_text())
    result = {
        'method': 'Independent standard-library XML/CSV/log/receipt inspection of existing artifacts; no solver or test reruns',
        'source_commit': original['source_commit'],
        'executable': original['executable'],
        'executable_sha256': original['executable_sha256'],
        'original_results': str(SOURCE),
        'original_results_sha256': sha(SOURCE),
        'original_campaign_status': original['status'],
        'scope': '15 originally passed runs; all saved volume steps and final fields/topology/ghosts, all accepted histories, all true residuals, final field gates, mechanism counters, all archived artifact hashes',
        'field_absolute_limit': LIMIT,
        'runs': [],
    }
    for case in original['cases']:
        directory, ranks = BASE / case['name'], case['ranks']
        reference_fields = {step: snapshot(directory, 'direct' + step, ranks)
                            for step in ('', '_step1', '_step2', '_step3')}
        reference_history = history(directory / 'direct.csv')
        direct_nnz = next(row['nnz'] for row in case['runs'] if row['mode'] == 'direct')
        for saved in case['runs']:
            if saved['status'] != 'passed':
                continue
            mode = saved['mode']
            for artifact in saved['artifacts']:
                path = Path(artifact['path'])
                assert path.stat().st_size == artifact['bytes'] and sha(path) == artifact['sha256'], path
            log_path = directory / (mode + '.log')
            log = log_path.read_text()
            reports = records(log, 'solver_report')
            residuals = records(log, 'linear_residual')
            accepted_fields = records(log, 'field_residual')
            assert len(reports) == 3 and log.count('status=success') == 1
            assert not any(marker in log for marker in ('linear_residual_unavailable', 'linear_iteration_limit_residual ', 'step_retry='))
            assert all(int(row['ranks']) == ranks and min(int(row['snes_reason']), int(row['ksp_reason'])) > 0
                       and int(row['linear_started']) == int(row['linear_completed']) for row in reports)
            assert sum(int(row['linear_completed']) for row in reports) == len(residuals)
            assert all(row['ksp'] == ('preonly' if mode == 'direct' else 'fgmres') for row in reports)
            field_names = {row['name'] for row in accepted_fields}
            assert {'velocity', 'pressure', 'mesh', 'structure'} <= field_names
            assert all(sum(row['name'] == name for row in accepted_fields) == 3 for name in field_names)
            final_gate_ratio = 0.0
            for row in accepted_fields:
                assert int(row['accepted']) == 1
                for value, limit in (('rms', 'limit'), ('constraint_max', 'constraint_limit')):
                    v, lim = float(row[value]), float(row[limit])
                    assert math.isfinite(v) and math.isfinite(lim) and 0 <= v <= lim
                    final_gate_ratio = max(final_gate_ratio, v / lim if lim else 0)
            ratios = []
            for row in residuals:
                norm, rhs = float(row['norm']), float(row['rhs_norm'])
                assert math.isfinite(norm) and math.isfinite(rhs) and min(norm, rhs) >= 0
                target = 1e-12 + 1e-10 * rhs
                if mode == 'mono_inexact':
                    rtol, atol = float(row['requested_rtol']), float(row['requested_atol'])
                    assert int(row['forcing']) == 1 and math.isfinite(rtol+atol) and 0 < rtol <= .5 and 0 <= atol <= 1e-12
                    target = (atol + rtol * rhs) * (1 + 64 * math.ulp(1.0))
                ratios.append(norm / target)
            assert max(ratios) <= 1
            nnz = max(float(row['nnz']) for row in reports)
            if mode in ('mono_reduced', 'mono_reduced_coo'):
                pcs = records(log, 'fsi_preconditioner')
                assert pcs and all(row['reduced'] == '1' and row['stores_full_jacobian'] == '0' for row in pcs)
                assert 0 < nnz < direct_nnz
            inexact = sum(int(row['inexact_linear_solves']) for row in reports)
            recycle = sum(int(row['recycle_projections']) for row in reports)
            recycle_vectors = max(int(row['recycle_vectors']) for row in reports)
            if mode == 'mono_inexact':
                assert inexact == len(residuals)
            if mode == 'mono_recycle':
                assert recycle > 0 and recycle_vectors > 0
            trajectory_difference, final_difference, ghost_difference, per_field = 0.0, 0.0, 0.0, {}
            for step in ('', '_step1', '_step2', '_step3'):
                actual = snapshot(directory, mode + step, ranks)
                difference, field_diffs = field_difference(reference_fields[step], actual)
                if not step:
                    final_difference = difference
                    per_field = field_diffs
                    final_snapshot = actual
                if step == '_step3':
                    assert field_difference(final_snapshot, actual)[0] == 0.0
                trajectory_difference = max(trajectory_difference, difference)
                ghost_difference = max(ghost_difference, actual[2])
            trace = history(directory / (mode + '.csv'))
            history_difference = 0.0
            for a, b in zip(reference_history, trace):
                assert a.keys() == b.keys()
                for key in ('step', 'time', 'accepted_dt'):
                    assert abs(a[key] - b[key]) <= 1e-13
                history_difference = max(history_difference, max(abs(a[key]-b[key]) for key in a if key != 'snes_iterations'))
            assert history_difference <= LIMIT
            iterations = sum(int(row['linear_iterations']) for row in reports)
            assert iterations == saved['outer_iterations'] and nnz == saved['nnz']
            assert abs(trajectory_difference - saved['field_max_difference']) <= 1e-30
            assert abs(history_difference - saved['history_max_difference']) <= 1e-30
            assert abs(max(ratios) - saved['max_true_residual_ratio']) <= 1e-30
            result['runs'].append({
                'case': case['name'], 'mode': mode, 'status': 'passed_offline_audit', 'ranks': ranks,
                'dofs': int(reports[-1]['dofs']), 'preconditioner_nnz': int(nnz),
                'reference_preconditioner_nnz': int(direct_nnz), 'nnz_reduction_fraction': 1-nnz/direct_nnz,
                'outer_iterations': iterations, 'newton_corrections': len(residuals),
                'iterations_per_correction': iterations/len(residuals),
                'iterations_by_step': [int(row['linear_iterations']) for row in reports],
                'corrections_by_step': [int(row['linear_completed']) for row in reports],
                'inexact_linear_solves': inexact, 'recycle_projections': recycle,
                'recycle_vectors_max': recycle_vectors, 'accepted_steps': 3,
                'final_field_max_difference': final_difference,
                'trajectory_field_max_difference': trajectory_difference,
                'final_field_max_difference_by_field': per_field,
                'history_max_difference': history_difference, 'ghost_max_difference': ghost_difference,
                'max_true_residual_gate_ratio': max(ratios),
                'linear_gate': 'requested_atol + requested_rtol*rhs with 64eps roundoff factor' if mode == 'mono_inexact' else '1e-12 + 1e-10*rhs',
                'max_final_field_gate_ratio': final_gate_ratio,
                'verified_artifact_count': len(saved['artifacts']), 'log_sha256': sha(log_path),
            })
    assert len(result['runs']) == 15
    result['summary'] = {
        'audited_runs': len(result['runs']), 'accepted_steps': sum(row['accepted_steps'] for row in result['runs']),
        'true_residual_records': sum(row['newton_corrections'] for row in result['runs']),
        'max_final_field_difference': max(row['final_field_max_difference'] for row in result['runs']),
        'max_trajectory_field_difference': max(row['trajectory_field_max_difference'] for row in result['runs']),
        'max_history_difference': max(row['history_max_difference'] for row in result['runs']),
        'max_ghost_difference': max(row['ghost_max_difference'] for row in result['runs']),
        'verified_artifacts': sum(row['verified_artifact_count'] for row in result['runs']),
        'qualifications': ['Small 307/350-DoF physical equivalence cases, not a mesh-independence or scaling result',
                           'Different inexact tolerance is used only for intermediate linear corrections; original final field/trajectory tolerances are unchanged',
                           'Original campaign remains failed because 9 action-telemetry records are absent; no status has been rewritten'],
    }
    OUT.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps(result['summary'], indent=2))
    for row in result['runs']:
        print(row['case'], row['mode'], 'nnz', row['preconditioner_nnz'],
              'iterations', row['outer_iterations'], '/', row['newton_corrections'],
              'final_diff', row['final_field_max_difference'])


if __name__ == '__main__':
    main()
