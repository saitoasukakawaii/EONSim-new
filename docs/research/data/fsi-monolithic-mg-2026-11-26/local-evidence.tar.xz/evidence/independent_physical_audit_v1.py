#!/usr/bin/env python3
"""Independent stdlib audit of raw physical output, without project test helpers.
Receipts discover campaigns and supply hashes to verify, never numerical truth.
"""
import argparse,collections,csv,hashlib,json,math,pathlib,re,subprocess,sys,xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parents[3]
FIELD_LIMIT=2e-9
MANIFEST={}
COUNT=collections.Counter()

def need(ok,what):
    if not ok: raise AssertionError(what)
    COUNT['assertions']+=1

def raw(path):
    path=pathlib.Path(path).resolve(); b=path.read_bytes()
    MANIFEST[str(path)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
    return b

def load(path): return json.loads(raw(path))
def records(text,label):
    return [dict(re.findall(r'([\w]+)=([^\s]+)',line[len(label):]))
            for line in text.splitlines() if line.startswith(label)]
def csvrows(path):
    text=raw(path).decode(); result=[]
    for row in csv.DictReader(text.splitlines()):
        values={key:float(value) for key,value in row.items()}
        need(all(math.isfinite(x) for x in values.values()),('nonfinite CSV',str(path)))
        result.append(values)
    return result

def numeric_array(element,tuples):
    need(element is not None,'missing XML DataArray')
    need(element.get('format','ascii')=='ascii','independent parser intentionally supports observed ASCII VTU')
    n=int(element.get('NumberOfComponents','1'))
    integer=not element.get('type','Float64').startswith('Float')
    data=[int(x) if integer else float(x) for x in (element.text or '').split()]
    need(len(data)==tuples*n,('array shape',element.attrib,len(data),tuples))
    need(all(math.isfinite(x) for x in data),('nonfinite VTU',element.attrib))
    return {'components':n,'integer':integer,'type':element.get('type'),'values':[tuple(data[i:i+n]) for i in range(0,len(data),n)]}

def piece(path,rank,ranks):
    doc=ET.fromstring(raw(path)); need(doc.get('type')=='UnstructuredGrid',('not VTU',str(path)))
    parts=doc.findall('./UnstructuredGrid/Piece'); need(len(parts)==1,'expected one piece per observed VTU')
    p=parts[0]; np=int(p.get('NumberOfPoints')); nc=int(p.get('NumberOfCells'))
    point={a.get('Name'):numeric_array(a,np) for a in p.findall('./PointData/DataArray')}
    point['coordinates']=numeric_array(p.find('./Points/DataArray'),np)
    need({'mesh_node_id','owner','algebra_node_id'}<=point.keys(),('missing point identity',str(path)))
    ids=[x[0] for x in point['mesh_node_id']['values']]
    need(len(set(ids))==np,('duplicate local point IDs',str(path)))
    cells={a.get('Name'):a for a in p.findall('./Cells/DataArray')}
    offsets=numeric_array(cells['offsets'],nc)['values']; types=numeric_array(cells['types'],nc)['values']
    connectivity=[int(x) for x in (cells['connectivity'].text or '').split()]
    need(all(0<=x<np for x in connectivity),('invalid topology point index',str(path)))
    need((not offsets and not connectivity) or offsets[-1][0]==len(connectivity),('connectivity length',str(path)))
    tags={a.get('Name'):numeric_array(a,nc) for a in p.findall('./CellData/DataArray')}
    need({'physical_tag','mesh_element_id'}<=tags.keys(),('missing cell identity',str(path)))
    elements={};start=0
    for i,(offset,) in enumerate(offsets):
        need(offset>start,('non-increasing offset',str(path)))
        eid=tags['mesh_element_id']['values'][i][0]
        need(eid not in elements,('duplicate cell ID in piece',str(path),eid))
        elements[eid]=(types[i][0],tags['physical_tag']['values'][i][0],tuple(ids[j] for j in connectivity[start:offset]))
        start=offset
    points={}
    for i,nid in enumerate(ids):
        entry={name:a['values'][i] for name,a in point.items()}
        need(0<=entry['owner'][0]<ranks,('invalid point owner',str(path),nid))
        points[nid]=entry
    COUNT['vtu_files']+=1;COUNT['point_copies']+=np;COUNT['cells']+=nc
    return {'rank':rank,'points':points,'cells':elements,'schema':{name:(a['components'],a['type'],a['integer']) for name,a in point.items()}}

def dataset(path,ranks):
    path=pathlib.Path(path)
    if ranks==1:
        pieces=[piece(path,0,1)]
    else:
        path=path.with_suffix('.pvtu'); doc=ET.fromstring(raw(path))
        refs=doc.findall('./PUnstructuredGrid/Piece');need(len(refs)==ranks,('wrong piece count',str(path)))
        pieces=[]
        for ref in refs:
            source=path.parent/ref.get('Source');match=re.search(r'_rank(\d+)\.vtu$',source.name)
            need(match is not None,('missing rank suffix',str(source)))
            pieces.append(piece(source,int(match[1]),ranks))
        need({p['rank'] for p in pieces}==set(range(ranks)),('missing rank piece',str(path)))
    allcopies=collections.defaultdict(list); cells={}
    for p in pieces:
        need(p['schema']==pieces[0]['schema'],('rank schema differs',str(path)))
        for nid,entry in p['points'].items():allcopies[nid].append((p['rank'],entry))
        for eid,entry in p['cells'].items():
            need(eid not in cells,('duplicate owned cell across ranks',str(path),eid));cells[eid]=entry
    owners={};ghost_max=0.;ghosts=0
    for nid,entries in allcopies.items():
        owner_ids={entry['owner'][0] for _,entry in entries}
        need(len(owner_ids)==1,('owner disagreement',str(path),nid))
        owner=next(iter(owner_ids));selected=[entry for rank,entry in entries if rank==owner]
        need(len(selected)==1,('no unique owned point copy',str(path),nid,owner,[r for r,_ in entries]))
        owners[nid]=selected[0]
        for rank,entry in entries:
            if rank==owner:continue
            ghosts+=1
            for name,values in entry.items():
                ref=owners[nid][name]
                if pieces[0]['schema'][name][2]:need(values==ref,('ghost ID mismatch',str(path),nid,name))
                else:
                    difference=max(map(lambda z:abs(z[0]-z[1]),zip(values,ref)),default=0.)
                    need(difference<=1e-13,('ghost value mismatch',str(path),nid,name,difference));ghost_max=max(ghost_max,difference)
    COUNT['datasets']+=1;COUNT['ghost_copies']+=ghosts
    return {'points':owners,'cells':cells,'pieces':pieces,'schema':pieces[0]['schema'],'ghost_max':ghost_max}

def compare(a,b,label,limit=FIELD_LIMIT):
    need(a['schema']==b['schema'],('dataset schema differs',label))
    need(a['cells']==b['cells'],('global cell IDs/tags/oriented topology differ',label))
    need(a['points'].keys()==b['points'].keys(),('global node identity differs',label))
    maxima=collections.defaultdict(float)
    for nid,point in a['points'].items():
        for name,values in point.items():
            ref=b['points'][nid][name]
            if a['schema'][name][2]:need(values==ref,('integer identity differs',label,nid,name))
            else:
                difference=max((abs(v-w) for v,w in zip(values,ref)),default=0.)
                maxima[name]=max(maxima[name],difference)
                need(difference<=limit,('field/coordinate mismatch',label,nid,name,difference,limit))
    return dict(maxima)

def compare_piece_files(path,reference):
    """Boundary pieces may omit the owner-rank copy; compare every stored copy."""
    match=re.search(r'_rank(\d+)',path.stem);rank=int(match[1]) if match else 0
    a=piece(path,rank,16);b=piece(reference,rank,16)
    need(a['schema']==b['schema'] and a['cells']==b['cells'] and a['points'].keys()==b['points'].keys(),('boundary topology/identity',str(path)))
    maxima=collections.defaultdict(float)
    for nid,point in a['points'].items():
        for name,values in point.items():
            ref=b['points'][nid][name]
            if a['schema'][name][2]:need(values==ref,('boundary metadata',str(path),name))
            else:
                diff=max((abs(x-y) for x,y in zip(values,ref)),default=0.)
                need(diff<=FIELD_LIMIT,('boundary field',str(path),name,diff));maxima[name]=max(maxima[name],diff)
    COUNT['boundary_piece_comparisons']+=1
    return dict(maxima)

def run_audit(directory,record,ranks,reference,config):
    mode=record['mode'];text=raw(directory/(mode+'.log')).decode(errors='replace')
    reports=records(text,'solver_report ');linear=records(text,'linear_residual ')
    steps=records(text,'fsi_step=')
    # fsi_step itself belongs in the parsed mapping, unlike other record labels.
    steps=[dict(re.findall(r'(\w+)=([^\s]+)',line)) for line in text.splitlines() if line.startswith('fsi_step=')]
    if record['status']=='failed':
        need('status=success' not in text and ('status=failed' in text or 'fatal' in text.lower()),('unsubstantiated failed run',str(directory),mode))
        count=len(steps);need(not reports or count<=len(reports),('failed evidence ordering',mode))
        COUNT['failed_runs']+=1
        return {'mode':mode,'status':'retained_failure','accepted_steps':count,'observed_residuals':len(linear),'failure_marker':'patch size cap' if 'exceeds the maximum size' in text else 'see raw log'}
    trace=csvrows(directory/(mode+'.csv')); cfg=load(directory/(mode+'.json'))
    expected_steps=int(cfg['fsi']['steps']);need(len(trace)==expected_steps==len(reports)==len(steps),('missing accepted time/solver evidence',str(directory),mode))
    need(text.count('status=success')==1 and 'status=failed' not in text and 'step_retry=' not in text and 'linear_residual_unavailable' not in text,('unaccepted trajectory',str(directory),mode))
    need(sum(int(r['linear_started']) for r in reports)==sum(int(r['linear_completed']) for r in reports)==len(linear),('unobserved correction',mode))
    ratios=[]
    for row in linear:
        n,b=float(row['norm']),float(row['rhs_norm']);need(math.isfinite(n) and math.isfinite(b) and min(n,b)>=0,('invalid true residual',mode))
        ratio=n/(1e-12+1e-10*b);need(ratio<=1,('original true residual gate',mode,ratio));ratios.append(ratio)
    need(linear,'no observed true residual')
    method='preonly' if mode=='direct' else 'pipefgmres' if mode=='mono_pipe' else 'fgmres'
    for row in reports:
        need(int(row['ranks'])==ranks and row['ksp']==method and int(row['snes_reason'])>0 and int(row['ksp_reason'])>0,('invalid convergence',mode))
    for row in records(text,'field_residual '):
        need(int(row['accepted'])==1 and float(row['rms'])<=float(row['limit']) and float(row['constraint_max'])<=float(row['constraint_limit']),('physical field gate',mode,row))
    aliases={'fsi_step':'step','position':'endpoint_position','velocity':'endpoint_velocity','stage_fluid_force':'evaluation_fluid_force','stage_body_balance':'evaluation_body_balance','stage_interface_power':'evaluation_interface_power','stage_body_power':'evaluation_body_power','stage_power_balance':'evaluation_power_balance'}
    schedule=cfg.get('time_control',{}).get('step_sizes',[cfg['fsi']['dt']]*expected_steps);time=0.;history_max=0.
    need(len(schedule)==expected_steps,('input time grid length',mode))
    for index,(row,line) in enumerate(zip(trace,steps)):
        time=math.fsum(schedule[:index+1]);need(row['step']==index+1 and abs(row['time']-time)<=1e-13 and abs(row['accepted_dt']-schedule[index])<=1e-13,('accepted time grid mismatch',mode,index))
        for key,value in line.items():
            target=aliases.get(key,key)
            if target in row:need(abs(float(value)-row[target])<=1e-13*(1+abs(row[target])),('log/CSV mismatch',mode,index,key))
        need(all(row[k]>0 for k in row if k.endswith('_j')),('inverted accepted geometry',mode,index))
        need(abs(row['evaluation_body_balance'])<2e-9 and abs(row['evaluation_power_balance'])<2e-9,('balance gate',mode,index))
        if reference is not None:
            prior=reference['trace'][index];need(row.keys()==prior.keys(),('history columns differ',mode))
            for key,value in row.items():
                if key=='snes_iterations':continue
                d=abs(value-prior[key]);need(d<=FIELD_LIMIT,('history physical mismatch',mode,index,key,d));history_max=max(history_max,d)
    snapshots={};field_max=collections.defaultdict(float)
    for suffix in ('','_solid'):
        pvd=ET.fromstring(raw(directory/(mode+suffix+'.pvd')));entries=pvd.findall('./Collection/DataSet')
        need(len(entries)==expected_steps,('saved PVD count',mode,suffix))
        for i,entry in enumerate(entries):
            need(abs(float(entry.get('timestep'))-trace[i]['time'])<=1e-13,('PVD time mismatch',mode,suffix,i))
            expected=f'{mode}_step{i+1}{suffix}'+('.vtu' if ranks==1 else '.pvtu')
            need(entry.get('file')==expected,('PVD source mismatch',mode,suffix))
            state=dataset(directory/expected,ranks);snapshots[(suffix,i+1)]=state
            if reference is not None:
                for k,v in compare(state,reference['snapshots'][(suffix,i+1)],(mode,suffix,i+1)).items():field_max[k]=max(field_max[k],v)
        final=dataset(directory/(mode+suffix+'.vtu'),ranks)
        for k,v in compare(final,snapshots[(suffix,expected_steps)],(mode,suffix,'final-copy'),limit=0.).items():field_max[k]=max(field_max[k],v)
    if reference is not None:
        for path in directory.glob(mode+'*.vtu'):
            tail=path.name[len(mode):]
            # Only exact mode + recognized output suffix, not later mode names.
            if not (tail.startswith('_step') or tail.startswith('_solid') or tail.startswith('_boundary') or tail.startswith('_rank') or tail=='.vtu'):continue
            if '_boundary' not in tail:continue
            other=directory/('direct'+tail);need(other.is_file(),('missing direct boundary',str(path)))
            for k,v in compare_piece_files(path,other).items():field_max['boundary_'+k]=max(field_max['boundary_'+k],v)
    circuit=0.
    if 'rcr_tag' in trace[0]:
        faces=csvrows(directory/(mode+'_pressure_faces.csv'));model=cfg['fsi']['domains']['rcr_outlet'];tag=model['tag']
        faces=[row for row in faces if row['tag']==tag];need(len(faces)==expected_steps,('RCR face count',mode))
        for row,face in zip(trace,faces):
            need(row['step']==face['step'] and row['time']==face['time'] and row['rcr_tag']==tag,('RCR times/tag',mode))
            for phase in ('stage','endpoint'):
                q=face[phase+'_outward_flow'];pb=face[phase+'_prescribed_pressure'];pc=row[phase+'_capacitor_pressure']
                defects=[pb-pc-model['proximal_resistance']*q,face[phase+'_pressure_power']+q*pb,row[phase+'_rcr_flow']-q,row[phase+'_rcr_pressure']-pb]
                if phase=='stage':
                    need('distal_pressure_time' not in model,'this audit must implement time-varying distal pressure if used')
                    defects.append(model['compliance']*row['stage_capacitor_rate']-q+(pc-model['distal_pressure'])/model['distal_resistance'])
                circuit=max(circuit,*map(abs,defects))
        need(circuit<2e-10,('independent RCR equations',mode,circuit))
    COUNT['passed_runs']+=1;COUNT['accepted_steps']+=len(trace);COUNT['observed_residuals']+=len(linear);COUNT['saved_volume_states']+=len(snapshots)
    summary={'mode':mode,'status':'audited_pass','accepted_steps':len(trace),'observed_residuals':len(linear),'outer_iterations':sum(int(r['linear_iterations']) for r in reports),'max_true_residual_gate_ratio':max(ratios),'field_max_abs_difference':max(field_max.values(),default=0.),'fields':dict(field_max),'history_max_abs_difference':history_max,'rcr_equation_max_abs_defect':circuit,'dofs':int(reports[-1]['dofs']),'times':[r['time'] for r in trace]}
    # Cross-check receipt numbers only after deriving raw evidence independently.
    for key,actual in [('accepted_steps',len(trace)),('corrections',len(linear)),('outer_iterations',summary['outer_iterations']),('dofs',summary['dofs'])]:need(record[key]==actual,('receipt aggregate differs',mode,key))
    need(abs(record['max_true_residual_ratio']-max(ratios))<1e-15,('receipt residual ratio differs',mode))
    return summary,{'trace':trace,'snapshots':snapshots}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('receipts',nargs='+');ap.add_argument('--output',required=True);args=ap.parse_args()
    audit={'status':'running','method':'stdlib raw XML/CSV/log/hash reread, no imported project audit helpers','limitations':['J, b and Newton increments were not saved; logged original-operator true residuals are re-gated, not recomputed by offline J multiplication.','Old overwritten executables cannot be rehashed; receipt/build source hashes are pinned and source driver blob hashes checked.'],'campaigns':[]}
    try:
        current_exe=ROOT/'build/cloud-3.23.7-release/eonsim';current_binary_hash=hashlib.sha256(current_exe.read_bytes()).hexdigest()
        audit['current_executable_sha256']=current_binary_hash
        for item in args.receipts:
            path=pathlib.Path(item).resolve();receipt=load(path);source=receipt['build_source'];git_source=subprocess.check_output(['git','rev-parse',source],cwd=ROOT,text=True).strip()
            need(source==git_source,('source commit unresolved',source))
            blob=subprocess.check_output(['git','show',source+':tests/verify_fsi_multigrid.py'],cwd=ROOT)
            need(hashlib.sha256(blob).hexdigest()==receipt['driver_sha256'],('driver differs from claimed source',source))
            campaign={'receipt':str(path),'receipt_sha256':MANIFEST[str(path)]['sha256'],'source':source,'executable_sha256':receipt['executable_sha256'],'executable_independently_rehashed':receipt['executable_sha256']==current_binary_hash,'driver_sha256':receipt['driver_sha256'],'receipt_status':receipt['status'],'cases':[]};audit['campaigns'].append(campaign)
            for cmd in receipt['commands']:
                b=raw(cmd['log']);need(hashlib.sha256(b).hexdigest()==cmd['log_sha256'],('command log hash mismatch',cmd['log']))
                COUNT['command_hash_checks']+=1
            for case in receipt['cases']:
                c={'name':case['name'],'ranks':case['ranks'],'runs':[]};campaign['cases'].append(c);reference=None
                for record in case['runs']:
                    for artifact in record.get('artifacts',[]):
                        b=raw(artifact['path']);need(len(b)==artifact['bytes'] and hashlib.sha256(b).hexdigest()==artifact['sha256'],('artifact hash/size mismatch',artifact['path']));COUNT['artifact_hash_checks']+=1
                    result=run_audit(path.parent/case['name'],record,case['ranks'],reference,case['configuration'])
                    if isinstance(result,tuple):
                        summary,fields=result
                        if record['mode']=='direct':reference=fields
                        c['runs'].append(summary)
                    else:c['runs'].append(result)
            failures=[r for c in campaign['cases'] for r in c['runs'] if r['status']=='retained_failure']
            need((receipt['status']=='failed')==bool(failures) and len(receipt['failures'])==len(failures),('campaign failure accounting',str(path)))
        audit['status']='passed'
    except Exception as e:
        audit['status']='failed';audit['error']=repr(e)
    audit['counts']=dict(COUNT);audit['artifacts']=MANIFEST
    successful=[r for c in audit['campaigns'] for s in c['cases'] for r in s['runs'] if r['status']=='audited_pass']
    if successful:audit['maxima']={k:max(r[k] for r in successful) for k in ('max_true_residual_gate_ratio','field_max_abs_difference','history_max_abs_difference','rcr_equation_max_abs_defect')}
    output=pathlib.Path(args.output);output.write_text(json.dumps(audit,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:audit[k] for k in ('status','counts','maxima','error') if k in audit},indent=2))
    print('audit_json',output.resolve());print('audit_sha256',hashlib.sha256(output.read_bytes()).hexdigest())
    return 0 if audit['status']=='passed' else 1
if __name__=='__main__':sys.exit(main())
