#!/usr/bin/env python3
"""Read saved logs/VTU only. No solver invocation or project test-helper import."""
import collections
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUILD = HERE.parent
spec = importlib.util.spec_from_file_location('independent_xml_parser', HERE / 'independent_physical_audit.py')
xml = importlib.util.module_from_spec(spec)
spec.loader.exec_module(xml)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def need(ok, reason):
    if not ok:
        raise AssertionError(reason)


def mg_memory(text, ranks):
    headers = xml.records(text, 'pc_monolithic_mg ')
    if not headers:
        return None
    need(len(headers) == 1, 'cost extractor expects observed fixed hierarchy')
    levels = int(headers[0]['levels'])
    transfer = xml.records(text, 'pc_monolithic_mg_level ')
    need(len(transfer) == levels - 1, 'missing transfer metadata')
    metadata = xml.records(text, 'pc_monolithic_mg_smoother ')
    need(len(metadata) == ranks * (levels - 1), 'missing smoother metadata')
    by_key = {(int(r['level']), int(r['rank'])): r for r in metadata}
    need(set(by_key) == {(l, r) for l in range(levels - 1) for r in range(ranks)}, 'smoother rank/level coverage')
    patch_levels = [l for l in range(levels - 1) if any(int(by_key[l, r]['patches']) for r in range(ranks))]
    factors = xml.records(text, 'interface_patch_pc ')
    need(all(r['level'] == '1' for r in factors), 'unexpected nonlevel patch context')
    initial = {}; last = {}; cycles = []
    if patch_levels:
        stride = ranks * len(patch_levels)
        need(len(factors) >= stride and len(factors) % stride == 0, 'incomplete factor refresh records')
        for start in range(0, len(factors), stride):
            cycle = {}
            for index, level in enumerate(patch_levels):
                group = factors[start + index * ranks:start + (index + 1) * ranks]
                need({int(r['rank']) for r in group} == set(range(ranks)), 'factor group rank coverage')
                for row in group:
                    rank = int(row['rank']); key = (level, rank)
                    need(int(row['patches']) == int(by_key[key]['patches']), 'factor group cannot map to smoother level')
                    if 'largest_patch' in by_key[key]:
                        need(int(row['largest']) == int(by_key[key]['largest_patch']), 'largest patch changed')
                    cycle[key] = row
            need(len({int(r['rebuilds']) for r in cycle.values()}) == 1, 'mixed factor refresh generation')
            if not initial:
                initial = cycle
            cycles.append(cycle); last = cycle
    else:
        need(not factors, 'unexpected factors for patchless smoother')
    summaries = []
    for level in range(levels - 1):
        rows = [by_key[level, rank] for rank in range(ranks)]
        factor_rows = [last[level, rank] for rank in range(ranks)] if level in patch_levels else []
        summary = {
            'level': level, 'rows': int(transfer[level]['rows']),
            'coarse_rows': int(transfer[level]['coarse_rows']),
            'spectral_modes': int(transfer[level]['spectral_modes']),
            'patches_global': sum(int(r['patches']) for r in rows),
            'largest_patch': max((int(r['largest']) for r in factor_rows), default=0),
            'factor_bytes_global_initial': sum(int(initial[level, rank]['factor_bytes']) for rank in range(ranks)) if factor_rows else 0,
            'factor_bytes_global_last': sum(int(r['factor_bytes']) for r in factor_rows),
            'factor_bytes_global_max_observed': max((sum(int(c[level, rank]['factor_bytes']) for rank in range(ranks)) for c in cycles), default=0) if factor_rows else 0,
            'interface_patches_global': sum(int(r['interface_patches']) for r in rows),
            'fp32_patches_global_last': sum(int(r['fp32']) for r in factor_rows),
            'fp64_patches_global_last': sum(int(r['fp64']) for r in factor_rows),
            'numeric_factorizations_global_last': sum(int(r['factorizations']) for r in factor_rows),
            'cached_factorizations_global_last': sum(int(r['cached']) for r in factor_rows),
            'factor_batches_global_last': sum(int(r['batches']) for r in factor_rows),
            'setup_fallbacks_global_last': sum(int(r['setup_fallbacks']) for r in factor_rows),
            'apply_fallbacks_global_last': sum(int(r['apply_fallbacks']) for r in factor_rows),
        }
        if all('patch_overlap' in r for r in rows):
            overlaps = {int(r['patch_overlap']) for r in rows}
            need(len(overlaps) == 1, 'rank overlap mismatch')
            summary['patch_overlap'] = next(iter(overlaps))
            summary['patch_rows_global'] = sum(int(r['patch_rows']) for r in rows)
            summary['covered_owned_rows_global'] = sum(int(r['covered_owned_rows']) for r in rows)
            if factor_rows:
                need(summary['covered_owned_rows_global'] == summary['rows'], 'smoother omitted owned rows')
                if level > 0 and summary['patch_overlap'] == 0:
                    need(summary['patch_rows_global'] == summary['rows'], 'coarse mixed blocks do not exactly cover rows')
        summaries.append(summary)
    stats = xml.records(text, 'monolithic_mg_stats ')
    need(len(stats) % ranks == 0 and len(stats) >= ranks, 'missing runtime MG stats')
    final_stats = stats[-ranks:]
    need({int(r['rank']) for r in final_stats} == set(range(ranks)), 'final MG stats rank coverage')
    return {
        'levels': levels, 'coarse_processes': int(headers[0]['coarse_processes']),
        'factor_refresh_generations_observed': len(cycles), 'smoother_levels': summaries,
        'coarse_smoother_largest_patch': max((r['largest_patch'] for r in summaries[1:]), default=0),
        'coarse_smoother_factor_bytes_global_last': sum(r['factor_bytes_global_last'] for r in summaries[1:]),
        'all_smoother_factor_bytes_global_last': sum(r['factor_bytes_global_last'] for r in summaries),
        'all_smoother_factor_bytes_global_max_observed': max((sum(int(r['factor_bytes']) for r in c.values()) for c in cycles), default=0),
        'fp32_csr_value_bytes_global_last': sum(int(r['fp32_value_bytes']) for r in final_stats),
        'fp32_csr_value_bytes_by_rank': {r['rank']: int(r['fp32_value_bytes']) for r in final_stats},
    }


def main():
    result = {
        'status': 'running', 'source_method': 'original solver_report, interface_patch_pc, hierarchy/runtime logs; raw VTU owner/ghost reread',
        'cautions': [
            'One observation per case/mode in each phase; campaigns overlap other validation work. Times are measured observations, not controlled speedup benchmarks.',
            'solver_report time fields are summed over accepted steps. Reported peak RSS is max over steps of the maximum rank; aggregate peak RSS is reported separately. Phase times need not form an additive partition.',
            'factor_bytes counts only local dense LU coefficient arrays. FP32 CSR value bytes counts only sparse float coefficient arrays for J/P; FP64 setup/Galerkin matrices, pivots, indices, vectors, communication buffers and coarse direct factors remain outside these byte counts.',
            'interface_patch_pc level=1 is the pure-level-mode boolean, not hierarchy depth. Factor depth is reconstructed from synchronized rank groups in construction/refresh order, checked against actual per-level patch metadata.',
            'Prior failed runs have no successful timing comparison; their failure logs remain retained.',
        ],
        'runs': [], 'paired_previous_phase': [], 'owner_ghost_by_phase': {},
    }
    index = {}; configurations = {}; meshes = {}
    final_audit = json.loads((HERE / 'independent-physical-final.json').read_text())
    cumulative_audit = json.loads((HERE / 'independent-physical-cumulative.json').read_text())
    result['audit_references'] = {name: digest(HERE / name) for name in ['independent-physical-final.json', 'independent-physical-cumulative.json', 'independent_physical_audit.py', 'independent_physical_audit_v1.py']}
    result['final_counts'] = final_audit['counts']; result['cumulative_counts'] = cumulative_audit['counts']
    result['final_maxima'] = dict(final_audit['maxima']); result['cumulative_maxima'] = dict(cumulative_audit['maxima'])
    for receipt_path in sorted(BUILD.glob('physical-0[1-5]/*/results.json')):
        receipt = json.loads(xml.raw(receipt_path)); phase = receipt_path.parts[-3]
        commands = {str(Path(c['log']).resolve()): c for c in receipt['commands']}
        phase_ghost_max = 0.0; before_copies = xml.COUNT['ghost_copies']; before_sets = xml.COUNT['datasets']
        for case in receipt['cases']:
            directory = receipt_path.parent / case['name']; ranks = case['ranks']
            for saved in case['runs']:
                mode = saved['mode']; log = directory / (mode + '.log')
                text = xml.raw(log).decode(errors='replace'); reports = xml.records(text, 'solver_report ')
                run = {'phase': phase, 'source': receipt['build_source'], 'case': case['name'], 'ranks': ranks, 'mode': mode, 'status': saved['status'], 'log': str(log.resolve()), 'log_sha256': digest(log)}
                result['runs'].append(run); index[(phase, case['name'], mode)] = run
                cfg = json.loads(xml.raw(directory / (mode + '.json'))); cfg.pop('output', None)
                configurations[(phase, case['name'], mode)] = cfg
                meshes[(phase, case['name'], mode)] = {k: digest(directory / k) for k in ['fluid.msh', 'solid.msh']}
                if saved['status'] == 'failed':
                    need('status=success' not in text and 'exceeds the maximum size' in text, 'failed coarse-patch provenance')
                    run['failure'] = 'explicit coarse patch size rejection before accepted trajectory'
                    continue
                need(len(reports) == saved['accepted_steps'], 'accepted report count')
                command = commands[str(log.resolve())]
                need(command['log_sha256'] == run['log_sha256'], 'command log hash')
                run['command_wall_seconds'] = command['wall_seconds']
                run.update({'dofs': int(reports[-1]['dofs']), 'ksp': reports[-1]['ksp'], 'accepted_steps': len(reports), 'corrections': sum(int(r['linear_completed']) for r in reports), 'outer_iterations': sum(int(r['linear_iterations']) for r in reports)})
                need(run['outer_iterations'] == saved['outer_iterations'], 'outer iteration aggregate')
                run['iterations_each_step'] = [int(r['linear_iterations']) for r in reports]
                for name in ['solve_seconds', 'linear_seconds', 'assembly_seconds', 'schur_setup_seconds', 'setup_seconds', 'matrix_free_seconds_rank0']:
                    values = [float(r.get(name, 0)) for r in reports]
                    need(all(math.isfinite(v) and v >= 0 for v in values), 'invalid reported time')
                    run[name] = math.fsum(values)
                for name in ['jacobian_assemblies', 'jacobian_callbacks', 'matrix_free_actions', 'assembled_pc_reuses']:
                    run[name] = sum(int(r.get(name, 0)) for r in reports)
                for name in ['peak_rss_max_bytes', 'peak_rss_sum_bytes']:
                    run[name] = max(float(r[name]) for r in reports)
                run['mg'] = mg_memory(text, ranks)
                ghost_max = 0.0
                for suffix in ['', '_solid']:
                    for step in list(range(1, len(reports) + 1)) + [None]:
                        stem = mode + (('_step' + str(step)) if step is not None else '') + suffix
                        state = xml.dataset(directory / (stem + '.vtu'), ranks)
                        ghost_max = max(ghost_max, state['ghost_max'])
                run['owner_ghost_max_abs_difference'] = ghost_max
                phase_ghost_max = max(phase_ghost_max, ghost_max)
        result['owner_ghost_by_phase'][phase] = {'max_abs_difference': phase_ghost_max, 'checked_ghost_copies': xml.COUNT['ghost_copies'] - before_copies, 'volume_datasets': xml.COUNT['datasets'] - before_sets}
    for current, previous in [('physical-04', 'physical-02'), ('physical-05', 'physical-03')]:
        for key, run in index.items():
            if key[0] != current:
                continue
            before_key = (previous, key[1], key[2]); prior = index.get(before_key)
            if prior is None:
                result['paired_previous_phase'].append({'current': list(key), 'previous': list(before_key), 'status': 'no prior mode'})
                continue
            need(configurations[key] == configurations[before_key] and meshes[key] == meshes[before_key], 'paired physical configuration or input mesh differs')
            pair = {'current': list(key), 'previous': list(before_key), 'same_physical_configuration_and_mesh_hashes': True, 'status': 'paired successful observations' if prior['status'] == run['status'] == 'passed' else 'retained prior failure, no timing ratio'}
            if prior['status'] == run['status'] == 'passed':
                pair['observations'] = {name: {'previous': prior[name], 'current': run[name]} for name in ['outer_iterations', 'solve_seconds', 'linear_seconds', 'assembly_seconds', 'schur_setup_seconds', 'peak_rss_max_bytes', 'jacobian_assemblies', 'matrix_free_actions', 'assembled_pc_reuses']}
            result['paired_previous_phase'].append(pair)
    result['final_maxima']['owner_ghost_max_abs_difference'] = max(r['max_abs_difference'] for p, r in result['owner_ghost_by_phase'].items() if p in ['physical-04', 'physical-05'])
    result['cumulative_maxima']['owner_ghost_max_abs_difference'] = max(r['max_abs_difference'] for r in result['owner_ghost_by_phase'].values())
    result['status'] = 'passed'
    result['artifacts'] = xml.MANIFEST
    output = HERE / 'independent-costs-and-ghosts.json'
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    columns = ['phase', 'case', 'ranks', 'mode', 'status', 'dofs', 'outer_iterations', 'corrections', 'solve_seconds', 'linear_seconds', 'assembly_seconds', 'schur_setup_seconds', 'peak_rss_max_bytes', 'jacobian_assemblies', 'jacobian_callbacks', 'matrix_free_actions', 'assembled_pc_reuses', 'coarse_smoother_largest_patch', 'coarse_smoother_factor_bytes_global_last', 'all_smoother_factor_bytes_global_last', 'fp32_csr_value_bytes_global_last']
    with (HERE / 'independent-measured-costs.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction='ignore'); writer.writeheader()
        for run in result['runs']:
            row = dict(run); row.update({k: v for k, v in (run.get('mg') or {}).items() if k in columns}); writer.writerow(row)
    print(json.dumps({k: result[k] for k in ['status', 'final_maxima', 'cumulative_maxima', 'owner_ghost_by_phase']}, indent=2))
    print('json_sha256', digest(output)); print('csv_sha256', digest(HERE / 'independent-measured-costs.csv'))


if __name__ == '__main__':
    main()
