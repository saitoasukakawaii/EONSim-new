"""Read-only replay of preserved FSI logs, history, owner/ghost fields and hashes."""
from pathlib import Path
import csv, hashlib, json, math, re, xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
RAW=HERE/'raw'
report=json.loads((RAW/'results.json').read_text())
identity=json.loads((HERE/'build-identity.json').read_text())
assert report['element_threads_per_rank']==2 and report['overlap_comparison'] is True
assert report['executable_sha256']==identity['binaries']['eonsim']
xml=ET.parse(HERE/'focused-junit.xml').getroot()
assert xml.attrib['tests']=='4' and xml.attrib['failures']=='0' and xml.attrib['skipped']=='0'
assert {t.attrib['name'] for t in xml.findall('testcase')}=={'pc_plan_mpi1','pc_plan_mpi2','pc_plan_mpi4','fsi_coo_verification'}
assert '37 solves' in xml.find("testcase[@name='fsi_coo_verification']/system-out").text

def lines(text, prefix):
    return [dict(re.findall(r'(\w+)=([^\s]+)',s)) for s in text.splitlines() if s.startswith(prefix)]

def fieldset(stem,ranks,elastic):
    answer={}
    for solid in ((False,True) if elastic else (False,)):
        pieces=[];support=set();owners={}
        for rank in range(ranks):
            suffix=('_solid' if solid else '')+(f'_rank{rank}' if ranks>1 else '')+'.vtu'
            root=ET.parse(stem.with_name(stem.name+suffix))
            arrays={a.attrib['Name']:(int(a.attrib.get('NumberOfComponents',1)),list(map(float,a.text.split()))) for a in root.findall('.//PointData/DataArray')}
            xyz=list(map(float,root.find('.//Points/DataArray').text.split()))
            arrays['coordinates']=(3,xyz)
            ids=arrays['mesh_node_id'][1]
            used=list(map(int,root.find('.//Cells/DataArray[@Name="connectivity"]').text.split()))
            assert all(0<=i<len(ids) for i in used)
            support.update(int(ids[i]) for i in used)
            for width,values in arrays.values():
                assert len(values)==width*len(ids) and all(map(math.isfinite,values))
            pieces.append(arrays)
            for i,node in enumerate(ids):
                if int(arrays['owner'][1][i])==rank:
                    assert int(node) not in owners
                    owners[int(node)]=(arrays,i)
        assert support<=owners.keys()
        for node in support:
            arrays,i=owners[node]
            for name,(width,values) in arrays.items():
                if name not in ('mesh_node_id','algebra_node_id','owner'):
                    answer[solid,node,name]=values[i*width:(i+1)*width]
        for arrays in pieces:
            for i,node in enumerate(arrays['mesh_node_id'][1]):
                if int(node) not in support: continue
                for name,(width,values) in arrays.items():
                    if name not in ('mesh_node_id','algebra_node_id','owner'):
                        assert max(abs(x-y) for x,y in zip(answer[solid,int(node),name],values[i*width:(i+1)*width]))<2e-9
    assert answer
    return answer

def history(folder,label):
    paths=[folder/(label+'.csv')]
    if not paths[0].exists():
        paths=[p for p in folder.glob(label+'_restart*.csv') if p.stem[len(label+'_restart'):].isdigit()]
    assert len(paths)==1
    with paths[0].open() as stream:
        rows=[{k:float(v) for k,v in r.items()} for r in csv.DictReader(stream)]
    for row in rows:
        assert all(map(math.isfinite,row.values()))
        assert abs(row['evaluation_body_balance'])<2e-9 and abs(row['evaluation_power_balance'])<2e-9
        assert min(v for k,v in row.items() if k.endswith('_j'))>0
    return rows

runs=[];by_label={};data={};commands=[]
for record in report['commands']:
    label=record['label'];argv=record['command']
    folder=RAW/Path(argv[argv.index('-case')+1]).parent.name
    log=folder/record['log'];text=log.read_text()
    cfg=json.loads((folder/(label+'.json')).read_text())
    steps=lines(text,'fsi_step=');retries=lines(text,'step_retry=');fail=record['expected_failure']
    row=dict(label=label,ranks=record['ranks'],threads=record['element_threads_per_rank'],overlap=not record['reference'],expected_failure=fail,
             success_markers=text.count('status=success'),accepted_steps=len(steps),rejections=len(retries),retry_records=retries,
             injected_batch_records=lines(text,'fsi_batch_failure '),log=str(log.relative_to(HERE)),
             null_bytes_in_raw_log=log.read_bytes().count(b'\0'))
    if fail:
        assert row['success_markers']==0 and not steps and fail in text
        assert not list(folder.glob(label+'*.vtu'))
    else:
        assert row['success_markers']==1 and steps
        observations=lines(text,'nonlinear_communication ')
        assert len(observations)==len(steps)
        assert all(int(x['overlap'])==int(not record['reference']) for x in observations)
        actual=history(folder,label)
        assert len(actual)==len(steps)
        for actual_row,step in zip(actual,steps):
            assert actual_row['time']==float(step['time']) and actual_row['accepted_dt']==float(step['accepted_dt'])
        data[label]=(fieldset(folder/label,record['ranks'],cfg['fsi'].get('body','rigid')=='elastic'),actual)
        row['snes_iterations']=sum(int(x['snes_iterations']) for x in steps)
        row['accepted_dt']=[r['accepted_dt'] for r in actual]
    runs.append(row);by_label[label]=row
    commands.append(dict(label=label,argv=argv,log=str(log.relative_to(HERE)),expected_failure=fail))
assert len(runs)==37 and sum(not r['expected_failure'] for r in runs)==34

comparisons=[]
def compare(label,expected,actual):
    left,lh=expected;right,rh=actual
    assert left.keys()==right.keys() and lh and len(lh)==len(rh)
    field=max(abs(x-y) for k in left for x,y in zip(left[k],right[k]))
    difference=max(abs(a[k]-b[k])/(1+max(abs(a[k]),abs(b[k]))) for a,b in zip(lh,rh) for k in a)
    assert field<2e-9 and difference<2e-9
    comparisons.append(dict(label=label,field_max_abs_difference=field,history_max_normalized_difference=difference))

for group in ('rigid','shared-elastic','dual-neo','moving-port','fixed-port'):
    entries=report[group];base=data[entries[0]['label']]
    for entry in entries[1:]: compare(entry['label'],base,data[entry['label']])
for label in ('rigid-fd','rigid-fd-values'):
    compare(label,(fieldset(RAW/'rigid'/'rigid-r2-values_step1',2,False),data['rigid-r2-values'][1][:1]),data[label])
for label in ('restart-from-values','restart-from-coo'):
    compare(label,(data['moving-r2-values'][0],data['moving-r2-values'][1][1:]),data[label])
for label in ('batch-worker','batch-insert'):
    compare(label,data['batch-replay'],data[label])
    row=by_label[label]
    assert row['rejections']==1 and row['accepted_dt']==[.004] and row['threads']==2 and row['overlap']
    fault=row['injected_batch_records'][0]
    assert fault['team']=='2' and fault['batch']=='1'
    assert fault['thread']==('1' if label=='batch-worker' else '0')
compare('retry-coo',(data['retry-values-replay'][0],data['retry-values-replay'][1][-1:]),data['retry-coo'])
retry=by_label['retry-coo']
assert retry['rejections']==3 and retry['accepted_dt']==[.0125] and retry['threads']==2 and retry['overlap']
assert [float(x['next_dt']) for x in retry['retry_records']]==[.05,.025,.0125]
for label in ('batch-worker_fatal','batch-insert_fatal'):
    assert by_label[label]['rejections']==0 and by_label[label]['threads']==2 and by_label[label]['overlap']
    assert by_label[label]['injected_batch_records'][0]['team']=='2'
unsupported=list((RAW/'moving-port').glob('unsupported-fluid-*.log'))
assert len(unsupported)==3
assert all('require the monolithic FSI problem' in p.read_text() and 'status=success' not in p.read_text() for p in unsupported)
manifest=json.loads((HERE/'raw-manifest.json').read_text())
for record in manifest['files']:
    p=HERE/record['path']
    assert p.stat().st_size==record['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256']
summary=dict(status='passed',source_commit=identity['source'],binary_sha256=report['executable_sha256'],solver_runs=len(runs),successful_solver_runs=34,
             expected_failed_solver_runs=3,expected_fatal_batch_runs=2,expected_retries_exhausted_runs=1,additional_expected_cli_rejections=3,
             accepted_steps=sum(r['accepted_steps'] for r in runs),successful_step_snes_iterations=sum(r.get('snes_iterations',0) for r in runs),
             observed_step_retry_records=sum(r['rejections'] for r in runs),successful_runs_with_recovery=[r['label'] for r in runs if r['rejections'] and not r['expected_failure']],
             actual_two_thread_overlap_successes=sum(r['threads']==2 and r['overlap'] and not r['expected_failure'] for r in runs),
             raw_files_verified=manifest['files_count'],raw_bytes=manifest['bytes'],independently_replayed_comparisons=len(comparisons),
             field_max_abs_difference=max(c['field_max_abs_difference'] for c in comparisons),history_max_normalized_difference=max(c['history_max_normalized_difference'] for c in comparisons),
             retry=by_label['retry-coo'],restart_labels=['restart-from-values','restart-from-coo'],
             evidence_limits=['This audit launched no solver, build or CTest.',
                              'Individual process exit codes are asserted by the successful original driver; its per-run JSON does not store numeric exit codes.',
                              'Checkpoint byte preservation before/after failed-coo was asserted by the original driver; this archive contains the final checkpoint, not separately saved before/after manifests.',
                              'Raw logs, including NUL bytes in the expected failed-coo diagnostic, were preserved unchanged.'])
(HERE/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(HERE/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
(HERE/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n')
(HERE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
