"""Replay the archived CI fatal log without importing or launching a solver."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
PARSER_COMMIT = '8e6c0137205fd4eb288137e03296d116e920488d'
PRODUCTION_COMMIT = '4c7edc6cc14219acfc97d39b9651c935a1c875ac'
CI_ROOT = ROOT / 'build/hpc-followup/ci-failed-raw/cloud-3.23.7-release'
RAW = CI_ROOT / 'fsi_coo_verification/batch-failures/batch-worker_fatal.log'
EXPECTED_RAW_SHA = 'afee44e61594ad87d379d3870a662510273364f1c2faca4bdcb4b079b6c15913'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def item(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': digest(data)}


def functions(source, names, filename):
    # Execute only the named pure parser definitions, never module/main code.
    tree = ast.parse(source, filename=filename)
    selected = [node for node in tree.body if isinstance(node, ast.FunctionDef)
                and node.name in names]
    require({node.name for node in selected} == set(names), 'Missing pure parser function')
    namespace = {'re': re}
    exec(compile(ast.Module(body=selected, type_ignores=[]), filename, 'exec'), namespace)
    return namespace


def main():
    summary_path = CI_ROOT / 'evidence/summary.json'
    ctest_path = CI_ROOT / 'evidence/ctest.log'
    summary = json.loads(summary_path.read_text())
    ci_commit = summary['commit']
    old_path = 'tests/verify_fsi_coo.py'
    runner_path = 'tests/verify_fsi_inlet.py'
    old_source = git('show', f'{ci_commit}:{old_path}')
    runner_source = git('show', f'{ci_commit}:{runner_path}')
    current_source = (ROOT / old_path).read_bytes()
    require(current_source == git('show', f'{PARSER_COMMIT}:{old_path}'),
            'Working parser differs from pushed parser source')
    require(runner_source == (ROOT / runner_path).read_bytes(), 'Runner gate source changed')
    require(not git('diff', f'{PRODUCTION_COMMIT}..{PARSER_COMMIT}', '--',
                    'src', 'include', 'CMakeLists.txt'), 'Production sources changed')
    raw_bytes = RAW.read_bytes()
    require(digest(raw_bytes) == EXPECTED_RAW_SHA, 'Archived raw log hash mismatch')
    text = raw_bytes.decode('utf-8')
    old = functions(old_source, ['records'], f'{ci_commit}:{old_path}')
    current = functions(current_source, ['require', 'check_batch_injection'],
                        f'{PARSER_COMMIT}:{old_path}')
    old_records = old['records'](text, 'fsi_batch_failure')
    record = current['check_batch_injection'](text, 'worker_fatal')
    require(old_records == [], 'Original parser did not reproduce the CI failure')
    require(record == {'mode': 'worker_fatal', 'thread': '1', 'team': '2', 'batch': '1'},
            'Unexpected current parser result')
    observed = {
        'injection_marker_count': text.count('fsi_batch_failure'),
        'fatal_message_count': text.count('Injected fatal FSI batch failure'),
        'failed_status_count': text.count('status=failed'),
        'successful_status_count': text.count('status=success'),
        'retry_marker_count': text.count('step_retry='),
        'accepted_step_marker_count': text.count('fsi_step='),
        'mpi_abort_reported': 'MPI_ABORT was invoked' in text,
        'mpi_abort_errorcodes': [int(x) for x in re.findall(r'Errorcode:\s*(\d+)', text)],
        'terminal_nul_bytes': len(raw_bytes) - len(raw_bytes.rstrip(b'\x00')),
    }
    require(observed['fatal_message_count'] == 2 and observed['failed_status_count'] == 2,
            'Missing rank fatal evidence')
    require(observed['successful_status_count'] == observed['retry_marker_count']
            == observed['accepted_step_marker_count'] == 0, 'Fatal run retried or accepted')
    require(observed['mpi_abort_reported'] and observed['mpi_abort_errorcodes'] == [1],
            'Missing MPI nonzero abort evidence')
    ci_test = next(row for row in summary['tests'] if row['name'] == 'fsi_coo_verification')
    require(ci_test['status'] == 'failed' and ci_test['exit_code'] == 1
            and ci_test['timeout'] is False, 'Unexpected archived CI test result')
    ctest = ctest_path.read_text()
    require('line 329, in batch_failures' in ctest
            and 'check_injection(text, mode)' in ctest
            and 'RuntimeError: worker_fatal: missing single injection in an actual multi-thread team'
            in ctest, 'Archived traceback does not show parser failure')
    runner_text = runner_source.decode()
    require('assert result.returncode != 0 and fail in output' in runner_text,
            'Missing original expected-failure gate')
    old_text = old_source.decode()
    fatal_block = old_text[old_text.index("for mode, coo in (('worker_fatal'"):]
    require(fatal_block.index("fail='Injected fatal FSI batch failure'")
            < fatal_block.index('check_injection(text, mode)'), 'Fatal predicate order changed')
    command = ['python', str(Path(__file__).relative_to(ROOT))]
    result = {
        'status': 'passed',
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Offline pure parser replay and archived evidence audit; no solver or test suite launched.',
        'command': command,
        'python_executable': sys.executable,
        'working_directory': str(ROOT),
        'script': item(Path(__file__)),
        'parser_commit': PARSER_COMMIT,
        'parser_tree': git('rev-parse', f'{PARSER_COMMIT}^{{tree}}').decode().strip(),
        'production_source_commit': PRODUCTION_COMMIT,
        'production_src_include_cmake_unchanged': True,
        'current_parser_source': item(ROOT / old_path),
        'archived_ci_commit': ci_commit,
        'archived_parser_source': {'git_object': f'{ci_commit}:{old_path}',
                                   'sha256': digest(old_source)},
        'archived_runner_source': {'git_object': f'{ci_commit}:{runner_path}',
                                   'sha256': digest(runner_source), 'unchanged_in_current_tree': True},
        'raw_log': item(RAW),
        'old_records_count': len(old_records),
        'current_injection_record': record,
        'raw_observations': observed,
        'ci_driver_summary': ci_test,
        'ci_evidence': [item(summary_path), item(ctest_path)],
        'nonzero_failure_evidence': {
            'driver_predicate': 'assert result.returncode != 0 and fail in output',
            'archived_traceback_reached_parser_after_expected_failure_return': True,
            'interpretation': 'The original driver passed its expected nonzero/fatal predicate before the parser failed; raw MPI_ABORT Errorcode: 1 independently supports fatal termination.',
            'individual_solver_launch_returncode_saved': False,
            'limitation': 'CI summary exit_code=1 is the test driver result. No numeric per-launch or per-rank solver return code is reconstructed or asserted.',
        },
    }
    destination = HERE / 'independent-replay.json'
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'report': str(destination.relative_to(ROOT)),
                      'raw_log_sha256': digest(raw_bytes), 'old_records_count': len(old_records),
                      'current_injection_record': record, 'raw_observations': observed}, indent=2))


if __name__ == '__main__':
    main()
