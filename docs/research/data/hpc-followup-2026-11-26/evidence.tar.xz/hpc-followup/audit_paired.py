"""Replay preserved assembly/MPI evidence; never execute a solver."""
from pathlib import Path
import csv
import hashlib
import json
import math
import re
import statistics
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
TIMERS = ('setup_seconds', 'schur_setup_seconds', 'solve_seconds', 'assembly_seconds',
          'callback_seconds', 'failure_sync_seconds', 'assembly_finalize_seconds',
          'constraint_seconds', 'ghost_seconds', 'linear_seconds',
          'linear_diagnostic_seconds', 'finalize_seconds')

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def lines(text, prefix):
    return [dict(item.split('=', 1) for item in line.split() if '=' in item)
            for line in text.splitlines() if line.startswith(prefix)]

def stats(values):
    return {'median': statistics.median(values), 'minimum': min(values), 'maximum': max(values)}

def maxdiff(first, second):
    require(first.keys() == second.keys(), 'Field/history identities differ')
    require(all(len(first[key]) == len(second[key]) for key in first), 'Field/history widths differ')
    return max((abs(x-y) for key in first for x,y in zip(first[key],second[key])), default=0.)

FIELD_COUNTS = {'pieces':0, 'owner_vectors':0, 'ghost_vectors':0, 'ghost_max_difference':0.}

def fields(base, ranks):
    result = {}
    ghosts = []
    for domain in ('', '_solid'):
        pieces, support = [], set()
        for rank in range(ranks):
            file = base.with_name(base.stem+domain+(f'_rank{rank}' if ranks>1 else '')+'.vtu')
            piece = ET.parse(file).find('.//Piece')
            FIELD_COUNTS['pieces'] += 1
            count = int(piece.get('NumberOfPoints'))
            arrays = {}
            for node in piece.findall('./PointData/DataArray'):
                name = node.get('Name')
                require(name not in arrays and node.get('format') == 'ascii', 'Invalid point data')
                parse = int if node.get('type').startswith(('Int', 'UInt')) else float
                width = int(node.get('NumberOfComponents', '1'))
                values = list(map(parse, node.text.split()))
                require(len(values) == count*width and all(map(math.isfinite,values)), 'Invalid field shape/value')
                arrays[name] = (width, values)
            coordinates = list(map(float, piece.find('./Points/DataArray').text.split()))
            require(len(coordinates) == 3*count and all(map(math.isfinite,coordinates)), 'Invalid geometry')
            arrays['coordinates'] = (3,coordinates)
            ids = arrays['mesh_node_id'][1]
            owner = arrays['owner'][1]
            require(len(set(ids)) == count and all(0 <= x < ranks for x in owner), 'Invalid ownership')
            connectivity = list(map(int,piece.find('./Cells/DataArray[@Name="connectivity"]').text.split()))
            require(all(0 <= x < count for x in connectivity), 'Invalid connectivity')
            support.update(ids[index] for index in connectivity)
            pieces.append((ids,owner,arrays))
        require(support, 'Domain has no support')
        for rank,(ids,owners,arrays) in enumerate(pieces):
            for i,(node,owner) in enumerate(zip(ids,owners)):
                if node not in support:
                    continue
                for name,(width,data) in arrays.items():
                    if name in ('mesh_node_id','algebra_node_id','owner'):
                        continue
                    key = (domain,node,name)
                    value = tuple(data[i*width:(i+1)*width])
                    if owner == rank:
                        require(key not in result,'Duplicate owned field')
                        result[key] = value
                        FIELD_COUNTS['owner_vectors'] += 1
                    else:
                        ghosts.append((key,value))
    for key,value in ghosts:
        FIELD_COUNTS['ghost_vectors'] += 1
        require(key in result and len(value)==len(result[key]) and
                max(abs(x-y) for x,y in zip(value,result[key])) <= 2e-9,'Ghost disagreement')
        FIELD_COUNTS['ghost_max_difference'] = max(FIELD_COUNTS['ghost_max_difference'], max(abs(x-y) for x,y in zip(value,result[key])))
    return result

def history(path):
    with path.open() as stream:
        rows = list(csv.DictReader(stream))
    require(len(rows)==5,'History length')
    result = {}
    for i,row in enumerate(rows,1):
        converted = {k:float(v) for k,v in row.items()}
        require(converted['step']==i and abs(converted['time']-.02*i)<1e-13 and
                abs(converted['accepted_dt']-.02)<1e-13,'History accepted grid')
        require(all(map(math.isfinite,converted.values())),'Nonfinite history')
        for k,v in converted.items():
            result[(i,k)] = (v,)
    return result


def event_table(path):
    output={}
    names=('MatAssemblyBegin','MatAssemblyEnd','MatZeroEntries','MatSetPreallCOO','MatSetValuesCOO',
           'FSIElementBatch','FSIInsert','FSIForceReplay','KSPSetUp','KSPSolve','PCSetUp')
    content=path.read_text()
    require('Using PETSc Release Version 3.23.7' in content, 'PETSc build identity missing')
    for line in content.splitlines():
        values=line.split()
        if values and values[0] in names:
            require(values[0] not in output and len(values)>=10,'Missing/duplicate event row')
            output[values[0]]={'maximum_count':int(values[1]),'count_max_min_ratio':float(values[2]),
                              'maximum_seconds':float(values[3]),'time_max_min_ratio':float(values[4]),
                              'reported_reductions':float(values[9])}
    require(all(name in output for name in ('MatAssemblyBegin','MatAssemblyEnd','FSIElementBatch','FSIInsert')),
            'Missing mandatory event')
    return output

def main():
    directory=WORK/'paired'
    data=json.loads((directory/'results.json').read_text())
    audit={'status':'passed','auditor':'amg_review independent raw paired replay',
           'script_sha256':sha(__file__),'results_sha256':sha(directory/'results.json'),
           'run_count':0,'step_reports':0,'linear_corrections':0,'true_linear_max_gate_ratio':0.,
           'physical_field_acceptance_rows':0,'hash_assertions':0,'states_checked':0,
           'same_partition_field_max_difference':0.,'same_partition_history_max_difference':0.,
           'pairs_recomputed':[],'summary_recomputed':[],'petsc_events':[],
           'limits':[
               'No solver or numerical test was executed by this audit.',
               'Wall times are checked against preserved launch records, not reconstructed from log timestamps.',
               'Shared single host; one mesh, 1/2 ranks, two element workers, one library thread, three measured pairs plus a warmup pair per rank count.',
               'Per-step maximum-rank timers overlap and cannot be added to reconstruct wall time.',
               'PETSc event counts are maximum rank counts; ratios and times are printed at limited precision.',
               'Current build identity and incremental log supersede the inherited historical build receipt for source provenance.',
               'Both production changes are enabled together; this campaign does not isolate their individual wall-time effects.'
           ]}
    require(data['status']=='passed' and data['source_commit']=='4c7edc6cc14219acfc97d39b9651c935a1c875ac','Wrong/incomplete source campaign')
    require(data['source_status']=='' and data['library_threads_per_rank']==1 and
            data['element_threads_per_rank']=={'baseline':2,'candidate':2},'Unexpected source/thread condition')
    require(sha(ROOT/'scripts/benchmark_fsi_assembly.py')==data['source_script_sha256'],'Driver source hash differs')
    require(data['field_absolute_limit']==2e-9 and data['linear_gate']=='1e-12 + 1e-10 * rhs_norm','Acceptance gate changed')
    require(data['baseline_options']==data['candidate_options']==['-fsi_overlap','true','-fsi_threads','2'], 'Different execution settings')
    require(len(data['runs'])==16 and len(data['pairs'])==6,'Incomplete campaign')
    preset=data['solver_preset']['options']
    require(hashlib.sha256(json.dumps(preset,separators=(',',':')).encode()).hexdigest()==data['solver_preset']['options_sha256'],'Preset hash')
    require(data['solver_preset']['name']=='hybrid' and preset[preset.index('-ksp_rtol')+1]=='1e-11' and
            preset[preset.index('-pc_plan_schur_approx')+1]=='nodal','Unexpected mathematical preset')
    digests={}
    def verify(path,expected,size=None):
        path=Path(path)
        if path not in digests:digests[path]=sha(path)
        require(digests[path]==expected,'SHA mismatch: '+str(path))
        require(size is None or path.stat().st_size==size,'File size mismatch: '+str(path))
        audit['hash_assertions']+=1
    for mode,binary in data['binaries'].items():
        verify(binary['path'],binary['sha256'])
        require(binary['solver_options']==preset and binary['solver_options_sha256']==data['solver_preset']['options_sha256'],'Binary preset differs')
        for key in ('cmake_cache','build_receipt'):
            if key in binary:verify(directory/binary[key]['path'],binary[key]['sha256'])
    identity=json.loads((WORK/'build-identity.json').read_text())
    sync=json.loads((WORK/'sync-before-validation.json').read_text())
    baseline=json.loads((WORK/'baseline.json').read_text())
    prior=json.loads((ROOT/'docs/research/data/adaptive-retry-budget-2026-11-26/focused-receipt.json').read_text())
    inherited=json.loads((directory/'candidate-build_receipt.json').read_text())
    require(identity['source']==sync['remote_source']==data['source_commit'] and not identity['dirty'] and
            sync['tree_equal'] and not sync['validation_started'],'Invalid source/build receipt')
    tree=subprocess.check_output(['git','rev-parse',data['source_commit']+'^{tree}'],cwd=ROOT,text=True).strip()
    require(tree==identity['tree']==sync['tree'],'Git tree identity mismatch')
    require(identity['captured_utc']>sync['synchronized_at_utc'],'Build identity precedes synchronization')
    require(identity['binaries']['eonsim']==data['binaries']['candidate']['sha256'],'Candidate binary provenance mismatch')
    verify(ROOT/'build/cloud-3.23.7-release/verify_pc_plan',identity['binaries']['verify_pc_plan'])
    require(prior['binaries']['eonsim']==baseline['baseline_sha256']==data['binaries']['baseline']['sha256'],'Baseline historical hash mismatch')
    source_diff=subprocess.check_output(['git','diff',prior['source_commit'],data['binaries']['baseline']['build_source_commit'],
                                         '--','src','include','CMakeLists.txt'],cwd=ROOT,text=True)
    require(not source_diff,'Baseline production source differs from its historical build')
    log=(WORK/'build.log').read_text()
    require('src/algebra/pc_plan.cpp.o' in log and 'src/physics/fsi.cpp.o' in log and
            'Linking CXX executable eonsim' in log and 'Linking CXX executable verify_pc_plan' in log,'Incremental build omitted changed targets')
    require('CMAKE_BUILD_TYPE:STRING=Release' in (directory/'candidate-cmake_cache.txt').read_text(),'Candidate cache is not Release')
    audit['provenance']={'source':identity['source'],'tree':tree,'baseline_implementation':prior['source_commit'],
                         'baseline_main':data['binaries']['baseline']['build_source_commit'],
                         'baseline_binary_sha256':data['binaries']['baseline']['sha256'],
                         'candidate_binary_sha256':data['binaries']['candidate']['sha256'],
                         'current_identity_sha256':sha(WORK/'build-identity.json'),'build_log_sha256':sha(WORK/'build.log'),
                         'sync_receipt_sha256':sha(WORK/'sync-before-validation.json'),
                         'baseline_receipt_sha256':sha(WORK/'baseline.json'),
                         'historical_baseline_receipt_sha256':sha(ROOT/'docs/research/data/adaptive-retry-budget-2026-11-26/focused-receipt.json'),
                         'inherited_build_receipt_commit':inherited['commit'],
                         'inherited_receipt_used_as_current_build_evidence':False}
    for case in data['cases']:
        require(case['subdivisions']==8 and case['fluid_cells']+case['solid_cells']==6147,'Mesh scope mismatch')
        for name,digest in case['input_sha256'].items():verify((directory/case['case']).parent/name,digest)
    for part in data['partitions']:
        require(part['modes']==['baseline','candidate'] and part['cell_weights'] is None,'Partition settings differ')
        for file in part['evidence']['files']:verify(directory/file['path'],file['sha256'],file['bytes'])
    commands={row['log']:row for row in data['commands']}
    require(len(commands)==18,'Missing/duplicate commands')
    for command in commands.values():require(command['returncode']==0 and not command['timeout'],'Failed command')
    references,recomputed,event_runs={}, {}, {}
    history_mapping={'fsi_step':'step','position':'endpoint_position','velocity':'endpoint_velocity',
                     'fluid_force':'evaluation_fluid_force','body_balance':'evaluation_body_balance',
                     'interface_power':'evaluation_interface_power','body_power':'evaluation_body_power',
                     'power_balance':'evaluation_power_balance'}
    expected_nodes={'-':('fgmres','fieldsplit'),'fieldsplit_dynamics_fieldsplit_velocity_':('gmres','asm')}
    for run in data['runs']:
        n,ranks,repeat,mode=(run[key] for key in ('subdivisions','ranks','repeat','mode'))
        text=(directory/run['log']).read_text();command=commands[run['log']];argv=command['command']
        require(command['seconds']==run['wall_seconds'] and command['element_threads_per_rank']==2,'Launch record differs')
        require(argv[argv.index('-n')+1]==str(ranks) and argv[argv.index('-n')+2]==data['binaries'][mode]['path'],'Rank/binary command mismatch')
        require(argv[argv.index('-partition')+1]==str(directory/run['partition']),'Partition mismatch')
        petsc_path=directory/run['log'].replace('.log','-petsc.log')
        require(argv[argv.index('-ksp_type'):]==preset+['-log_view',':'+str(petsc_path),'-fsi_assembly_report']+data[mode+'_options'],'Numerical/execution options changed')
        require(text.count('status=success')==1 and not any(word in text for word in
                ('step_retry=','linear_residual_unavailable','linear_iteration_limit_residual ','solver_node_unavailable')),'Run failed or evidence missing')
        reports=lines(text,'solver_report ');accepted=lines(text,'fsi_step=');physical=lines(text,'field_residual ')
        require(len(reports)==len(accepted)==5 and accepted==run['accepted'] and physical==run['fields'],'Raw step/field evidence mismatch')
        require(len(physical)==20,'Missing physical field gate')
        selected=[];stepnodes=[];last_step=0
        for line in text.splitlines():
            if line.startswith('solver_node '):
                node=lines(line,'solver_node ')[0]
                require(int(node['pc_reason'])==0 and int(node['operator_rows'])>=0 and
                        math.isfinite(float(node['reported_norm'])),'Invalid full solver hierarchy')
                if node['prefix'] in expected_nodes:
                    require((node['ksp'],node['pc'])==expected_nodes[node['prefix']],'Unexpected response solver')
                    require(int(node['ksp_reason'])>0 or (node['prefix']!='-' and int(node['ksp_reason'])==-3),'Response failed')
                    selected.append(node);stepnodes.append((node['prefix'],int(node['rank'])))
            elif line.startswith('fsi_step='):
                require(sorted(stepnodes)==sorted((prefix,rank) for prefix in expected_nodes for rank in range(ranks)),'Missing/duplicate per-step solver evidence')
                stepnodes=[];last_step+=1
        require(not stepnodes and last_step==5 and selected==run['solver_nodes'],'Stored hierarchy differs from raw')
        trajectory=[]
        for step,(report,stored,accept) in enumerate(zip(reports,run['steps'],accepted),1):
            require(int(accept['fsi_step'])==step and abs(float(accept['time'])-.02*step)<1e-13 and float(accept['accepted_dt'])==.02,'Changed accepted grid')
            require(report['ksp']=='fgmres' and report['pc']=='fieldsplit' and int(report['ranks'])==ranks,'Root solver differs')
            require(int(report['snes_reason'])>0 and int(report['ksp_reason'])>0 and int(report['domain_rejections'])==0,'Unconverged step')
            require(int(report['linear_started'])==int(report['linear_completed'])==2,'Linear correction count')
            require(int(report['jacobian_assemblies'])==int(report['user_schur_updates'])==2 and
                    int(report['solver_reused'])==int(step>1) and int(report['solver_generation'])==1,'Freshness/session accounting')
            for key,value in stored.items():
                original=accept['snes_iterations'] if key=='snes_iterations' else report[key]
                require((float(original)==value) if isinstance(value,(int,float)) else original==value,'Stored report mismatch '+key)
            trajectory.append([int(accept['snes_iterations']),int(report['linear_iterations'])])
        require(trajectory==run['iteration_trajectory'],'Iteration trajectory differs')
        for step in range(5):require({x['name'] for x in physical[4*step:4*step+4]}=={'velocity','pressure','mesh','structure'},'Missing/duplicate physical field')
        for field in physical:
            values=[float(field[key]) for key in ('rms','limit','constraint_max','constraint_limit')]
            require(all(math.isfinite(x) and x>=0 for x in values) and int(field['accepted'])==1 and
                    values[0]<=values[1] and values[2]<=values[3],'Physical acceptance failed')
        corrections=lines(text,'linear_residual ')
        require([int(row['solve']) for row in corrections]==[1,2]*5,'Linear correction order')
        ratios=[float(row['norm'])/(1e-12+1e-10*float(row['rhs_norm'])) for row in corrections]
        require(all(math.isfinite(x) and 0<=x<=1 for x in ratios) and max(ratios)==run['max_linear_residual_ratio'],'True linear gate failed')
        audit['linear_corrections']+=len(ratios);audit['true_linear_max_gate_ratio']=max(audit['true_linear_max_gate_ratio'],max(ratios))
        communication=lines(text,'nonlinear_communication ')
        require(communication==run['communication'] and len(communication)==5,'Communication evidence mismatch')
        require([(int(x['overlap']),int(x['fused_reductions']),int(x['ghost_exchanges']),int(x['field_reduction_calls'])) for x in communication]==[(1,1,5,3)]+[(1,1,6,3)]*4,'Communication contract changed')
        plans=lines(text,'fsi_assembly_plan ');execution=lines(text,'fsi_execution_plan ')
        require(plans==run['plan'] and len(plans)==1 and int(plans[0]['cells'])==6147 and int(plans[0]['coo'])==0,'Matrix assembly plan differs')
        require(execution==run['execution_plan'] and len(execution)==1 and int(execution[0]['threads_requested'])==2 and
                int(execution[0]['residual_coo'])==1 and int(execution[0]['batch_cells'])==64,'Execution plan differs')
        sums={key:sum(float(row[key]) for row in reports) for key in TIMERS};sums['wall_seconds']=command['seconds']
        for key in ('peak_rss_max_bytes','peak_rss_sum_bytes'):sums[key]=max(float(row[key]) for row in reports)
        for key in ('pattern_seconds','plan_seconds','system_seconds','setup_seconds'):sums['initialization_'+key]=float(plans[0][key])
        for key,value in sums.items():require(value==run[key],'Stored aggregate differs '+key)
        recomputed[n,ranks,repeat,mode]=sums
        base=directory/run['log'].replace('.log','.vtu')
        states=[fields(base.with_stem(base.stem+f'_step{i}'),ranks) for i in range(1,6)]
        final=fields(base,ranks);hist=history(base.with_suffix('.csv'))
        reference=references.setdefault(ranks,(states,hist))
        delta=max(maxdiff(states[-1],final),*(maxdiff(a,b) for a,b in zip(reference[0],states)))
        history_delta=maxdiff(reference[1],hist)
        require(delta==run['field_max_delta'] and history_delta==run['history_max_delta'],'Stored physical differences disagree')
        require(delta<=2e-9 and history_delta<=2e-9 and run['saved_states_checked']==6,'Physical comparison gate failed')
        for step,accept in enumerate(accepted,1):
            for key,value in accept.items():
                mapped=history_mapping.get(key,key)
                if (step,mapped) in hist:require(float(value)==hist[step,mapped][0],'CSV differs from accepted-step log')
        audit['same_partition_field_max_difference']=max(audit['same_partition_field_max_difference'],delta)
        audit['same_partition_history_max_difference']=max(audit['same_partition_history_max_difference'],history_delta)
        audit['states_checked']+=6;audit['step_reports']+=5;audit['physical_field_acceptance_rows']+=len(physical);audit['run_count']+=1
        for file in run['files']:verify(directory/file['path'],file['sha256'],file['bytes'])
        events=event_table(petsc_path);event_runs[n,ranks,repeat,mode]=events
        audit['petsc_events'].append({'ranks':ranks,'repeat':repeat,'mode':mode,'events':events})
    audit['cross_rank_field_max_difference']=max(maxdiff(a,b) for a,b in zip(references[1][0],references[2][0]))
    audit['cross_rank_history_max_difference']=maxdiff(references[1][1],references[2][1])
    require(audit['cross_rank_field_max_difference']<=2e-9 and audit['cross_rank_history_max_difference']<=2e-9,'Cross-rank physical comparison failed')
    for pair in data['pairs']:
        n,ranks,repeat=(pair[key] for key in ('subdivisions','ranks','repeat'))
        require(repeat in (0,1,2),'Warmup leaked into measured pair')
        base=recomputed[n,ranks,repeat,'baseline'];candidate=recomputed[n,ranks,repeat,'candidate']
        relative={key:candidate[key]/value-1 for key,value in base.items() if value>0}
        require(relative==pair['relative_change'],'Pair statistics differ')
        audit['pairs_recomputed'].append({**pair,'relative_change':relative})
    for summary in data['summary']:
        n,ranks=summary['subdivisions'],summary['ranks']
        modes={mode:{key:stats([recomputed[n,ranks,i,mode][key] for i in range(3)]) for key in summary['modes'][mode]}
               for mode in ('baseline','candidate')}
        changes={key:stats([pair['relative_change'][key] for pair in audit['pairs_recomputed'] if pair['ranks']==ranks])
                 for key in summary['paired_relative_change']}
        result={'subdivisions':n,'ranks':ranks,'modes':modes,'paired_relative_change':changes}
        require(result==summary,'Campaign summary differs');audit['summary_recomputed'].append(result)
    audit['field_read_details']=FIELD_COUNTS
    audit['unique_files_hashed']=len(digests)
    audit['event_mechanism']={}
    for ranks in (1,2):
        values={mode:{name:sorted({events.get(name,{}).get('maximum_count',0) for (n,r,i,m),events in event_runs.items() if r==ranks and m==mode})
                      for name in ('MatAssemblyBegin','MatAssemblyEnd','MatZeroEntries','MatSetPreallCOO','MatSetValuesCOO','FSIElementBatch','FSIInsert')}
                for mode in ('baseline','candidate')}
        audit['event_mechanism'][str(ranks)]=values
    (WORK/'independent-paired-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    compact={k:v for k,v in audit.items() if k not in ('pairs_recomputed','summary_recomputed','petsc_events')}
    compact['timing_percent']={str(x['ranks']):{k:{s:100*v for s,v in x['paired_relative_change'][k].items()}
                                            for k in ('wall_seconds','solve_seconds','linear_seconds','callback_seconds','assembly_seconds','peak_rss_max_bytes')}
                              for x in audit['summary_recomputed']}
    print(json.dumps(compact,indent=2))

if __name__=='__main__':
    main()
