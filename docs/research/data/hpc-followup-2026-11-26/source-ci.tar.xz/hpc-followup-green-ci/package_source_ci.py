#!/usr/bin/env python3
"""Freeze both successful HPC-07 source CI executions and verify every archive member."""
from datetime import datetime, timezone
import hashlib
import io
import json
import lzma
from pathlib import Path
import re
import stat
import subprocess
import tarfile


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'build/hpc-followup-green-ci'
DESTINATION = ROOT / 'docs/research/data/hpc-followup-2026-11-26'
EXCLUDED = set()
SIGNED_URL = re.compile(rb'https?://[^\s"<>]*(?:\?|&|&amp;)(?:sig|signature|token|x-amz-[^=\s]+|x-goog-[^=\s]+|se|sp|sv)=', re.I)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def main():
    for version in ('9066411', '8e6c013'):
        receipt = json.loads((SOURCE / version / 'receipt.json').read_text())
        if receipt.get('status') != 'passed':
            raise RuntimeError('Both green source CI receipts must be finalized before packaging')
    source_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    snapshot_time = datetime.now(timezone.utc).isoformat()
    snapshot, omitted = [], []
    for path in sorted(SOURCE.rglob('*')):
        relative = path.relative_to(SOURCE).as_posix()
        if path.is_symlink():
            raise RuntimeError('Refusing symlink in evidence: ' + relative)
        if not path.is_file():
            continue
        if relative in EXCLUDED or '__pycache__' in path.parts or path.suffix in ('.pyc', '.zip'):
            omitted.append(relative)
            continue
        data = path.read_bytes()
        if SIGNED_URL.search(data):
            raise RuntimeError('Refusing signed URL content in evidence: ' + relative)
        permissions = 0o755 if path.stat().st_mode & 0o111 else 0o644
        snapshot.append((relative, data, permissions))
    DESTINATION.mkdir(parents=True, exist_ok=True)
    archive = DESTINATION / 'source-ci.tar.xz'
    if archive.exists():
        raise RuntimeError('Refusing to overwrite existing archive')
    temporary = DESTINATION / 'source-ci.tar.xz.tmp'
    manifest = []
    with lzma.open(temporary, 'wb', format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC64, preset=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as bundle:
            for relative, data, permissions in snapshot:
                name = 'hpc-followup-green-ci/' + relative
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = permissions
                entry.uid = entry.gid = entry.mtime = 0
                entry.uname = entry.gname = ''
                bundle.addfile(entry, io.BytesIO(data))
                manifest.append({'path': name, 'source': 'build/hpc-followup-green-ci/' + relative,
                                 'bytes': len(data), 'sha256': digest(data), 'mode': oct(permissions)})
    expected = {entry['path']: entry for entry in manifest}
    checked, seen = 0, set()
    with tarfile.open(temporary, 'r:xz') as bundle:
        for entry in bundle:
            if not entry.isfile() or entry.name not in expected or entry.name in seen:
                raise RuntimeError('Unexpected or duplicate archive member: ' + entry.name)
            saved = expected[entry.name]
            data = bundle.extractfile(entry).read()
            source_data = (ROOT / saved['source']).read_bytes()
            if len(data) != saved['bytes'] or digest(data) != saved['sha256'] or data != source_data:
                raise RuntimeError('Archive/source integrity mismatch: ' + entry.name)
            if entry.uid != 0 or entry.gid != 0 or entry.mtime != 0 or entry.mode != int(saved['mode'], 8):
                raise RuntimeError('Archive metadata was not normalized: ' + entry.name)
            seen.add(entry.name)
            checked += 1
    if seen != set(expected):
        raise RuntimeError('Archive has missing members')
    temporary.replace(archive)
    archive_data = archive.read_bytes()
    json_write(DESTINATION / 'source-ci-archive-manifest.json', manifest)
    metadata = {
        'schema': 1, 'archive': archive.name, 'bytes': len(archive_data), 'sha256': digest(archive_data),
        'format': 'tar+XZ, CRC64, preset=6', 'members': len(manifest),
        'uncompressed_file_bytes': sum(entry['bytes'] for entry in manifest),
        'manifest': 'source-ci-archive-manifest.json', 'snapshot_at_utc': snapshot_time,
        'repository_head_at_snapshot': source_head,
        'production_source_commit': '4c7edc6cc14219acfc97d39b9651c935a1c875ac',
        'scope': 'Successful source CI runs for intermediate parser 9066411 and final parser 8e6c013, including selected Release raw outputs, job logs, extraction/source receipts and per-file manifests. Downloaded ZIP transports excluded. Original local/failed-CI evidence.tar.xz remains unchanged.',
        'exclusions': omitted,
        'determinism': 'Lexicographic regular-file members; uid/gid/mtime zero; empty owner names; normalized 0644/0755 modes; no symlink/hardlink members; XZ stores no wall-clock timestamp.'
    }
    json_write(DESTINATION / 'source-ci-archive.json', metadata)
    integrity = {
        'status': 'passed', 'archive': archive.name, 'archive_sha256': metadata['sha256'],
        'members_checked': checked, 'unique_members': len(seen),
        'member_bytes_checked': metadata['uncompressed_file_bytes'],
        'member_sha256_matches': True, 'each_member_equal_to_source_after_archive': True,
        'normalized_metadata': True, 'symlinks': 0, 'signed_download_urls': 0,
        'manifest_sha256': digest((DESTINATION / 'source-ci-archive-manifest.json').read_bytes()),
        'packaging_script_sha256': digest(Path(__file__).read_bytes()),
        'note': 'Integrity replay only; no numerical tests, builds or solver executions were launched.'
    }
    json_write(DESTINATION / 'source-ci-archive-integrity.json', integrity)
    print(json.dumps(metadata, indent=2), flush=True)
    print(json.dumps(integrity, indent=2), flush=True)


if __name__ == '__main__':
    main()
