#define _GNU_SOURCE
#include <fenv.h>
__attribute__((constructor)) static void trap_solver_floating_point(void) {
    feenableexcept(FE_INVALID | FE_DIVBYZERO | FE_OVERFLOW);
}
