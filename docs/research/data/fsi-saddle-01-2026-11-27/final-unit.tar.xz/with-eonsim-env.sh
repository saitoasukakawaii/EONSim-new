#!/usr/bin/env bash
set -euo pipefail
EONSIM_ENV_PREFIX=/workspace/scratch/2185eeebac03/eonsim-tools/petsc-3.23.7
export PATH="$EONSIM_ENV_PREFIX/bin:$PATH"
export LD_LIBRARY_PATH="$EONSIM_ENV_PREFIX/lib"
export LIBRARY_PATH="$EONSIM_ENV_PREFIX/lib"
export PKG_CONFIG_PATH="$EONSIM_ENV_PREFIX/lib/pkgconfig"
export PETSC_DIR="$EONSIM_ENV_PREFIX"
export CC="$EONSIM_ENV_PREFIX/bin/gcc" CXX="$EONSIM_ENV_PREFIX/bin/g++"
unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH CMAKE_PREFIX_PATH PETSC_ARCH PYTHONOPTIMIZE CFLAGS CXXFLAGS CPPFLAGS LDFLAGS
export OMPI_MCA_btl=self,sm,tcp OMPI_MCA_pml=ob1
export OMP_NUM_THREADS=1 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export OMPI_MCA_rmaps_base_oversubscribe=1 PRTE_MCA_rmaps_default_mapping_policy=:oversubscribe
exec "$@"
