"""Audit downloaded Actions evidence; never build or execute project tests."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import math
import re
import stat
import tarfile
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
OUT = ROOT / 'docs/research/data/rcr-port-2026-11-26'
EXPECTED_RUN = 45776829333
EXPECTED_HEAD = 'ad08887f8b357ef16e6a6b49b89d968f531f8053'
FROZEN_LOCAL_SHA = '50e69135f587a94235e1973d8cb90f5ab305e7f3501f53faf161d2981765628c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(name):
    return json.loads((WORK / name).read_text())


def safe_path(name):
    path = PurePosixPath(name)
    assert name and not path.is_absolute() and '..' not in path.parts, name
    assert '\\' not in name and str(path) == name.rstrip('/'), name
    return path


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def main():
    assert sha((OUT / 'evidence.tar.xz').read_bytes()) == FROZEN_LOCAL_SHA
    run = read_json('final-run.json')
    jobs = read_json('final-jobs.json')['jobs']
    artifacts = read_json('final-artifacts.json')['artifacts']
    assert run['id'] == EXPECTED_RUN and run['head_sha'] == EXPECTED_HEAD
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    assert len({job['id'] for job in jobs}) == len(jobs)
    successful_job_names = {
        'Select affected checks', 'PETSc 3.23.7 / release', 'Record incremental evidence'
    }
    assert {j['name'] for j in jobs if j['conclusion'] == 'success'} == successful_job_names
    assert all(j['status'] == 'completed' for j in jobs)
    skipped_job_names = {
        'PETSc 3.19.6 / release (manual compatibility)',
        'PETSc 3.23.7 / debug (manual diagnostics)'
    }
    assert {j['name'] for j in jobs if j['conclusion'] == 'skipped'} == skipped_job_names
    assert len(jobs) == len(successful_job_names) + len(skipped_job_names)

    payloads = []
    for name in ('initial-run.json', 'initial-jobs.json', 'initial-artifacts.json',
                 'final-run.json', 'final-jobs.json', 'final-artifacts.json'):
        payloads.append((WORK / name, 'metadata/' + name))
    for name in ('selection-job.log', 'release-job.log', 'receipt-job.log'):
        payloads.append((WORK / name, 'actions-logs/' + name))
    payloads.append((Path(__file__), 'analysis/audit_archive.py'))

    artifact_reports = []
    artifact_origins = {}
    extracted = {}
    for artifact in artifacts:
        name = artifact['name']
        assert '/' not in name and '\\' not in name
        path = WORK / (name + '.zip')
        data = path.read_bytes()
        digest = sha(data)
        assert artifact['digest'] == 'sha256:' + digest
        assert len(data) == artifact['size_in_bytes']
        assert not artifact['expired']
        assert artifact['workflow_run']['id'] == EXPECTED_RUN
        assert artifact['workflow_run']['head_sha'] == EXPECTED_HEAD
        archived_zip = ('artifacts/' + path.name) if name in ('incremental-plan', 'incremental-receipt') else None
        if archived_zip:
            payloads.append((path, archived_zip))
        dest = WORK / 'extracted' / name
        artifact_members = []
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            members = z.infolist()
            assert len({m.filename for m in members}) == len(members)
            count = 0
            for member in members:
                relative = safe_path(member.filename)
                mode = member.external_attr >> 16
                assert not stat.S_ISLNK(mode), member.filename
                target = dest.joinpath(*relative.parts)
                if member.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                member_bytes = z.read(member)
                target.write_bytes(member_bytes)
                selected = (name in ('incremental-plan', 'incremental-receipt') or
                    any(part in ('evidence', 'Testing', 'rcr_port_fsi', 'restore-evidence')
                        for part in relative.parts) or
                    relative.name in ('CMakeCache.txt', 'CMakeConfigureLog.yaml'))
                archive_member = 'extracted/' + name + '/' + member.filename if selected else None
                if selected:
                    payloads.append((target, archive_member))
                    artifact_origins[archive_member] = dict(artifact_id=artifact['id'],
                        artifact_name=name, zip_member=member.filename)
                artifact_members.append(dict(zip_member=member.filename,
                    bytes=len(member_bytes), sha256=sha(member_bytes), crc32=f'{member.CRC:08x}',
                    archived=selected, archive_path=archive_member))
                count += 1
        members_path = WORK / (name + '.members.json')
        write_json(members_path, dict(artifact_id=artifact['id'], artifact_name=name,
            zip_bytes=len(data), zip_sha256=digest, members=artifact_members))
        payloads.append((members_path, 'metadata/' + members_path.name))
        extracted[name] = dest
        artifact_reports.append(dict(id=artifact['id'], name=name,
            bytes=len(data), sha256=digest, github_digest_matched=True,
            extracted_files=count, archived_files=sum(m['archived'] for m in artifact_members),
            downloaded_zip_path=str(path.relative_to(ROOT)), archived_zip_path=archived_zip,
            member_inventory='metadata/' + members_path.name, created_at=artifact['created_at'],
            expires_at=artifact['expires_at']))

    assert len(artifacts) == 3
    plan_path = extracted['incremental-plan'] / 'plan.json'
    receipt_path = extracted['incremental-receipt'] / 'receipt.json'
    plan = json.loads(plan_path.read_text())
    receipt = json.loads(receipt_path.read_text())
    numeric_name = next(n for n in extracted if n.startswith('numerics-3.23.7-release-'))
    numeric = extracted[numeric_name]
    summary_paths = list(numeric.rglob('summary.json'))
    assert len(summary_paths) == 1
    summary_path = summary_paths[0]
    evidence = summary_path.parent
    summary = json.loads(summary_path.read_text())
    assert plan['run_id'] == EXPECTED_RUN and plan['head'] == EXPECTED_HEAD
    assert plan['tests'] == plan['required'] and plan['reused'] == []
    assert len(set(plan['tests'])) == len(plan['tests'])
    assert summary['status'] == 'passed' and summary['dirty'] is False
    assert summary['petsc'] == '3.23.7' and summary['mode'] == 'release'
    assert summary['commit'] == plan['commit']
    assert summary['lock_sha256'] == sha((ROOT / 'environments/petsc-3.23.7-linux-64.lock').read_bytes())
    assert all(c['exit_code'] == 0 and not c['timeout'] and
               not c['cleaned_live_descendants'] for c in summary['commands'])

    inventory = json.loads((evidence / 'selected-inventory.json').read_text())
    assert len(inventory) == len({item['name'] for item in inventory})
    assert set(item['name'] for item in inventory) == set(plan['tests'])
    junit_path = evidence / 'junit.xml'
    junit_root = ET.parse(junit_path).getroot()
    cases = junit_root.findall('.//testcase')
    assert int(junit_root.get('tests')) == len(cases)
    assert int(junit_root.get('failures', 0)) == 0
    assert int(junit_root.get('errors', 0)) == 0
    assert int(junit_root.get('disabled', 0)) == 0
    assert int(junit_root.get('skipped', 0)) == 0
    assert len(cases) == len({c.get('name') for c in cases})
    assert set(c.get('name') for c in cases) == set(plan['tests'])
    junit_results = []
    for case in cases:
        failed = (case.find('failure') is not None or case.find('error') is not None or
                  case.get('status') in ('failed', 'failure', 'error'))
        skipped = case.find('skipped') is not None or case.get('status') in ('notrun', 'disabled')
        status = 'failed' if failed else 'skipped' if skipped else 'passed'
        if status == 'passed':
            assert case.get('status') in (None, 'run', 'passed'), case.attrib
        duration = float(case.get('time', 0))
        assert math.isfinite(duration) and duration >= 0
        junit_results.append(dict(name=case.get('name'), status=status, seconds=duration))
    junit_counts = dict(Counter(x['status'] for x in junit_results))
    assert junit_counts == {'passed': len(plan['tests'])}

    ctest_paths = list(numeric.glob('**/Testing/*/Test.xml'))
    assert len(ctest_paths) == 1
    details = ET.parse(ctest_paths[0]).findall('.//Testing/Test')
    assert len(details) == len({c.findtext('Name') for c in details})
    assert set(c.findtext('Name') for c in details) == set(plan['tests'])
    assert Counter(c.get('Status') for c in details) == Counter(passed=len(plan['tests']))
    for case in details:
        values = {m.get('name'):m.findtext('Value') for m in case.findall('./Results/NamedMeasurement')}
        assert values.get('Exit Code', 'Completed') == 'Completed'
        assert int(values.get('Exit Value', 0)) == 0
    results = summary['tests']
    assert len(results) == len({r['name'] for r in results}) == len(plan['tests'])
    assert set(r['name'] for r in results) == set(plan['tests'])
    assert all(r['status'] == 'passed' and r['exit_code'] == 0 and
               not r['timeout'] for r in results)
    ctest_log = (evidence / 'ctest.log').read_text()
    passes = re.findall(r'^\s*\d+/\d+ Test\s+#\d+:\s+(\S+)\s+\.+\s+Passed\s', ctest_log, re.M)
    assert len(passes) == len(set(passes)) == len(plan['tests']), len(passes)
    assert set(passes) == set(plan['tests'])
    assert re.search(r'^100% tests passed(?:, 0 tests failed)? out of ' +
                     str(len(plan['tests'])) + r'$', ctest_log, re.M)

    for field in ('repository','pr','base','head','commit','tree','fingerprint','run_id'):
        assert receipt[field] == plan[field], field
    assert receipt['status'] == 'passed'
    assert receipt['executed'] == plan['tests']
    assert receipt['covered'] == plan['required']
    assert receipt['reused'] == [] and receipt['previous_run_id'] is None
    assert set(receipt['origins']) == set(plan['tests'])
    assert all(value == {'release': {'run_id': EXPECTED_RUN, 'commit': plan['commit']}}
               for value in receipt['origins'].values())

    selection_log = (WORK / 'selection-job.log').read_text()
    lines = [re.sub(r'^\d{4}-\d\d-\d\dT\S+\s', '', x) for x in selection_log.splitlines()]
    python_results = []
    for index, line in enumerate(lines):
        match = re.fullmatch(r'Ran (\d+) tests? in ([0-9.]+)s', line)
        if match:
            following = next((x for x in lines[index+1:index+6] if x.strip()), '')
            assert following == 'OK', following
            python_results.append(dict(script=plan['python'][len(python_results)],
                executed=int(match[1]), passed=int(match[1]), failed=0, skipped=0,
                seconds=float(match[2]), result=following))
    assert len(python_results) == len(plan['python']) == 5
    assert [x['executed'] for x in python_results] == [26,6,6,3,13]

    manifest = []
    payloads = sorted(payloads, key=lambda x:x[1])
    assert len(payloads) == len({name for _,name in payloads})
    archive = OUT / 'source-ci.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as tar:
        for source, name in payloads:
            safe_path(name)
            assert source.is_file() and not source.is_symlink()
            data = source.read_bytes()
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mtime = 0
            item.uid = item.gid = 0
            item.uname = item.gname = ''
            item.mode = 0o644
            tar.addfile(item, io.BytesIO(data))
            record = dict(source_path=str(source.relative_to(ROOT)),
                archive_path=name, bytes=len(data), sha256=sha(data))
            if name in artifact_origins:
                record['artifact_origin'] = artifact_origins[name]
            manifest.append(record)
    manifest_map = {f['archive_path']:f for f in manifest}
    verified = []
    with tarfile.open(archive, 'r:xz') as tar:
        members = tar.getmembers()
        assert len(members) == len(manifest_map)
        assert len({m.name for m in members}) == len(members)
        assert {m.name for m in members} == set(manifest_map)
        for member in members:
            safe_path(member.name)
            assert member.isfile()
            data = tar.extractfile(member).read()
            expected = manifest_map[member.name]
            assert len(data) == member.size == expected['bytes']
            assert sha(data) == expected['sha256']
            source = ROOT / expected['source_path']
            assert sha(source.read_bytes()) == expected['sha256']
            verified.append(dict(archive_path=member.name, bytes=len(data),
                sha256=sha(data), size_match=True, sha256_match=True, source_unchanged=True))
    assert sha((OUT / 'evidence.tar.xz').read_bytes()) == FROZEN_LOCAL_SHA
    archive_data = archive.read_bytes()
    archive_report = dict(path=archive.name, bytes=len(archive_data), sha256=sha(archive_data),
        members=len(manifest), uncompressed_bytes=sum(f['bytes'] for f in manifest))
    report = dict(schema_version=1,
        audited_at_utc=datetime.now(timezone.utc).isoformat(),
        repository=plan['repository'], pr=plan['pr'], source_head=plan['head'],
        tested_merge_preview_commit=plan['commit'], tested_tree=plan['tree'],
        base=plan['base'], fingerprint=plan['fingerprint'],
        run=dict(id=run['id'], url=run['html_url'], attempt=run['run_attempt'],
            status=run['status'], conclusion=run['conclusion']),
        jobs=[{key:j.get(key) for key in ('id','name','status','conclusion','started_at','completed_at')}
              for j in jobs], artifacts=artifact_reports,
        numerical=dict(required=len(plan['required']), selected=len(plan['tests']),
            executed=len(cases), passed=junit_counts.get('passed',0), failed=junit_counts.get('failed',0),
            skipped=junit_counts.get('skipped',0), reused=len(plan['reused']),
            summary_status=summary['status'], petsc=summary['petsc'], mode=summary['mode'],
            results=junit_results),
        python=dict(scripts=len(python_results), executed=sum(x['executed'] for x in python_results),
            passed=sum(x['passed'] for x in python_results), failed=0, skipped=0,
            results=python_results,
            negative_control_annotations='test_cloud_evidence.py intentionally emits failure/skip XML annotations; its unittest result is OK.'),
        independent_checks=dict(github_artifact_digests=True, exact_selected_inventory=True,
            junit=True, ctest_test_xml=True, ctest_log=True, summary=True,
            receipt_and_origins=True, python_unittest_results=True,
            archive_reopened_and_rehashed=True, source_files_unchanged=True,
            local_frozen_archive_unchanged=True), archive=archive_report)
    write_json(OUT / 'source-ci.json', report)
    write_json(OUT / 'source-ci.manifest.json', dict(schema_version=1, files=manifest))
    write_json(OUT / 'source-ci.integrity.json', dict(schema_version=1,
        status='passed', archive=archive_report, verified_members=len(verified),
        checks=dict(no_absolute_paths=True, no_parent_traversal=True, no_links=True,
            no_duplicate_paths=True, exact_inventory=True, all_sizes_match=True,
            all_sha256_match=True, all_original_sources_unchanged=True,
            frozen_local_archive_sha256=FROZEN_LOCAL_SHA), files=verified))
    (OUT / 'source-ci.selection.json').write_bytes(plan_path.read_bytes())
    (OUT / 'source-ci.receipt.json').write_bytes(receipt_path.read_bytes())
    (OUT / 'source-ci.summary.json').write_bytes(summary_path.read_bytes())
    print(json.dumps(dict(run_id=EXPECTED_RUN, numerical=report['numerical'] | {'results':'omitted'},
        python=report['python'], artifacts=artifact_reports, archive=archive_report), indent=2))


if __name__ == '__main__':
    main()
