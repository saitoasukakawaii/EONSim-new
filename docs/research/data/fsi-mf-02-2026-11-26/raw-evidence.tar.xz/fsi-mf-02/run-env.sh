#!/usr/bin/env bash
set -euo pipefail
export EONSIM_FSI_RUNTIME=/workspace/scratch/ae740e1dde63/EONSim-new/.cloud/petsc-3.23.7
export PATH="$EONSIM_FSI_RUNTIME/bin:$PATH"
export LD_LIBRARY_PATH="$EONSIM_FSI_RUNTIME/lib"
export LIBRARY_PATH="$EONSIM_FSI_RUNTIME/lib"
export PKG_CONFIG_PATH="$EONSIM_FSI_RUNTIME/lib/pkgconfig"
export PETSC_DIR="$EONSIM_FSI_RUNTIME"
export OMP_NUM_THREADS=1 OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export OMPI_MCA_btl=self,sm,tcp OMPI_MCA_pml=ob1 OMPI_MCA_rmaps_base_oversubscribe=1
export PRTE_MCA_rmaps_default_mapping_policy=:oversubscribe
unset PETSC_ARCH PYTHONOPTIMIZE
exec "$@"
