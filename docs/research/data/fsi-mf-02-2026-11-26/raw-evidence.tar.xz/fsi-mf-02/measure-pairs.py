"""Interleave archived/new executables on an identical validated moving FSI input.

Use after sourcing run-env.sh's environment. Production/test sources must already
be synchronized. This is a measurement orchestration record, not a solver change.
"""
import json, math, shutil, statistics, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tests'))
import verify_fsi_multigrid as mg
import verify_fsi_advanced_pc as previous
from verify_fsi_inlet import error, check_rcr_history

base = ROOT / 'build/fsi-mf-02'
source = next((base / 'physical-moving').glob('*/results.json'))
source_receipt = json.loads(source.read_text())
original = source.parent / 'moving-rcr'
work = base / 'paired-moving'
work.mkdir(exist_ok=False)
for name in ('fluid.msh', 'solid.msh', 'geometry.json'):
    shutil.copy2(original / name, work / name)
shutil.copytree(original / 'part-2', work / 'part-2')
cfg = json.loads((original / 'mono_mf.json').read_text())
area = json.loads((work / 'geometry.json').read_text())['interface_area']
executables = {'baseline': base / 'eonsim-baseline', 'candidate': ROOT / 'build/cloud-3.23.7-release/eonsim'}
mpi = Path('/workspace/scratch/ae740e1dde63/EONSim-new/.cloud/petsc-3.23.7/bin/mpiexec')
result = {'status': 'running', 'source_receipt': str(source), 'ranks': 2, 'samples': 3,
          'source_commits': {'baseline': '3b5cbddb928dfa789dc1f3f424dba451f33107e6',
                             'candidate': 'b7d727bd10231c22987b18114d1e25d622b2b8f1'},
          'executable_sha256': {k: mg.assembly.digest(v) for k,v in executables.items()},
          'input_sha256': {name: mg.assembly.digest(work / name) for name in ('fluid.msh','solid.msh','geometry.json')},
          'commands': [], 'runs': [], 'pairs': [], 'linear_gate': '1e-12 + 1e-10*rhs_norm', 'field_limit': previous.FIELD_LIMIT}
receipt = work / 'results.json'
previous.save(result, receipt)
runners = {k: previous.EvidenceRunner(v, mpi, work, timeout=240, interface_area=area, commands=result['commands'])
           for k,v in executables.items()}
reference = None

def solve(version, label, measured, direct=False):
    global reference
    runner = runners[version]
    mode = 'direct' if direct else 'mono_mf'
    row = {'label': label, 'version': version, 'measured': measured, 'mode': mode, 'status': 'running'}
    result['runs'].append(row)
    previous.save(result, receipt)
    fields, trace, log = runner.solve(label, cfg, 2, mg.flags(mode, ports=not direct))
    snapshots = previous.snapshot(runner, label, trace, 2)
    row.update(mg.audit(log, trace, 2, mode))
    row['matrix_free_seconds_rank0'] = sum(float(r['matrix_free_seconds_rank0'])
          for r in mg.assembly.records(log, 'solver_report '))
    row['wall_seconds'] = result['commands'][-1]['wall_seconds']
    if reference is None:
        assert direct
        reference = fields, trace, snapshots
    row['field_max_difference'] = max(error(fields, reference[0]), *(
        mg.assembly.compare_fields(a,b) for a,b in zip(snapshots, reference[2])))
    assert len(snapshots) == len(reference[2]) and row['field_max_difference'] <= previous.FIELD_LIMIT
    row['history_max_difference'] = previous.compare_history(reference[1], trace)
    row['circuit_defect'] = check_rcr_history(runner, label, cfg['fsi']['domains']['rcr_outlet'], trace)
    row['artifacts'] = [{'path': str(p), 'sha256': mg.assembly.digest(p), 'bytes': p.stat().st_size}
                        for p in sorted(work.glob(label + '*')) if p.is_file()]
    row['status'] = 'passed'
    previous.save(result, receipt)
    return row

try:
    solve('candidate', 'reference', False, True)
    for version in ('baseline','candidate'):
        solve(version, 'warmup-' + version, False)
    metrics = ('matrix_free_seconds_rank0','linear_seconds','solve_seconds','wall_seconds','peak_rss_max_bytes')
    for sample in range(3):
        rows = {}
        order = ('baseline','candidate') if sample % 2 == 0 else ('candidate','baseline')
        for version in order:
            rows[version] = solve(version, f'sample-{sample}-{version}', True)
        result['pairs'].append({'sample': sample, 'order': order,
            'ratios': {metric: rows['candidate'][metric]/rows['baseline'][metric] for metric in metrics},
            'iterations': {v: rows[v]['outer_iterations'] for v in rows},
            'actions': {v: rows[v]['matrix_free_actions'] for v in rows}})
        previous.save(result, receipt)
    result['paired_summary'] = {metric: {'median_ratio': statistics.median([p['ratios'][metric] for p in result['pairs']]),
        'minimum_ratio': min(p['ratios'][metric] for p in result['pairs']),
        'maximum_ratio': max(p['ratios'][metric] for p in result['pairs'])} for metric in metrics}
    assert result['input_sha256'] == {name: mg.assembly.digest(work/name) for name in result['input_sha256']}
    result['status'] = 'passed'
except BaseException as exc:
    result['status'] = 'failed'
    result['error'] = repr(exc)
    raise
finally:
    previous.save(result, receipt)
print(json.dumps({'status': result['status'], 'paired_summary': result.get('paired_summary'), 'pairs': result['pairs']}, indent=2))
