from pathlib import Path
import hashlib,json,math,re,subprocess,xml.etree.ElementTree as ET
root=Path.cwd();base=root/'build/adaptive-retry-budget';s=json.loads((base/'fsi-quick/results-quick.json').read_text());assert s['status']=='passed' and not s['failures'];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();totalsteps=0;totalcorr=0;maxratio=0;maxfield=0;retry=0;hashes=0;rows=[]
for name,digest in s['script_hashes'].items():
 assert h(root/'tests'/name)==digest; assert (root/'tests'/name).read_bytes()==subprocess.check_output(['git','show',s['source_commit']+':tests/'+name]);hashes+=1
assert h(root/'docs/research/data/fsi-linear-transient-2026-11-24/arterial-inputs.tar.xz')==s['input_sha256'];hashes+=1
assert h(root/'build/cloud-3.23.7-release/eonsim')==s['executable_sha256'];hashes+=1

def fields(out,ranks):
 result={}
 for suffix,ns in [('',('velocity','pressure','mesh_displacement')),('_solid',('velocity','displacement'))]:
  for r in range(ranks):
   p=out/('tube_step4'+suffix+(f'_rank{r}' if ranks>1 else '')+'.vtu');a={e.attrib['Name']:e for e in ET.parse(p).findall('.//PointData/DataArray')};ids=list(map(int,a['mesh_node_id'].text.split()));owner=list(map(int,a['owner'].text.split()));assert len(ids)==len(owner)
   for name in ns:
    key=('wall_' if suffix else 'fluid_')+name;n=int(a[name].attrib.get('NumberOfComponents','1'));v=list(map(float,a[name].text.split()));assert len(v)==n*len(ids) and all(map(math.isfinite,v));data=result.setdefault(key,{})
    for i,(gid,own) in enumerate(zip(ids,owner)):
     if own==r:
      assert gid not in data;data[gid]=tuple(v[i*n:(i+1)*n])
 return result
for c in s['cases']:
 d=Path(c['runs'][0]['output_directory']).parent
 for name,digest in c['input_hashes'].items():assert h(d/'input'/name)==digest;hashes+=1
 for name,digest in c['partition_hashes'].items():assert h(d/'partition'/name)==digest;hashes+=1
 ref=fields(Path(c['runs'][0]['output_directory']),c['ranks'])
 for run in c['runs']:
  out=Path(run['output_directory']);log=(out/'solve.log').read_text();assert h(out/'solve.log')==run['log_sha256'];hashes+=1;assert run['exit_code']==0 and not run['timeout'];assert log.splitlines().count('status=success')==1
  counts={};corr=[];reports=[];steps=[]
  for line in log.splitlines():
   x=dict(re.findall(r'(\w+)=([^\s]+)',line))
   if line.startswith('linear_residual '):corr.append({'norm':float(x['norm']),'rhs':float(x['rhs_norm']),'fields':{}})
   elif line.startswith('linear_field_residual '):corr[-1]['fields'][x['name']]=float(x['rms'])
   elif line.startswith('field_residual '):assert x['accepted']=='1';counts[x['name']]=int(x['equation_rows'])
   elif line.startswith('solver_report '):reports.append(x)
   elif line.startswith('fsi_step='):steps.append(x)
  assert len(steps)==len(reports)==run['steps']==4 and len(corr)==run['corrections']==8
  assert [int(x['fsi_step']) for x in steps]==[1,2,3,4] and all(abs(float(x['time'])-(i+1)/32)<1e-14 for i,x in enumerate(steps));assert sum(counts.values())==c['dofs']
  ratios=[]
  for x in corr:
   reconstructed=math.sqrt(sum(counts[name]*rms*rms for name,rms in x['fields'].items()));assert math.isclose(reconstructed,x['norm'],rel_tol=2e-12,abs_tol=1e-300)
   ratios.append(x['norm']/max(1e-23,1e-10*x['rhs']))
  assert max(ratios)<=s['tolerance_margin'] and max(ratios)==run['worst_ratio'];actual=fields(out,c['ranks']);fg={}
  for key,rv in ref.items():
   av=actual[key];assert rv.keys()==av.keys();peak=max(abs(z) for vals in rv.values() for z in vals);difference=max(abs(a-b) for gid in rv for a,b in zip(av[gid],rv[gid]));fg[key]=difference/peak if peak else 0
   assert math.isclose(fg[key],run['field_relative_peaks'][key],rel_tol=1e-12,abs_tol=1e-25) and fg[key]<s['field_relative_peak_limit']
  nr=sum(int(x['pc_rebuild_retries']) for x in reports);assert nr==sum(line.startswith('pc_rebuild_retry ') for line in log.splitlines());retry+=nr
  totalsteps+=len(steps);totalcorr+=len(corr);maxratio=max(maxratio,max(ratios));maxfield=max(maxfield,*fg.values());rows.append(dict(grid=c['grid'],ranks=c['ranks'],mode=run['mode'],steps=len(steps),corrections=len(corr),worst_ratio=max(ratios),field_peak_max=max(fg.values()),retries=nr,pc_refreshes=sum(int(x['pc_refreshes']) for x in reports),pc_reuses=sum(int(x['pc_reuses']) for x in reports)))
print(json.dumps(dict(status='independently-audited',runs=len(rows),steps=totalsteps,corrections=totalcorr,max_true_residual_ratio=maxratio,max_fivefield_peak_ratio=maxfield,real_fsi_pc_rebuild_retries=retry,hash_assertions=hashes,rows=rows),indent=2))
