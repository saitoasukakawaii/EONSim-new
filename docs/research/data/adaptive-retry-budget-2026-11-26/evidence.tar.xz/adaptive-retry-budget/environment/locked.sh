#!/usr/bin/env bash
set -eo pipefail
runtime_state=/workspace/scratch/ae740e1dde63/EONSim-new/.cloud
export MAMBA_ROOT_PREFIX="$runtime_state/mamba"
eval "$("$runtime_state/micromamba" shell hook -s bash)"
micromamba activate "$runtime_state/petsc-3.23.7"
export LD_LIBRARY_PATH="$CONDA_PREFIX/lib" LIBRARY_PATH="$CONDA_PREFIX/lib"
export PKG_CONFIG_PATH="$CONDA_PREFIX/lib/pkgconfig" PETSC_DIR="$CONDA_PREFIX"
export CC="$CONDA_PREFIX/bin/gcc" CXX="$CONDA_PREFIX/bin/g++"
export OMPI_MCA_btl=self,sm,tcp OMPI_MCA_pml=ob1 OMPI_MCA_smsc=^cma
export OMPI_MCA_rmaps_base_oversubscribe=1 PRTE_MCA_rmaps_default_mapping_policy=:oversubscribe
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH CMAKE_PREFIX_PATH PETSC_ARCH PYTHONOPTIMIZE
unset CFLAGS CXXFLAGS CPPFLAGS LDFLAGS
exec "$@"
